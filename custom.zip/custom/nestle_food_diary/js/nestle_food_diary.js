/**
 * @file
 * Handles AJAX fetching of food nutrients post records , including filter submission and response.
 */

(function ($, Drupal) {
    'use strict';
    /**
     * Attaches the AJAX behavior to fetch post records and filters.
     *
     * @type {Drupal~behavior}
     *
     * @prop {Drupal~behaviorAttach} attach
     *   Attaches ajax functionality to relevant elements.
     */
    Drupal.behaviors.food_diary_accord = {
        attach: function (context) {
			
			$(".mealplan-acodn h4:first").addClass("mp-active");
			$(".mealplan-acodn-cont:first").show();
			$(".mealplan-acodn h4").click(function(){
			$(this).next(".mealplan-acodn-cont").slideDown("slow");
			$(".mealplan-acodn .mealplan-acodn-cont:visible").not($(this).next(".mealplan-acodn-cont")).slideUp("slow");
			$(this).addClass("mp-active");
			$(".mealplan-acodn h4").not($(this)).removeClass("mp-active");
			});	

        }
    };
	Drupal.behaviors.food_diary_formvalidation = {
		attach: function (context, settings) {
			$("#edit-food-date").keydown(function(e){
			 e.preventDefault();
			});
		}
	};
	/*
	   Food Diary Meqal Search
	*/

	var laoderHtml = '<div class="loader"><span></span></div>';

	$(document).on('keyup', '.search_meal_cls', function (e) {
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
		var short_url ="hindi/";
		} 
		else {
		var short_url = "";
		}
		var key = jQuery(this).attr('data-key');
		$(".replacesearchData_" + key).show();
		var url=  drupalSettings.path.baseUrl + short_url + "search-meal";

		var searchFoodVal = Drupal.checkPlain(jQuery('#search_meal_frm_' + key).val());
        if(searchFoodVal == '') {
			$(".fooddiarysrchdispaly").hide();
			return false;
		}
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "search-meal",
			data: {
			q: searchFoodVal
			},
			beforeSend: function () {

			},
			success: function (data) {
			$('.replacesearchData_' + key).parent().show();	
			$('.replacesearchData_' + key).html(data);
			}

		});


	});
	/*
	 add search food
	*/
	$(document).on('click', '.searchAutofood', function () {
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
		var short_url ="hindi/";
		} 
		else {
		var short_url = "";
		}
		var key = $(this).attr('data-key');
		var title = $(this).attr('data-title');
		var uniqueId = $(this).parent().attr('data-key');
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "meal-unit",
			data: {
			key: jQuery(this).attr('data-key'),
			title: jQuery(this).attr('data-title')
			},
			beforeSend: function () {
			$(laoderHtml).appendTo(".mealplan-acodn");
			},
			success: function (units) {
			 $(".loader").remove();
			 $(".nadded").remove();
			 $(".foodlist-items-row_"+uniqueId).append(units);
			 $(".replacesearchData_"+uniqueId).html('');
			 $("#search_meal_frm_"+uniqueId).val(title);
			 $("#bn_"+uniqueId).attr("disabled", false);
			 $(".fooddiarysrchdispaly").hide();
			}
		});

	});
	
	/**
	  Add Food button click
	**/
	
	$(document).on('click', '.addfoodmeal', function (event) {

		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
		var short_url ="hindi/";
		} 
		else {
		var short_url = "";
		}
		var dataUniqId = $(this).attr('data-id');
		var txtBoxVal = $("#search_meal_frm_"+dataUniqId).val().trim();
		var qtyVal = $(".foodlist-items-row_"+dataUniqId +" .nadded .qty").val();

		if(txtBoxVal == '') {
		$("#search_meal_frm_"+dataUniqId).css('border-color', 'red');
		return false;
		} else {
		$("#search_meal_frm_"+dataUniqId).css('border-color', '');
		}
		if(qtyVal == '0') {
		$(".foodlist-items-row_"+dataUniqId +" .nadded .qty").css('color', 'red');
		return false;
		} else {
		$(".foodlist-items-row_"+dataUniqId +" .nadded .qty").css('color', '');
		}
		var unitselectVal = $(".foodlist-items-row_"+dataUniqId +" .nadded .droplist").find(":selected").val();
		var fd_quantity_val = Drupal.checkPlain($(".foodlist-items-row_"+dataUniqId +" .nadded .qty").val());
		var fd_serUnit_val = Drupal.checkPlain($(".foodlist-items-row_"+dataUniqId +" .nadded .droplist").find(":selected").val());
		var fd_timeslt_val = Drupal.checkPlain($('#fd_time_val_' + dataUniqId).val());
		var selectedDateval = Drupal.checkPlain($('#edit-food-date').val());
		var fd_search_val = Drupal.checkPlain($(".foodlist-items-row_"+dataUniqId +" .nadded .fooditem-name").attr('data-id'));
		var foodTimeVal = Drupal.checkPlain($(".foodlist-items-row_"+dataUniqId).attr('data-foodtime'));

		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "add-meal",
			data: {
				foodId: fd_search_val,
				qntId: fd_quantity_val,
				servUnt: fd_serUnit_val,
				timeSltval: fd_timeslt_val,
				countVal: dataUniqId,
				selectedDateval: selectedDateval,
				foodTimeVal:foodTimeVal,
				mealName:txtBoxVal
			},
			beforeSend: function () {
			  $(laoderHtml).appendTo(".mealplan-acodn");
			},
			success: function (foodNutrientData) {
			
				$(".loader").remove();
				$(".nutrnal-brkdwn ul").html(foodNutrientData.n_distribution);
				$(".prgbar-crcl").html(foodNutrientData.eneryarrayup);
				$(".nutrient-tips-list").html(foodNutrientData.n_pervct);
				$(".nutrtn-score em").html(foodNutrientData.NutritionScore);
				$(".foodlist-items-row_"+dataUniqId +" .nadded").attr("data-foodentryid",foodNutrientData.foodEntryFinalId);
				$(".foodlist-items-row_"+dataUniqId +" .nadded .fooditem-dlt").attr("data-foodentryid",foodNutrientData.foodEntryFinalId);
				$("#search_meal_frm_"+dataUniqId).val('');
				//console.log($(".foodlist-items-row_"+dataUniqId +" .foodlist-item .nadded").html());
				$(".foodlist-items-row_"+dataUniqId +" .foodlist-item").removeClass('nadded');
				
			}
		});
		return false;
	});
	
	/**
	   Food Quantity Plus Minus
	**/
	$(document).on('click', '.add', function (event) {

		let oldValue = Drupal.checkPlain($(this).prev(".qty").val());
		let newVal = '';
		if (oldValue == "0") {
			newVal = parseFloat(oldValue) + 0.5;
		} else if (oldValue == "0.5") {
			newVal = parseFloat(oldValue) + 0.5;
		} else if (oldValue >= 0.5) {
			newVal = parseFloat(oldValue) + 0.5;
		} 
		$(this).prev(".qty").val(newVal);
		$('.qty').css('color', '');	

	});
	$(document).on('click', '.minus', function (event) {
		let hasclassadded = $(this).hasClass('added');
		if(hasclassadded) {
		alert('yes');
		} else {

		}
		let oldValue = Drupal.checkPlain($(this).next(".qty").val());
		let newVal = '';
		if (oldValue == "0") {
		newVal = oldValue;
		} else if (oldValue >= 0.5) {
		newVal = (parseFloat(oldValue) - 0.5);
		} 
		$(this).next(".qty").val(newVal);
	});
	
	/**
	  Food Item Delete Code
	**/
	$(document).on('click', '.fooditem-dlt', function (event) {
		var food_entry_id = $(this).attr('data-foodentryid');
		if(!food_entry_id) {
			alert('Kinldy add meal item');
			return false;
		}
		var currentdivclick = $(this);
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
			var short_url ="hindi/";
		} 
		else {
			var short_url = "";
		}
		var selectedDateval = Drupal.checkPlain($('#edit-food-date').val());
		var confirmDel = '';
		var foodcnt = "";
		if (lang == "hi") {
			foodcnt = "क्या आप इस फ़ूड को हटाना चाहते हैं?"
		}else{
			foodcnt = "Do you want to delete this food entry?"
		}
		if (confirm(foodcnt)) {
			confirmDel = 1;
		} else {
			confirmDel = 2;
		}
		if (confirmDel == 1) {

			$.ajax({
				dataType: "json",
				url: drupalSettings.path.baseUrl + short_url + "delete-meal",
				data: {
					food_entry_id: food_entry_id,
					selectedDateval: selectedDateval
				},
				beforeSend: function () {
					$(laoderHtml).appendTo(".mealplan-acodn");
				},
				success: function (deleteNutrientData) {

					//jQuery('#' + chk).parents('.food-dairy-form').remove();
					//loadNutritionData(deleteNutrientData);
					jQuery('.loader').remove();
					//$('.'+food_entry_id).remove();
					currentdivclick.parents(".foodlist-item").remove();

					$(".nutrnal-brkdwn ul").html(deleteNutrientData.n_distribution);
					$(".prgbar-crcl").html(deleteNutrientData.eneryarrayhtml);
					$(".nutrient-tips-list").html(deleteNutrientData.n_pervct);
					$(".nutrtn-score em").html(deleteNutrientData.NutritionScore);
				}
			});
		}


	});
	/**
	  Date Change Dairy Value
	**/
	
	$(document).on('change', '#edit-food-date', function (event) {
		var selectedDateval = $(this).val();
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
			var short_url ="hindi/";
		} else {
			var short_url = "";
		}			 
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "date-postnutrition",
			data: {
				selectedDateval: selectedDateval
			},
			beforeSend: function () {
				$(laoderHtml).appendTo(".mealplan-acodn");
			},
			success: function (dataNew) {
				jQuery('.loader').remove(); 
				$(".nutrnal-brkdwn ul").html(dataNew.n_distribution);
				$(".prgbar-crcl").html(dataNew.eneryarrayhtml);
				$(".nutrient-tips-list").html(dataNew.n_pervct);
				$(".nutrtn-score em").html(dataNew.NutritionScore);
				$(".mealplan-acodn").html(dataNew.acrdrow_repeat);
				$(".mealplan-acodn h4:first").addClass("mp-active");
				$(".mealplan-acodn-cont:first").show();
				$(".mealplan-acodn h4").click(function(){
					$(this).next(".mealplan-acodn-cont").slideDown("slow");
					$(".mealplan-acodn .mealplan-acodn-cont:visible").not($(this).next(".mealplan-acodn-cont")).slideUp("slow");
					$(this).addClass("mp-active");
					$(".mealplan-acodn h4").not($(this)).removeClass("mp-active");
				});	

			}
		});
	});
	
	/**
	  Update Food Item
	**/
	$(document).on('click', '.update-f-item', function (event) {
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
			var short_url ="hindi/";
		} else {
			var short_url = "";
		}	
		var unitq = $(this).parent().prev('.food-unitqty').find(".droplist :selected").val();
		var unitqVal = $(this).parent().prev('.food-unitqty').find(".qty").val();
		var footEntryId = $(this).attr("data-foodentryid");
		var selectedDateval = Drupal.checkPlain($('#edit-food-date').val());
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "update-meal",
			data: {
				food_entry_id: footEntryId,
				fd_quantity_val: unitqVal,
				selectedDateval: selectedDateval,
				fd_serUnit_val: unitq
			},
			beforeSend: function () {
				$(laoderHtml).appendTo(".mealplan-acodn");
			},
			success: function (dataNew) {
				jQuery('.loader').remove(); 
				$(".prgbar-crcl").html(dataNew.eneryarrayhtml);
				$(".nutrient-tips-list").html(dataNew.n_pervct);
				$(".nutrtn-score em").html(dataNew.NutritionScore);

			}
		});
		return false;
	});
	$(document).on('submit', '#get-food-nutrients', function (event) {
		return false;
	
	});
	
})(jQuery, Drupal);
