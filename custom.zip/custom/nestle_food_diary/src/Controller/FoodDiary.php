<?php

namespace Drupal\nestle_food_diary\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\Core\Language\LanguageManager;

/**
 * Defines a controller to fetching records and return food diary data.
 */
class FoodDiary extends ControllerBase {
	

	/**
	* Search meal as per @request.
	*/
	public function searchMeal(Request $request) {
		$hindi = CommonFunc::isHindi();
		$results = [];
		$input = $request->query->get('q');
		$post_data = [
			"name" => $input,
		];
		$post_data = CommonFunc::APiHindi($post_data);
		
		$search = NestleAPI::searchItem($post_data);
		$html ='';
		if($hindi) {
			$noress= "कोई सुझाव नहीं मिला";
		} else {
			$noress = "No suggestion found";
		}
		if ($search != 0) {
			foreach ($search as $data) {
				$item['value'] = $data['id'];
				$item['label'] = $data['name'];
				$item['eng'] = $data['key'];
				$results[] = $item;
				$html .= '<div data-eng="'.$item['eng'].'" data-key="'.$item['value'].'" data-title="'.$item['label'].'" class="searchAutofood srchDataItm">'.$item['label'].'</div>';
			}
		} else {
			$html = '<div data-eng="" data-key="" data-title="" class="srchDataItm" style="color:red;">'.$noress.'</div>';
		}
		return new JsonResponse($html);
	}
	
	/**
	* Get meal unit as per @request.
	*/
	public function mealUnit(Request $request) {
		$id = $request->query->get('key');
		$title = $request->query->get('title');
		$post_data = [
			"name" => $title,
		];
		$post_data = CommonFunc::APiHindi($post_data);
		$search = NestleAPI::searchItem($post_data);
        $html ='';
		$html1 ='';
		if ($search != 0) {
			
			foreach ($search as $key => $data) {
				
				if ($data['id'] == $id) {
					foreach ($data['serving_units'] as $unit) {
						$option['id'] = $unit['id'];
						$option['title'] = $unit['name'];
						$option['eng'] = $unit['key'];
						$html .= '<option data-eng="'.$unit['key'].'" value="'.$unit['id'].'" data-id="'.$unit['id'].'">'.$unit['name'].'</option>';
					}
				}
				
			   
			}
			
			
		}
		$html1 = '<div class="foodlist-item nadded">
                                  <div class="foodlist-item-dtls">
                                    <div class="fooditem-name" data-id="'.$id.'"> <span data-id="'.$id.'">'.$title.'</span>
                                      <p><em></em> <i></i></p>
                                    </div>
                                    <div class="fooditem-dlt" style="display: block;"></div>
                                    <div class="fooditem-edt acive-edt"></div>
                                  </div>
                                  <div class="fooditem-edtbox" style="display: block;">
                                    <div class="food-unitqty">
                                      <div class="fooditem-unit">
                                        <select class="droplist">
                                          '.$html.'
                                        </select>
                                      </div>
                                      <div class="fooditem-qty">
                                        <div class="addminus-form">
                                          <input type="button" value=""  class="minus btn-addminus" />
                                          <input type="text" value="0" class="qty" />
                                          <input type="button" value=""  class="add btn-addminus" />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>';
		

		return new JsonResponse($html1);
	}
	
	/**
	* Load post food diary Nutrition info as per @request.
	*/
	public function loadPostFoodNutrition(Request $request) {

		$selectedDateval = $request->query->get('selectedDateval');
		$selectedDateval = date("d-m-Y", strtotime($selectedDateval));
		$listNutrientData = $this->postFoodNutrietions($selectedDateval);

		return new JsonResponse($listNutrientData);

	}
	
	/**
   * Get Post food Meal Nutrition Information as per @selectedDateval.
   */
  public function postFoodNutrietions($selectedDateval) {
    
    $child_id = CommonFunc::childField('field_child_key');
    $field_participation_key = CommonFunc::childField('field_participation_key');
    $post_data_usr = [
      'client_key' => $child_id,
      'participation_key' => $field_participation_key,
      'from_date' => $selectedDateval,
      'to_date' => $selectedDateval,
    ];
    
    $post_data_usr = CommonFunc::APiHindi($post_data_usr);
    $retrieveData = NestleAPI::retrieveFoodEntry($post_data_usr);
	//echo "<pre>";
	//print_r($retrieveData); die;
    $n_distribution = '';
	$n_distribution11 = '';
	$n_pervct = '';
    $nutritionScore = $retrieveData['contents']['nutrition_index'];
	$eneryarray = array();
	//echo $nutritionScore;
	//die;
    $i = 1;
	
    foreach ($retrieveData['contents']['analysis'] as $nutrition) {
      $nameNutri = $nutrition['name'];
      $consume_prct = $nutrition['consumption_percentage'];
      $fd_rda = $nutrition['rda'];
      $unit_name = $nutrition['unit_name'];
	  $excess_deviation1 = $nutrition['excess_deviation1'];
	  $excess_deviation2 = $nutrition['excess_deviation1'];
	  $shortfall_deviation1 = $nutrition['shortfall_deviation1'];
	  $shortfall_deviation2 = $nutrition['shortfall_deviation2'];
	  $colorClass = '';
	  if($consume_prct < $shortfall_deviation2) {
		  $colorClass = 'redlight-color';
	  } else if (in_array($consume_prct, range($shortfall_deviation1,$shortfall_deviation1))) {
		  $colorClass = 'yellow-color';
	  } else if(in_array($consume_prct, range($shortfall_deviation1,$excess_deviation1))) {
		  $colorClass = 'green-color';
	  } else if($consume_prct > $excess_deviation1) {
		  $colorClass = 'red-color';
	  }
	  //echo "<pre>";
	  //print_r($nutrition); die;
      
       if($i == 1){

          $j = 1;

          $k  = 100;
        }else{

          $j = $i * 100 + 1;

          $k = ($i+1) * 100; 
        }
        

      $nutritionrdm = rand($j, $k);
      $data[] = array('name' =>$nameNutri, 'id' =>$nutritionrdm, 'data-rm' =>$nutritionrdm,  'prectng' =>$consume_prct, 'rda' =>$fd_rda, 'rda_unit' =>$unit_name);
    //  $nutritionrdm = rand(1, 100);
	
      $n_distribution11 .= '<li>
                    <div class="rd"><span>' . $fd_rda . ' ' . $unit_name . '</span><div class="prog-bar-full"></div></div>
                    <div class="cm"><span>' . $consume_prct . '%</span><div class="prog-bar" data-height="' . $consume_prct . '" id="' . $nutritionrdm . '" data-rm="' . $nutritionrdm . '"></div></div>
                    <div class="nm">' . $nameNutri . '</div>
                </li>';
	if($nameNutri == 'Energy') {
		
		$percentrr = ($consume_prct/$fd_rda)*100;
		
		
		$eneryarray = array("energy"=>$fd_rda,"unit"=>$unit_name,"precentage"=>$consume_prct,"newpercentage"=>$percentrr);
		$eneryarrayup = '<div role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="--value:'.$percentrr.';"></div>
                                <div class="prgbar-crcl-val">'.$fd_rda.' '.$unit_name.'</div>';
		
	} else {
		
    $n_distribution .= '<li>
							<span class="brkdwn-prgsbar">
							  <i class="brkdwn-val" style="height: '.$consume_prct.'%"></i>
							</span>
							<span class="brkdwn-text">
							  <em>'.$nameNutri.'</em>
							  <i>'.$fd_rda.' '.$unit_name.'</i>
							</span>
						</li>';	
	}
    $n_pervct .= '<div class="item-tips">
                                  <div class="tips-title">'.$nameNutri.'</div>
                                  <div class="tips-graph">
                                    <div class="tips-graph-box">
                                      <div class="col25"></div>
                                      <div class="col25 '.$colorClass.'" style="width:'.$consume_prct.'%"></div>
                                      <div class="col25"></div>
                                      <div class="col25"></div>
                                    </div>
                                  </div>
                                  <div class="tips-popup">'.$consume_prct.'%</div>
                                </div>';
                $i++;
    }
	
    $listNutrientDataNew['n_distribution'] = $n_distribution;
	$listNutrientDataNew['eneryarray'] = $eneryarray;
	$listNutrientDataNew['eneryarrayhtml'] = $eneryarrayup;
	$listNutrientDataNew['n_pervct'] = $n_pervct;
    $listNutrientDataNew['NutritionChart'] = $data;

    $listNutrientDataNew['NutritionScore'] = $nutritionScore;
	//echo "<pre>";
	//print_r($listNutrientDataNew); die;
	

    return $listNutrientDataNew;
  }
	/**
	* Add food diary meal as per @request.
	*/
	public function addFoodMeal(Request $request) {
		
		$foodId = $request->query->get('foodId');
		$qntId = $request->query->get('qntId');
		$servUnt = $request->query->get('servUnt');
		$timeSltval = $request->query->get('timeSltval');
		$countVal = $request->query->get('countVal');
		$foodTimeVal = $request->query->get('foodTimeVal');
		$selectedDateval = $request->query->get('selectedDateval');
		$mealName = $request->query->get('mealName');
		$selectedDateval = date("d-m-Y", strtotime($selectedDateval));
		
		$child_id = CommonFunc::childField('field_child_key');
        $field_participation_key = CommonFunc::childField('field_participation_key');
		$post_data = [
			'client_key' => $child_id,
			'participation_key' => $field_participation_key,
			'food_id' => $foodId,
			'quantity' => $qntId,
			'unit_id' => $servUnt,
			'entry_date' => $selectedDateval,
			'time_in_minutes' => $timeSltval,
			'alias' => $mealName
		];
		$post_data = CommonFunc::APiHindi($post_data);
        $addFoodMeal = NestleAPI::addFoodEntry($post_data);
		$post_data_usr = [
			'client_key' => $child_id,
			'participation_key' => $field_participation_key,
			'from_date' => $selectedDateval,
			'to_date' => $selectedDateval,
		];
		$post_data_usr = CommonFunc::APiHindi($post_data_usr);
        $retrieveData = NestleAPI::retrieveFoodEntry($post_data_usr);
		$n_distribution = '';
		$eneryarray = array();
	    $n_pervct = '';
        $nutritionScore = $retrieveData['contents']['nutrition_index'];
		 $i = 1;
	   $foodEntryId = end($retrieveData['contents']['meal_entries'][$selectedDateval][$foodTimeVal]);
	   $finalFoodEntryId = $foodEntryId['food_entry_id'];
       foreach ($retrieveData['contents']['analysis'] as $nutrition) {
         $nameNutri = $nutrition['name'];
         $consume_prct = $nutrition['consumption_percentage'];
         $fd_rda = $nutrition['rda'];
         $unit_name = $nutrition['unit_name'];
		 $excess_deviation1 = $nutrition['excess_deviation1'];
		$excess_deviation2 = $nutrition['excess_deviation1'];
		$shortfall_deviation1 = $nutrition['shortfall_deviation1'];
		$shortfall_deviation2 = $nutrition['shortfall_deviation2'];
		$colorClass = '';
		if($consume_prct < $shortfall_deviation2) {
		$colorClass = 'redlight-color';
		} else if (in_array($consume_prct, range($shortfall_deviation1,$shortfall_deviation1))) {
		$colorClass = 'yellow-color';
		} else if(in_array($consume_prct, range($shortfall_deviation1,$excess_deviation1))) {
		$colorClass = 'green-color';
		} else if($consume_prct > $excess_deviation1) {
		$colorClass = 'red-color';
		}
      
		   if($i == 1){

			  $j = 1;

			  $k  = 100;
			}else{

			  $j = $i * 100 + 1;

			  $k = ($i+1) * 100; 
			}
        

         $nutritionrdm = rand($j, $k);
         $data[] = array('name' =>$nameNutri, 'id' =>$nutritionrdm, 'data-rm' =>$nutritionrdm,  'prectng' =>$consume_prct, 'rda' =>$fd_rda, 'rda_unit' =>$unit_name);
         //  $nutritionrdm = rand(1, 100);
	
         $n_distribution11 .= '<li>
                    <div class="rd"><span>' . $fd_rda . ' ' . $unit_name . '</span><div class="prog-bar-full"></div></div>
                    <div class="cm"><span>' . $consume_prct . '%</span><div class="prog-bar" data-height="' . $consume_prct . '" id="' . $nutritionrdm . '" data-rm="' . $nutritionrdm . '"></div></div>
                    <div class="nm">' . $nameNutri . '</div>
                </li>';
	     if($nameNutri == 'Energy') {
		     $percentrr = ($consume_prct/$fd_rda)*100;
		    $eneryarray = array("energy"=>$fd_rda,"unit"=>$unit_name,"precentage"=>$consume_prct,"newpercentage"=>$eneryarray);
			$eneryarrayup = '<div role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="--value:'.$percentrr.';"></div>
                                <div class="prgbar-crcl-val">'.$fd_rda.' '.$unit_name.'</div>';
		
	     } else {
		
           $n_distribution .= '<li>
							<span class="brkdwn-prgsbar">
							  <i class="brkdwn-val" style="height: '.$consume_prct.'%"></i>
							</span>
							<span class="brkdwn-text">
							  <em>'.$nameNutri.'</em>
							  <i>'.$fd_rda.' '.$unit_name.'</i>
							</span>
						</li>';	
	     }
		 
         $n_pervct .= '<div class="item-tips">
                                  <div class="tips-title">'.$nameNutri.'</div>
                                  <div class="tips-graph">
                                    <div class="tips-graph-box">
                                      <div class="col25"></div>
                                      <div class="col25 '.$colorClass.'" style="width:'.$consume_prct.'%"></div>
                                      <div class="col25"></div>
                                      <div class="col25"></div>
                                    </div>
                                  </div>
                                  <div class="tips-popup">'.$consume_prct.'%</div>
                                </div>';
                $i++;
         }
		 
		$listNutrientDataNew['n_distribution'] = $n_distribution;
		$listNutrientDataNew['eneryarrayup'] = $eneryarrayup;
		$listNutrientDataNew['n_pervct'] = $n_pervct;
		$listNutrientDataNew['NutritionChart'] = $data;
        $listNutrientDataNew['foodEntryFinalId'] = $finalFoodEntryId;
		$listNutrientDataNew['NutritionScore'] = $nutritionScore;
		return new JsonResponse ($listNutrientDataNew);
	   
	}
	
	/**
	* Delete food diary meal as per @request.
	*/
	public function deleteFoodMeal(Request $request) {
		$foodId = $request->query->get('food_entry_id');
		$selectedDateval = $request->query->get('selectedDateval');
		$selectedDateval = date("d-m-Y", strtotime($selectedDateval));
		$child_id = CommonFunc::childField('field_child_key');
        $field_participation_key = CommonFunc::childField('field_participation_key');

		$post_data = [
			'client_key' => $child_id,
			'participation_key' => $field_participation_key,
			'food_entry_id' => $foodId,
		];
		 $post_data = CommonFunc::APiHindi($post_data);
         $updateFoodMeal = NestleAPI::deleteFoodEntry($post_data);

         $listNutrientData = $this->postFoodNutrietions($selectedDateval);

         return new JsonResponse($listNutrientData);
	}
	
	/**
	* Edit food diary meal as per @request.
	*/
	public function updateFoodMeal(Request $request) {
		$foodId = $request->query->get('food_entry_id');
		$qntId = $request->query->get('fd_quantity_val');
		$servUnt = $request->query->get('fd_serUnit_val');
		$selectedDateval = $request->query->get('selectedDateval');
		$selectedDateval = date("d-m-Y", strtotime($selectedDateval));
		
		$child_id = CommonFunc::childField('field_child_key');
		$field_participation_key = CommonFunc::childField('field_participation_key');
		
		$post_data = [
			'client_key' => $child_id,
			'participation_key' => $field_participation_key,
			'food_entry_id' => $foodId,
			'quantity' => $qntId,
			'unit_id' => $servUnt,
		];
		$post_data = CommonFunc::APiHindi($post_data);
        $updateFoodMeal = NestleAPI::updateFoodEntry($post_data);
		$listNutrientData = $this->postFoodNutrietions($selectedDateval);
		 return new JsonResponse($listNutrientData);
	}


 

}
