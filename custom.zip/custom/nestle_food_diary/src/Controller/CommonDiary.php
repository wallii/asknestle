<?php

namespace Drupal\nestle_food_diary\Controller;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\taxonomy\Entity\Term;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;

/**
 * This class have all common functions which are using in the CMS.
 */
class CommonDiary extends ControllerBase {

	/**
	* Get Post food Meal DOM Data.
	*/
	public static function foodDiaryDom($timeslotRecipes, $key, $fd_time, $gtm_array) {
		$hindi = CommonFunc::isHindi();
		$meal_term = '';
		if ($hindi) {
			$update = 'मील अपडेट करें';
			$add= 'मील आइटम जोड़ें';
			$search_food='भोजन खोजो';
			$serving_unit='सर्विंग यूनिट';
		} else {
			$update = 'Update Meal Item';
			$add= 'Add Meal Item';
			$search_food='Search Food';
			$serving_unit='Serving Unit';
		} 
		$countslotRecipe = 0;
		if (isset($timeslotRecipes) && count($timeslotRecipes) > 0) {
			$meal_term = '';
			foreach ($timeslotRecipes as $keyTime => $valueTime) {
				
				$nameslotrecipe = $valueTime['name'];
				$nameslotrecipe_eng = $gtm_array[$countslotRecipe]['name'];
				$qntslotrecipe = $valueTime['quantity'];
				$selected_unit = $valueTime['selected_unit'];
				$food_entry_id = $valueTime['food_entry_id'];
				$optionUnit = '';
				
				foreach ($valueTime['serving_units'] as $keyunit => $valueunit) {
					
					if ($gtm_array[$countslotRecipe]['selected_unit']['id'] == $valueunit['id']) {
						$unit_val = $gtm_array[$countslotRecipe]['selected_unit']['name'];
					} 
					else {
						$unit_val = '';
					}
					
					if ($selected_unit['id'] == $valueunit['id']) {
						$optionUnit .= '<option data-eng="'.$valueunit['key'].'" value="' . $valueunit['id'] . '" selected>' . $valueunit['name'] . '</option>';
					}
					else {
						$optionUnit .= '<option data-eng="'.$valueunit['key'].'" value="' . $valueunit['id'] . '">' . $valueunit['name'] . '</option>';
					}
				}
				$meal_term .= '<div class="foodlist-item '.$valueTime['food_entry_id'].'" data-foodentryid="'.$valueTime['food_entry_id'].'">
                              <div class="foodlist-item-dtls">
                                    <div class="fooditem-name"> <span>'.$nameslotrecipe.'</span>
                                      <p><em>'.$unit_val.'</em> <i>'.$qntslotrecipe.'</i></p>
                                    </div>
                                    <div class="fooditem-dlt" data-foodentryid="'.$valueTime['food_entry_id'].'"></div>
                                    <div class="fooditem-edt" data-foodentryid="'.$valueTime['food_entry_id'].'"></div>
                                  </div>
								  <div class="fooditem-edtbox">
                                    <div class="food-unitqty">
                                      <div class="fooditem-unit">
                                        <select class="droplist">
                                          '.$optionUnit.'
                                        </select>
                                      </div>
                                      <div class="fooditem-qty">
                                        <div class="addminus-form">
                                          <input type="button" value=""  class="minus btn-addminus" />
                                          <input type="text" value="'.$qntslotrecipe.'" class="qty" />
                                          <input type="button" value=""  class="add btn-addminus" />
                                        </div>
                                      </div>
                                    </div>
									<div class="btn-add">
                                  <button id="" class="secnd-button update-f-item" data-foodentryid="'.$valueTime['food_entry_id'].'">'.$update.'</button>
                                 </div>
                                  </div>
								 ';
				$meal_term .= '</div>';
				
				 
			}
			
		} 
	  return $meal_term;
	}
	/**
	* Defines a controller to load log meal datewise data.
	*/
	public function loadPostDateNutrition(Request $request) {
		$hindi = CommonFunc::isHindi();
		$meal_term = array();
		$FoodDiaryobj = new FoodDiary;
		$selectedDateval = $request->query->get('selectedDateval');
		$selectedDate = date("d-m-Y", strtotime($selectedDateval));
	    $child_id = CommonFunc::childField('field_child_key');
		$field_participation_key = CommonFunc::childField('field_participation_key');
		$post_data = [
			'client_key' => $child_id,
			'participation_key' => $field_participation_key,
			'from_date' => $selectedDate,
			'to_date' => $selectedDate,
		];
		$post_data = CommonFunc::APiHindi($post_data);
		$addFoodMeal = NestleAPI::retrieveFoodEntry($post_data);
		$getFoodexist_gtm = $addFoodMeal['contents']['gtm']['recipes'];
		if (isset($addFoodMeal['contents']['meal_entries'][$selectedDate])) {

		foreach ($addFoodMeal['contents']['meal_entries'][$selectedDate] as $keytime => $valuetime) {

		$timeslotRecipes[$keytime] = $valuetime;
		}
		}
		if($timeslotRecipes) {
			ksort($timeslotRecipes);
		}
		
		if (!empty($child_id)) {
		$date = $field_child_dob;
		$ageGet = CommonFunc::calculateYearMonth($date);
		$years = $ageGet['year'];
        $months = $ageGet['month'];
		$age = $years . '.' . $months;
		$tid = \Drupal::entityQuery('taxonomy_term')
          ->condition('vid', 'diary_timing')
          ->sort('weight', 'ASC')
          ->execute();
        $tids = Term::loadMultiple($tid);

        $options = [];
		foreach ($tids as $term) {
          $term = CommonFunc::multilingualConvert("entity",$term);
          $options[$term->id()] = $term->getName();
        }
		$foodTime = CommonFunc::getFoodTime($options, $age);
		
		$inc = 0;
		//echo "<pre>";
		//print_r($foodTime); die;
		$meal_term1 ='';
		foreach ($foodTime as $key => $value) {
			$time_term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($key);
			$eng_name = strip_tags($time_term->description->value);
			$fd_time = $time_term->get('field_diary_value')->value;
			
			$meal_term1 .= '<div class="acrdrow_repeat"> 
                      <h4 eng="'.$eng_name.'"><i class="early-morning-icon"></i><span>'.$value.'</span></h4>
                      <div class="mealplan-acodn-cont">
                        <div class="box-fg">
                          <div class="box-fginr">
                            <div class="add-foodlist">
                              <div class="src-hd">What did you have - '.$value.'?</div>
                              <div class="foodlist-search">
                                <div class="srch-fltrs"> <span class="srchfltr-btn"></span>
                                  <input name="search_meal_frm_'.$key.'_'.$inc.'" id="search_meal_frm_'.$key.'_'.$inc.'" data-key="'.$key.'_'.$inc.'" type="text" placeholder="'.$search_food.'" class="srchfld search_meal_cls">
                                </div>
								<div class="replacesearchData_'.$key.'_'.$inc.' replaceslist" data-key="'.$key.'_'.$inc.'"></div>
                              </div>
                              <div class="foodlist-items-row foodlist-items-row_'.$key.'_'.$inc.'" data-foodTime="'.$fd_time.'">';
			$meal_term1 .= $this->foodDiaryDom($timeslotRecipes[$fd_time], $key, $fd_time, $getFoodexist_gtm);;  
            $meal_term1 .=   '</div>
                              <div class="btn-add">
							    <input type="hidden" name= "fd_time_val_' . $key . '_' . $inc . '" value="' . $fd_time . '" id="fd_time_val_' . $key .'_' . $inc . '" class ="" >
                                <button class="primary-button addfoodmeal" data-id="'.$key.'_'.$inc.'" disabled="true" id="bn_'.$key.'_'.$inc.'">Add Meal Item</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div></div>';
			
            
			//echo "<pre>";
            //print_r($eng_name);	die;
             $inc++;			
	
		}
		
	  }
	  
	  $nutitionDistribution = $FoodDiaryobj->postFoodNutrietions($selectedDate);
	  $meal_term['acrdrow_repeat'] = $meal_term1;
	  $meal_term['n_distribution'] = $nutitionDistribution['n_distribution'];
	  $meal_term['eneryarrayhtml'] = $nutitionDistribution['eneryarrayhtml'];
	  $meal_term['NutritionScore'] = $nutitionDistribution['NutritionScore'];
	  //echo "<pre>";
	  //print_r($nutitionDistribution['n_pervct']); die;
	  $meal_term['n_pervct'] = $nutitionDistribution['n_pervct'];
	  return new JsonResponse($meal_term);
	  
		
	}

}
