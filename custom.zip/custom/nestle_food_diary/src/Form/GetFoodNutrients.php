<?php

namespace Drupal\nestle_food_diary\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\nestle_food_diary\Controller\CommonDiary;
use Drupal\nestle_food_diary\Controller\FoodDiary;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Drupal\Core\Language\LanguageManager;

/**
 * Form to handle food diary form functionality.
 */
class GetFoodNutrients extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {

    return 'get_food_nutrients';
  }

  /**
   * Food diary filling form with session management.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $base_url;

    $hindi = CommonFunc::isHindi();
    $CommonDiaryobj = new CommonDiary;
	$FoodDiaryobj = new FoodDiary;
    if (\Drupal::currentUser()->isAnonymous()) {
      if ($hindi) {
        CommonFunc::redirectPage($base_url.'/hindi/login');
      } 
      else {
        CommonFunc::redirectPage($base_url.'/login');
      }
      
    }
    else {
		if ($hindi) {
			$update = 'मील अपडेट करें';
			$add= 'मील आइटम जोड़ें';
			$search_food='भोजन खोजो';
			$serving_unit='सर्विंग यूनिट';
			$whatdoyouvae ='तुम्हारे पास क्या है ';
		} 
		else {
			 $update = 'Update Meal Item';
			$add= 'Add Meal Item';
			$search_food='Search Food';
			$serving_unit='Serving Unit';
			$whatdoyouvae ='What did you have';
		}
		$dateintervals = CommonFunc::getDayIntervals('d-m-Y', '7');
        
      $child_id = CommonFunc::childField('field_child_key');
	 
	  $field_participation_key = CommonFunc::childField('field_participation_key');
	  $field_child_dob = '2013-09-05';
	  $selectedDate = date("d-m-Y");
	  $post_data = [
        'client_key' => $child_id,
        'participation_key' => $field_participation_key,
        'from_date' => $selectedDate,
        'to_date' => $selectedDate,
      ];
	  $post_data = CommonFunc::APiHindi($post_data);
	  $addFoodMeal = NestleAPI::retrieveFoodEntry($post_data);
      $getFoodexist_gtm = $addFoodMeal['contents']['gtm']['recipes'];
      $timeslotRecipes= [];
	  if (isset($addFoodMeal['contents']['meal_entries'][$selectedDate])) {

        foreach ($addFoodMeal['contents']['meal_entries'][$selectedDate] as $keytime => $valuetime) {

          $timeslotRecipes[$keytime] = $valuetime;
        }
      }
	  if ($timeslotRecipes) {
		 ksort($timeslotRecipes);
	  }
	  
      if (!empty($child_id)) {
		$date = $field_child_dob;
		$ageGet = CommonFunc::calculateYearMonth($date);
		$years = $ageGet['year'];
        $months = $ageGet['month'];
		$age = $years . '.' . $months;
		$tid = \Drupal::entityQuery('taxonomy_term')
          ->condition('vid', 'diary_timing')
          ->sort('weight', 'ASC')
          ->execute();
        $tids = Term::loadMultiple($tid);

        $options = [];
		foreach ($tids as $term) {
          $term = CommonFunc::multilingualConvert("entity",$term);
          $options[$term->id()] = $term->getName();
        }
		$foodTime = CommonFunc::getFoodTime($options, $age);
		
		$inc = 0;
		
		
		foreach ($foodTime as $key => $value) {
			$time_term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($key);
			$eng_name = strip_tags($time_term->description->value);
			$fd_time = $time_term->get('field_diary_value')->value;
			
			$meal_term[$key] = '<div class="acrdrow_repeat"> 
                      <h4 eng="'.$eng_name.'"><i class="early-morning-icon"></i><span>'.$value.'</span></h4>
                      <div class="mealplan-acodn-cont">
                        <div class="box-fg">
                          <div class="box-fginr">
                            <div class="add-foodlist">
                              <div class="src-hd">'.$whatdoyouvae.' - '.$value.'?</div>
                              <div class="foodlist-search">
                                <div class="srch-fltrs"> <span class="srchfltr-btn"></span>
                                  <input name="search_meal_frm_'.$key.'_'.$inc.'" id="search_meal_frm_'.$key.'_'.$inc.'" data-key="'.$key.'_'.$inc.'" type="text" placeholder="'.$search_food.'" class="srchfld search_meal_cls" autocomplete="off">
                                 <div class="srchData-outr fooddiarysrchdispaly" style="display:none;">
								 <div class="replacesearchData_'.$key.'_'.$inc.' replaceslist srchData" data-key="'.$key.'_'.$inc.'"></div>
								 </div>
								</div>
								
                              </div>
                              <div class="foodlist-items-row foodlist-items-row_'.$key.'_'.$inc.'" data-foodTime="'.$fd_time.'">';
				if(isset($timeslotRecipes[$fd_time])) {
					$meal_term[$key] .= $CommonDiaryobj->foodDiaryDom($timeslotRecipes[$fd_time], $key, $fd_time, $getFoodexist_gtm);
				}			  
			  
            $meal_term[$key] .=   '</div>
                              <div class="btn-add">
							    <input type="hidden" name= "fd_time_val_' . $key . '_' . $inc . '" value="' . $fd_time . '" id="fd_time_val_' . $key .'_' . $inc . '" class ="" >
                                <button class="primary-button addfoodmeal" data-id="'.$key.'_'.$inc.'" disabled="true" id="bn_'.$key.'_'.$inc.'">Add Meal Item</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div></div>';
			
            
             $inc++;			
	
		}
		
	  }	
	  $todayDate = date("d-m-Y");
	  $nutitionDistribution = $FoodDiaryobj->postFoodNutrietions($todayDate);
	  
	  if(isset($nutitionDistribution['NutritionChart'])) {
		 $meal_term['n_nutritionChart'] = $nutitionDistribution['NutritionChart']; 
	  } else {
		  $meal_term['n_nutritionChart'] = '';
	  }
	  if (isset($nutitionDistribution['n_distribution'])) {
		  $meal_term['n_distribution'] = $nutitionDistribution['n_distribution'];
	  } else {
		  $meal_term['n_distribution'] = '';
	  }
	 
	  $meal_term['NutritionScore'] = $nutitionDistribution['NutritionScore'];
	  
	  if(isset($nutitionDistribution['n_pervct'])) {
		 $meal_term['n_pervct'] = $nutitionDistribution['n_pervct']; 
	  } else {
		 $meal_term['n_pervct'] = ''; 
	  }
	  if(isset($nutitionDistribution['eneryarray'])) {
		 $meal_term['eneryarray'] = $nutitionDistribution['eneryarray']; 
	  } else {
		 $meal_term['eneryarray'] = ''; 
	  }
	  
      $meal_term['dateData'] = $dateintervals;	  
      $meal_term['welcomemsg'] = CommonFunc::getConfigPageFieldValue('nestle_food_diary', 'field_inner_welcome');
	  $meal_term['welcomeheading'] = CommonFunc::getConfigPageFieldValue('nestle_food_diary', 'field_subheading');
	  $meal_term['nutri_info'] = CommonFunc::getConfigPageFieldValue('nestle_food_diary', 'field_heading_1');
	  $meal_term['immunoscla_inner_desc'] = CommonFunc::getConfigPageFieldValue('nestle_food_diary', 'field_inner_desclaimer');
	  $meal_term['footer_desc'] = CommonFunc::getConfigPageFieldValue('nestle_food_diary', 'field_footer_disclaimer');
    
	  $meal_term['postData'] = $meal_term;
	  $form['meal_type'] = [
        '#markup' => $meal_term,
      ];
	  
	  
		$form['food_date'] = [
		'#type' => 'date',
		'#title' => t(''),
		'#attributes' => [
		    'min' =>  \Drupal::service('date.formatter')->format(REQUEST_TIME, 'custom', date('Y-m-d', strtotime('-6 days'))),
			'max' =>  \Drupal::service('date.formatter')->format(REQUEST_TIME, 'custom', 'Y-m-d'),
			'class' => array('caldr-fild')
        ],
	    '#default_value' => \Drupal::service('date.formatter')->format(REQUEST_TIME, 'custom', 'Y-m-d')
		];
      $form['#meal_type_val'] = $form['meal_type']["#markup"];
      $form['#theme'] = 'GetRegUserFoodNutrients';
      $form['#hindi'] = $hindi;
      $form['#attached']['library'][] = 'nestle_food_diary/food_diary';
      return $form;
    }
  }
  
  /**
   * Submit food diary form and set variables.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }


}
