(function ($, Drupal) {
	Drupal.behaviors.loadmoreRecipe = {
    attach: function (context) {
	
		function hindiUrl(){
			var lang = drupalSettings.path.currentLanguage;
			if (lang == "hi") {
				var short_url = "hindi/";
			} 
			else {
				var short_url = "";
			}
			return short_url;
		}
		
		 var laoderHtml = '<div class="loader"><span></span></div>';
		$("#morerecipe",context).on("click", function () {
			 var short_url = hindiUrl();
			 var pageCounterCheck = Drupal.checkPlain($("#rowCount").val());
			 var catKey = $(".rcips-list").attr("data-key");
			//$(laoderHtml).appendTo(".rcips-list");
			var counterInce = parseInt(pageCounterCheck)+1;
			$("#rowCount").val(counterInce);
			if ($(".rcips-list").attr('data-filter') == 'Applied2') {
				let ingerContainer = document.getElementById("ing_srchadded");
				let spans = ingerContainer.getElementsByTagName("span");
				let allingId = new Array();
				for (let span of spans) {
				  allingId.push($(span).attr('data-id'));  
			    }
				/**
			    get Cuisine Value
			    **/
				let cuisine = new Array();
			    $('input[name="cuisine"]:checked').each(function() {
				 cuisine.push(this.value);
			    });
				/**
			    get Preferences Value
			    **/
				let preferences = new Array();
			    $('input[name="preferences"]:checked').each(function() {
				   preferences.push(this.value);
			    });
				$.ajax({
				dataType: "json",
				url: drupalSettings.path.baseUrl + short_url +"filter-recipes",
				data: { allingId: allingId, cuisine: cuisine, catKey: catKey, preferences: preferences, pageNo: counterInce,ajax:"ajaxCall" },
				beforeSend: function() {
					$(laoderHtml).appendTo(".rcips-list");
				},
				success: function (filterecipelist) {
					 var divItemlength = filterecipelist.split('<div').length;
					 if (divItemlength < 121) {
						 $("#morerecipe").hide();
					 } else {
						 $("#morerecipe").show();
					 }
					 if($("#rowCount").val()==1) {
						 $(".rcips-list").html(filterecipelist);
					 } else {
						 $(".rcips-list").append(filterecipelist);
					 }
					$(".rcips-list").attr('data-filter','Applied2'); 
					$(".loader").remove();
					
				 },
			    });
			} else if($(".rcips-list").attr('data-filter') == 'Applied3') {
				let ingerContainer = document.getElementById("ing_srchadded");
				let spans = ingerContainer.getElementsByTagName("span");
				let allingId = new Array();
				for (let span of spans) {
				  allingId.push($(span).attr('data-id'));  
			    }
				/**
			    get Cuisine Value
			    **/
				let cuisine = new Array();
			    $('input[name="cuisine"]:checked').each(function() {
				 cuisine.push(this.value);
			    });
				/**
			    get Preferences Value
			    **/
				let preferences = new Array();
			    $('input[name="preferences"]:checked').each(function() {
				   preferences.push(this.value);
			    });
				var timeSlotRecipeVala = $("#timeslot_recipe").val();
				var timeSlotrecipeTimea = $("#timeslopt_recipe_time").val();
				
				$.ajax({
				dataType: "json",
				url: drupalSettings.path.baseUrl + short_url +"filter-recipes",
				data: { time_slot: timeSlotRecipeVala, time_too_cook: timeSlotrecipeTimea,   allingId: allingId, cuisine: cuisine, catKey: catKey, preferences: preferences, pageNo: counterInce,ajax:"ajaxCall" },
				beforeSend: function() {
					$(laoderHtml).appendTo(".rcips-list");
				},
				success: function (filterecipelist) {
					 var divItemlength = filterecipelist.split('<div').length;
					 if (divItemlength < 121) {
						 $("#morerecipe").hide();
					 } else {
						 $("#morerecipe").show();
					 }
					 if($("#rowCount").val()==1) {
						 $(".rcips-list").html(filterecipelist);
					 } else {
						 $(".rcips-list").append(filterecipelist);
					 }
					$(".rcips-list").attr('data-filter','Applied2'); 
					$(".loader").remove();
					
				 },
			    });
				
			}else if ($(".rcips-list").attr('data-filter') == 'Applied1'){
				
				var timeSlotRecipeVala = $("#timeslot_recipe").val();
				var timeSlotrecipeTimea = $("#timeslopt_recipe_time").val();
				var catKey = $(".rcips-list").attr("data-key");
			   
				$.ajax({
				dataType: "json",
				url: drupalSettings.path.baseUrl + short_url +"filter-recipes",
				data: { time_slot: timeSlotRecipeVala, time_too_cook: timeSlotrecipeTimea, catKey: catKey, pageNo: counterInce,ajax:"ajaxCall" },
				beforeSend: function() {
                  $(laoderHtml).appendTo(".rcips-list");
                },
				success: function (filterecipelist) {
					 var divItemlength = filterecipelist.split('<div').length;
					 if (divItemlength < 121) {
						 $("#morerecipe").hide();
					 } else {
						 $("#morerecipe").show();
					 }
					 if($("#rowCount").val()==1) {
						 $(".rcips-list").html(filterecipelist);
					 } else {
						 $(".rcips-list").append(filterecipelist);
					 }
					$(".rcips-list").attr('data-filter','Applied1'); 
					$(".loader").remove();
					
				 },
			    });	
				
			} else {
				$.ajax({
				dataType: "json",
				url: drupalSettings.path.baseUrl + short_url +"recipes-list",
				data: { catName: catKey, pageNo: counterInce,ajax:"ajaxCall" },
				beforeSend: function() {
                  $(laoderHtml).appendTo(".rcips-list");
                },
				success: function (catrecipelist) {
					 var divItemlength = catrecipelist.split('<div').length;
					 if (divItemlength < 121) {
						 $("#morerecipe").hide();
					 } else {
						 $("#morerecipe").show();
					 }
					 $(".rcips-list").append(catrecipelist);
					 $(".loader").remove();
					
				  },
			   });
				
			}
        
      });
     
    }
  };
  
 /** Recipe search code **/  
	function sendToLink(link) {
		location.replace(Drupal.checkPlain(link));
	}
	var lang = drupalSettings.path.currentLanguage;
	var baseurl = drupalSettings.path.baseUrl;
	$("#recipes-search").on("keyup", function () {
		$(this).addClass('searchrecipes');
		var keyword = Drupal.checkPlain($(this).val().toLowerCase());
		if (keyword != '') {
			$.ajax({
				url: drupalSettings.path.baseUrl + "ajax/set-ajax",
				type: "post",
				cache: false,
				data: {
					action: "searchBykeyword",
					keyword: keyword,
					language: drupalSettings.path.currentLanguage,
				},
				success: function (recipe_list) {
					if(recipe_list == '') {
					
					 $('.replaceslist').hide();
			         $(".recipesearchdisplay").hide();	
					} else {
						$(".recipesearchdisplay").show();
					    $('.replaceslist').show();
					}
					$('.replaceslist').html(recipe_list);
					$(this).toggle($(this).text().toLowerCase().indexOf(keyword) > -1);
					
				},
			});
		} else {
			$('.replaceslist').hide();
			$(".recipesearchdisplay").hide();
		}
	});
	$(document).on('click', '.searchAutofood', function () {
		var Atrvalue = $(this).attr('data-title');
		$("#recipes-search").val(Atrvalue);
		$('.replaceslist').hide();
		var e = $.Event("keydown", { keyCode: 13 });
		$("#recipes-search").trigger(e);
	});
	$(document).on('click', '.searchAutofood', function () {
		var Atrvalue = $(this).attr('data-title');
		$("#recipes-filter").val(Atrvalue);
		$('.replaceslist').hide();
		var e = $.Event("keydown", { keyCode: 13 });
		$("#recipes-filter").trigger(e);
	});
	$( "#recipes-search" ).keydown(function(e) {
		if (e.keyCode === 13) {
			var serachVal = $('#recipes-search').val();
			if (serachVal) {
			serachVal = serachVal.trim();
			}
            var baseurl = window.location.origin;
			var hindiurl = "/";
			if (serachVal) {
			if (lang === "hi") {
				hindiurl = "/hindi/";
			}
			serachValrecipe = serachVal.replace(/\s/g, ''.length);
			if (serachValrecipe.length !== 0) {
				$(".recipesearchdisplay").hide();
				sendToLink(baseurl + hindiurl + "recipes-search?searchRecData=" + serachVal);
			} else {
				$('#recipes-search').css('border-color', 'red');
			}
			} else {
			$('#recipes-search').css('border-color', 'red');
			}
		}
	});
	$( "#recipesearchid" ).click(function(e) {

		
			var serachVal = $('#recipes-search').val();
			if (serachVal) {
			serachVal = serachVal.trim();
			}

			var hindiurl = "";
			if (serachVal) {
			if (lang === "hi") {
				hindiurl = "/hindi/";
			}
			serachValrecipe = serachVal.replace(/\s/g, ''.length);
			if (serachValrecipe.length !== 0) {
				$(".recipesearchdisplay").hide();
				sendToLink(baseurl + hindiurl + "recipes-search?searchRecData=" + serachVal);
			} else {
				$('#recipes-search').css('border-color', 'red');
			}
			} else {
			$('#recipes-search').css('border-color', 'red');
			}
		
	});

   
 
 /** 
  Advanced Filter
 **/ 

	function hindiUrl(){
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
			var short_url = "hindi/";
		} 
		else {
			var short_url = "";
		}
		return short_url;
	}
	var short_url = hindiUrl();
	var lang = drupalSettings.path.currentLanguage;
	var baseurl = drupalSettings.path.baseUrl;
	var laoderHtml = '<div class="loader"><span></span></div>';
	$("#recipe_ing_srch").on("keyup", function () {
		
		var searchString = $(this).val().trim();
		var serachingre = searchString.replace(/\s/g, ''.length);
		if (serachingre.length !== 0) {
			if (serachingre.length >= 4) {
				$('#recipe_ing_srch').css('border-color', '');
				$.ajax({
					url: drupalSettings.path.baseUrl + "ajax/set-ajax",
					type: "post",
					cache: false,
					data: {
						action: "searchIngredientRecipe",
						keyword: serachingre,
						language: drupalSettings.path.currentLanguage,
					},
					success: function (ingredient_list) {
						$('.replacesInglist').html(ingredient_list);
						$(".ingddisplay").show();
						$('.replacesInglist').show();

					},
				}); 
			} else {
				$('.replacesInglist').html(''); 
				$(".ingddisplay").hide();
			}
		} else {
			$('#recipe_ing_srch').css('border-color', 'red');
			$('.replacesInglist').html('');
			$(".ingddisplay").hide();
		}

	});
	$(document).on('click', '.searchAutoIng', function () {
		var Atrvalue = $(this).attr('data-title');
		var AtrId = $(this).attr('data-key');
		var lHtml = '<span data-id="'+AtrId+'" data-title="'+Atrvalue+'">'+Atrvalue+'<i class="choice-remove"></i></span>';
		$("#ing_srchadded").append(lHtml);
		$(this).remove();
		$(".ingddisplay").hide();
		$("#recipe_ing_srch").val('');				
	});
	$(document).on('click', '.choice-remove', function () {
		$(this).parent().remove();	
	});
	/**
	Check only One couisine at a time code
	Multiple select cuisine api not work
	**/
	$(document).on('click', '.cuisine_select', function () {
		$('.cuisine_select').not(this).prop('checked', false);
	});
	/**
	Check only One Preferences at a time code
	Multiple select Preferences api not work
	**/
	$(document).on('click', '.preferences_select', function () {
		$('.preferences_select').not(this).prop('checked', false);
	});
	$(document).on('click', '#submitRecipeFilter', function () {
		
	    let ingerContainer = document.getElementById("ing_srchadded");
		let spans = ingerContainer.getElementsByTagName("span");
		let allingId = new Array();
		
		for (let span of spans) {
			allingId.push($(span).attr('data-id'));
        }
		/**
		get Cuisine Value
		**/
		let cuisine = new Array();
		$('input[name="cuisine"]:checked').each(function() {
			cuisine.push(this.value);
		});
		/**
		get Preferences Value
		**/
		let preferences = new Array();
		$('input[name="preferences"]:checked').each(function() {
			preferences.push(this.value);
		});
		$("#rowCount").val(1);
		
		if($(".rcips-list").attr('data-filter') == 'Applied1') {
			
			var timeSlotRecipeVal1 = $("#timeslot_recipe").val();
		    var timeSlotrecipeTime1 = $("#timeslopt_recipe_time").val();
			
		} else if ($(".rcips-list").attr('data-filter') == 'Applied3'){
			var timeSlotRecipeVal1 = $("#timeslot_recipe").val();
		    var timeSlotrecipeTime1 = $("#timeslopt_recipe_time").val();
		} else {
			var timeSlotRecipeVal1 = '';
		    var timeSlotrecipeTime1 = '';
		}
		var catKey = $(".rcips-list").attr("data-key");
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url +"filter-recipes",
			data: { allingId: allingId, cuisine: cuisine, catKey: catKey, preferences: preferences, time_slot: timeSlotRecipeVal1, time_too_cook: timeSlotrecipeTime1, pageNo: 1,ajax:"ajaxCall" },
			beforeSend: function() {
              $(laoderHtml).appendTo(".rcips-list");
            },
			success: function (filterecipelist) {
				var divItemlength = filterecipelist.split('<div').length;
				 if (divItemlength < 121) {
					 $("#morerecipe").hide();
				 } else {
					 $("#morerecipe").show();
				 }
				 $("#rowCount").val(1);
				
					 $(".rcips-list").html(filterecipelist);
				 
				 if($(".rcips-list").attr('data-filter') == 'Applied1') {
					 $(".rcips-list").attr('data-filter','Applied3'); 
				 } else if ($(".rcips-list").attr('data-filter') == 'Applied3') {
					$(".rcips-list").attr('data-filter','Applied3');  
				 } else {
					$(".rcips-list").attr('data-filter','Applied2'); 
				 }
				
				$(".loader").remove();

			},
		});

		   

	});
	
	$(document).on('click', '#mobsubmitRecipeFilter', function () {
		
		$(".rcps-lft-col").removeClass("open-fltr");		
        $("body").removeClass("ovlfw-hdn");	
		
	    let ingerContainer = document.getElementById("ing_srchadded");
		let spans = ingerContainer.getElementsByTagName("span");
		let allingId = new Array();
		
		for (let span of spans) {
			allingId.push($(span).attr('data-id'));
        }
		/**
		get Cuisine Value
		**/
		let cuisine = new Array();
		$('input[name="cuisine"]:checked').each(function() {
			cuisine.push(this.value);
		});
		/**
		get Preferences Value
		**/
		let preferences = new Array();
		$('input[name="preferences"]:checked').each(function() {
			preferences.push(this.value);
		});
		$("#rowCount").val(1);
		
		if($(".rcips-list").attr('data-filter') == 'Applied1') {
			
			var timeSlotRecipeVal1 = $("#timeslot_recipe").val();
		    var timeSlotrecipeTime1 = $("#timeslopt_recipe_time").val();
			
		} else if ($(".rcips-list").attr('data-filter') == 'Applied3'){
			var timeSlotRecipeVal1 = $("#timeslot_recipe").val();
		    var timeSlotrecipeTime1 = $("#timeslopt_recipe_time").val();
		} else {
			var timeSlotRecipeVal1 = '';
		    var timeSlotrecipeTime1 = '';
		}
		var catKey = $(".rcips-list").attr("data-key");
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url +"filter-recipes",
			data: { allingId: allingId, cuisine: cuisine, catKey: catKey, preferences: preferences, time_slot: timeSlotRecipeVal1, time_too_cook: timeSlotrecipeTime1, pageNo: 1,ajax:"ajaxCall" },
			beforeSend: function() {
              $(laoderHtml).appendTo(".rcips-list");
            },
			success: function (filterecipelist) {
				var divItemlength = filterecipelist.split('<div').length;
				 if (divItemlength < 121) {
					 $("#morerecipe").hide();
				 } else {
					 $("#morerecipe").show();
				 }
				 $("#rowCount").val(1);
				
					 $(".rcips-list").html(filterecipelist);
				 
				 if($(".rcips-list").attr('data-filter') == 'Applied1') {
					 $(".rcips-list").attr('data-filter','Applied3'); 
				 } else if ($(".rcips-list").attr('data-filter') == 'Applied3') {
					$(".rcips-list").attr('data-filter','Applied3');  
				 } else {
					$(".rcips-list").attr('data-filter','Applied2'); 
				 }
				
				$(".loader").remove();

			},
		});

		   

	});
	
	$(document).on('click', '#get_recipe_time_slot', function () {
		var foodpref = $('input[name="recipe_food_pref"]:checked').val();
		if(foodpref == null) {
			foodpref = '';
		}
		let timeSlotRecipeVal = $("#timeslot_recipe").val();
		let timeSlotrecipeTime = $("#timeslopt_recipe_time").val();
		var catKey = $(".rcips-list").attr("data-key");
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url +"filter-recipes",
			data: { time_slot: timeSlotRecipeVal, time_too_cook: timeSlotrecipeTime, catKey: catKey, preferencesre:foodpref, pageNo: 1,ajax:"ajaxCall" },
			beforeSend: function() {
              $(laoderHtml).appendTo(".rcips-list");
           },
			success: function (filterecipelist) {
				
				var divItemlength = filterecipelist.split('<div').length;
				 if (divItemlength < 121) {
					 $("#morerecipe").hide();
				 } else {
					 $("#morerecipe").show();
				 }
				 if($("#rowCount").val()==1) {
					 $(".rcips-list").html(filterecipelist);
				 } else {
					 $(".rcips-list").append(filterecipelist);
				 }
				 
				$(".rcips-list").attr('data-filter','Applied1');
                				
				$(".loader").remove();
				

			},
		});
		return false;
	});
/* Recipe details progress bar */
  
})(jQuery, Drupal);

$(function() {
	
	setTimeout(function(){
			
			let liarray = new Array();
			$('.nutrnal-prgbar-val ul li').each(function () {
				
				if(parseFloat($(this).attr("data-value")) < 0.10) {
					liarray.push(0.10);
				} else {
					liarray.push($(this).attr("data-value"));
				}
				
			});
			if(liarray.length > 0) {
			var a = parseFloat(liarray[0]);
			var b = parseFloat(liarray[1]);
			var c = parseFloat(liarray[2]);
			var d = parseFloat(liarray[3]);
			var obj = {
				values: [a,b,c,d],
				colors: ['#EB724C', '#A37CE2', '#FCC435', '#60B05E'],
				animation: true,
				animationSpeed:15,
				fillTextData: false, 
				fillTextPosition: 'inner',
				doughnutHoleSize: 80,
				doughnutHoleColor: '#fff',
				offset: 1,
				pie: 'normal'
			};
			generatePieGraph('myCanvas', obj);
			}

		},2000); 
	
});
