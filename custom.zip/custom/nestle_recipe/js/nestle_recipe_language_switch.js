(function ($, Drupal) {
	Drupal.behaviors.recipeSearchlanguageswitch = {
		attach: function (context) {
			function sendToLink(link) {
				location.replace(link);
			}
            
			var current_lang_id = drupalSettings.path.currentLanguage;
			var baseurl = drupalSettings.path.baseUrl;
			if(current_lang_id == 'hi') {
			$( ".language-switcher-language-url" ).prepend( $( "<div class='lng1'>आ</div>" ) );
				var shot_url = "hindi";
			} else {
			$( ".language-switcher-language-url" ).prepend( $( "<div class='lng1'>AA</div>" ) );
				var shot_url = "";
			}
			$('.lng1:eq(1)').hide();
		
			
			var transdisable = $('#istransalate').val();
			if(transdisable =='') {
				transdisable = 2;
			}
			var recipesSeo = $('#istransalate').attr('data-seoname');
			if (transdisable) {
			 var baseurl = window.location.origin;	
			 if(current_lang_id == 'hi') {
				 var baseurl1 = baseurl + "/recipes/" + recipesSeo;		
                 $('ul.links li:nth-child(1) a').attr('href',baseurl1);
			 }
             if(current_lang_id == 'en') {
				  var baseurl1 = baseurl + "/hindi/recipes/" + recipesSeo;		
                 $('ul.links li:nth-child(2) a').attr('href',baseurl1);
			 }				 
			}

			if (transdisable == 2) {
				jQuery('#langdroprecipe .droplist').prop('disabled', 'disabled');
			}
			
			jQuery("#langdroprecipe .droplist").on("change", function () {
			
			var value = $(this).val();
			var baseurl = window.location.origin;
			if(value == 'hi') {
				sendToLink(baseurl + "/hindi/recipes/" + recipesSeo);
			} else {
				sendToLink(baseurl + "/recipes/" + recipesSeo);
			}
			});

		}
	};




})(jQuery, Drupal);
