<?php

namespace Drupal\nestle_recipe\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Cmf\Component\Routing\RouteObjectInterface;
use Drupal\Core\Url;
use Drupal\Core\Language\LanguageManager;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\Core\Database\Schema;
use Drupal\node\Entity\Node;
use Drupal\file\Entity\File;
use Drupal\image\Entity\ImageStyle;
use Drupal\taxonomy\Entity\Term;

/**
 * Provides controllers for Home Page.
 */
class Recipes extends ControllerBase {

    /**
     * Home page with recipes details.
     */
    public function mainPage() {
        global $base_url;
        $hindi = CommonFunc::isHindi();
        if($hindi){
        	$lang = 'hi';
        }else{
        	$lang = 'en';
        }
		$globRecipeVariable =array();
		$globRecipeVariable['recipe_top_heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_subheading');
		
		$globRecipeVariable['recipe_top_desc'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_inner_desclaimer');
		
		$globRecipeVariable['recipe_banner_heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_inner_welcome_');
		
		$globRecipeVariable['recipe_banner_desc'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_rda_description');
		
		$globRecipeVariable['recipe_banner_desktop_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_header_logo');
		
		$globRecipeVariable['recipe_banner_mobile_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_footer_logo');
		
		$globRecipeVariable['recipe_banner_link'] = CommonFunc::getConfigPageLinkFieldValue('common_page_headings', 'field_recipe_banner_link');
		
		$globRecipeVariable['recipe_top_tab'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_recipe_top_tab');
		
		//echo "<pre>";
		//print_r($globRecipeVariable); die;
		
        $lang_code = CommonFunc::multilingualConvert("lang");
        $category_tag_new = CommonFunc::APiHindi(['tag_type' => 'nestle_bucket_1']);
        $recipesTags_new = NestleAPI::recipesTags($category_tag_new);
        $recipes = array();
		    $latestRecipes = array();
		/**
		  Latest Recipe
		**/
		$post_datal = CommonFunc::APiHindi(['limit' => 6]);
	    $r_datal = NestleAPI::recipesData($post_datal);
		if($r_datal['status'] == 'success') {
		  $latestRecipes['lrecipe'] = $r_datal['contents']['recipe_list']; 	
		} else {
		 $latestRecipes['lrecipe'] = array();	
		}
		/**
		   Latest Recipe code ENd Here
		**/
		if($recipesTags_new['status'] == 'success') {
			$rest_category_new = NestleAPI::categaryListNew($recipesTags_new);
			$recipes['category'] = $rest_category_new['mainCat'];
			$i = 0;
			foreach ($rest_category_new['mainCat'] as $catKey => $catVal) {
			   $post_data = CommonFunc::APiHindi(['nestle_bucket' => $catVal['seo_name'], 'limit' => 3]);
			   $r_data = NestleAPI::recipesData($post_data);
			   if($r_data['status'] == 'success') {
				    if ($i < 5) {
					$recipeLists = $r_data['contents']['recipe_list'];
					$gtm_array = $r_data['contents']['gtm']['recipes'];
					$recipe['richTagval'] = '';
					 $ki = 0;
					foreach ($recipeLists as $recipeList) {
						$recipe['id'] = $recipeList['id'];
						$recipe['name'] = $recipeList['name'];
						$recipe['eng_name'] = $gtm_array[$ki]['name'];
						$recipe['seo_name'] = $recipeList['seo_name'];
						$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($recipeList['seo_name']);
						$recipe = $recipeMetaData;
						$recipe['fav'] = CommonFunc::getRecipeFavlikeDislike($recipeList['seo_name'], $lang);
						$recipe['gRating'] = CommonFunc::getRecipeRatingBySeo($recipeList['seo_name'], $lang);
						$recipe['url_redirect'] = CommonFunc::encryptData($recipeList['seo_name'].'|recipes|card|'.$lang.'|fav');
						$recipe['time'] = $recipeList['time_to_cook'];
						$recipe['trivia'] = $recipeList['trivia'];
                        $recipe['webp'] = $recipeList['round_images'];
						$recipe['calories'] = $recipeList['calories'];
						$globalTag = $recipeList['global_tags'];
						if($globalTag != "NA") {
						$globalTagarr = explode("@",$globalTag);
						$globalTagarrff = '';
						foreach($globalTagarr as $tagfVal) {
						if($tagfVal !='') {
						$globalTagarrff .='<span>'.$tagfVal.'</span>';
						}

						}
						} else {
						$globalTagarrff = '';
						}
						$recipe['glob_tag'] = $globalTagarrff;
						$recipes['recipe'][$i][] = $recipe;
					    $ki++;
					}
			      }
				   
			   }
				if ($hindi) {
					$url_recipeSchema = $base_url . '/hindi/recipes/' . $catVal['seo_name'];
				} else {
					$url_recipeSchema = $base_url . '/recipes/' . $catVal['seo_name'];
				}			   
			  $recipe_schemaArr[] = array(
                 "@type" => "ListItem",
                 "position" => $i + 1,
                 "url" => $url_recipeSchema
              ); 
			  $i++;
			}
			$recipes['hindiLng'] = CommonFunc::isHindi();
			$recipe_schema = array(
             "@context" => "https://schema.org",
             "@type" => "ItemList",
             "mainEntityOfPage" => array(
                 "@type" => "CollectionPage",
                 "@id" => "https://www.asknestle.in/recipes"
             ),
             "itemListElement" => $recipe_schemaArr
            );
			$jsonldRecipeSchema = json_encode($recipe_schema, JSON_UNESCAPED_UNICODE);
			$schema_metatag_recipe = [
             '#type' => 'html_tag',
             '#tag' => 'script',
             '#value' => $jsonldRecipeSchema,
             '#attributes' => ['type' => 'application/ld+json'],
           ];
		} else {
			$recipes = array();
			//throw new NotFoundHttpException();
		}
		
		return [
            '#theme' => 'RecipesPage',
            '#recipes' => $recipes,
			'#latestRecipes' => $latestRecipes,
			'#globRecipeVariable' => $globRecipeVariable,
             '#attached' => [
			     'library' => 'nestle_recipe/recipe_page',
                 'html_head' => [
                     [$schema_metatag_recipe, 'schema_metatag']
                 ]
             ]
        ];
		

        
    }
	 /**
     * Recipes categories list.
     */
    public function recipeCategory($category) {
		 if($category == 'lunch') {
			 $category = 'lunch-dinner';
		 }
		 global $base_url;
		 $hindi = CommonFunc::isHindi();
		 if($hindi){
        	$lang = 'hi';
        }else{
        	$lang = 'en';
        }
		 if (preg_match("/[A-Z]/", $category) === 0) {
			
			$registeruser = CommonFunc::isRegisterUser();
            $lang_code = CommonFunc::multilingualConvert("lang");
            $category_tag = CommonFunc::APiHindi(['tag_type' => 'nestle_bucket_1']);
			$recipesTags = NestleAPI::recipesTags($category_tag);
            $recipe_category = NestleAPI::categaryListNew($recipesTags);
			if (in_array($category, $recipe_category['SeoName']) !== false) {
				
				 $category = str_replace('+', ' ', $category);
				 $recipe_category_main = $recipe_category['mainCat'];
				 foreach ($recipe_category_main as $keyCat => $valueCat) {
					
                    if (trim($category) == trim($valueCat['seo_name'])) {
                        $CatDesc = $valueCat['desc'];
                        $SeoTitleName = $valueCat['seo_title'];
						$CatSeoName = $valueCat['seo_name'];
                    }
                 }
				 if (isset($CatDesc)) {
                    $recipe_category['mainCatDesc'] = $CatDesc;
                 } else {
					 $recipe_category['mainCatDesc'] = '';
				 }
				 if (isset($SeoTitleName)) {
                    $recipe_category['mainCatTitle'] = $SeoTitleName;
                 } else {
					 $recipe_category['mainCatTitle'] = '';
				 }
				 if (isset($CatSeoName)) {
                    $recipe_category['CatSeoName'] = $CatSeoName;
                 } else {
					 $recipe_category['CatSeoName'] = '';
				 }
				 
				$catName = $category;
				$pageNo = 1;
				$post_data = CommonFunc::APiHindi(['nestle_bucket' => $catName, 'page' => $pageNo]);
				$r_data = NestleAPI::recipesData($post_data);
				if($r_data['status'] == 'success') {
					$catRecipelist = $r_data['contents']['recipe_list'];
					
					foreach ($catRecipelist as $key => $value) {
						$catRecipelist[$key]['recipeMetadata']= CommonFunc::getRecipeMetaDataBySeoName($value['seo_name']);
						$catRecipelist[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value['seo_name'], $lang); 
						$catRecipelist[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value['seo_name'], $lang);
						$catRecipelist[$key]['url_redirect'] = CommonFunc::encryptData($value['seo_name'].'|recipes|card|'.$lang.'|fav');
					}
					$recipe_category['catRecipelistf'] = $catRecipelist; 
				}
				$recipe_category['hindiLng'] = CommonFunc::isHindi();
				$recipe_category['registerUser'] = CommonFunc::isRegisterUser();
				if ($hindi) {
					$url_recipeCatSchema = $base_url . '/hindi/recipes/' . $category;
				} else {
					$url_recipeCatSchema = $base_url . '/recipes/' . $category;
				}

				 
				  $recipecat_schema = array(
                    "@context" => "https://schema.org",
                    "@type" => "ItemList",
                    "mainEntityOfPage" => array(
                        "@type" => "CollectionPage",
                        "@id" => $url_recipeCatSchema
                    ),
                    "name" => $SeoTitleName,
                    "itemListElement" => $recipecat_schemaArr
                 );
				 $jsonldRecipeCatSchema = json_encode($recipecat_schema, JSON_UNESCAPED_UNICODE);
				 $schema_metatag_recipecat = [
                    '#type' => 'html_tag',
                    '#tag' => 'script',
                    '#value' => $jsonldRecipeCatSchema,
                    '#attributes' => ['type' => 'application/ld+json'],
                ];
				//echo "<pre>";
				//print_r($recipe_category['catRecipelistf']); die;
				return [
					'#theme' => 'RecipesCategory',
					'#recipes' => $recipe_category,
					'#attached' => [
					    'library' => 'nestle_recipe/recipe_page',
						'html_head' => [
							[$schema_metatag_recipecat, 'schema_metatag']
						]
					],
				];
				
				
			} else {
				
				$dataValue = $this->recipeDetailPage($category);
				//echo "<pre>";
				//print_r($dataValue['recipes']['recipe_rda_delivery']);
				//die;
				
				 /** Get Banner Details By Config **/
				
				 $recipeGlobVariable['banner_first_heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_red_rda_text');
				 $recipeGlobVariable['banner_first_desc'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_green_rda_text');
				 $recipeGlobVariable['banner_first_desktop_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_banner_first_desktop_image');
				 $recipeGlobVariable['banner_first_mobile_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_banner_first_mobile_image');
				 $recipeGlobVariable['banner_first_link'] = CommonFunc::getConfigPageLinkFieldValue('common_page_headings', 'field_banner_first_link');
				 
				 
				 $recipeGlobVariable['banner_second_heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_choose_your_preferences');
				 $recipeGlobVariable['banner_second_desc'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_inner_welcome');
				  $recipeGlobVariable['banner_second_desktop_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_health_track_male_female_1');
				  $recipeGlobVariable['banner_second_mobile_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_health_track_male_image_2');
				  $recipeGlobVariable['banner_second_link'] = CommonFunc::getConfigPageLinkFieldValue('common_page_headings', 'field_banner_second_link');
				/*******************************************/
				if($hindi) {
				 $recipeBaseurl	 = $base_url . '/hindi/recipes/';
				} else {
				 $recipeBaseurl =  $base_url . '/recipes/';
				}
			     			 
				
				return [
					'#theme' => 'RecipesDetails',
					'#recipes' => $dataValue['recipes'],
					'#youmaylike' => $dataValue['youmaylike'],
					'#BestPairedRecipe' => $dataValue['BestPairedRecipe'],
					'#article' => $dataValue['article'],
					'#recipeBaseUrl' => $recipeBaseurl,
					'#recipeGlobVariable' => $recipeGlobVariable,
					'#attached' => [
					    'library' => 'nestle_recipe/recipe_page',
					],
				];
			}
			
		 } else {
			 
			if ($hindi) {
			CommonFunc::redirectPage($base_url . '/hindi/recipes/' . strtolower($category));
			} else {
			CommonFunc::redirectPage($base_url . '/recipes/' . strtolower($category));
			}
			 
		 }
		
		
	}

	/**
	   Get Recipe Details page datat
	**/
	public function recipeDetailPage($name) {
		 global $base_url;
		 $recipe_schema_data = [];
     $hindiLang = CommonFunc::isHindi();
     if($hindiLang){
     	$lang = 'hi';
     }else{
     	$lang = 'en';
     }
		 $recipe = array();
		 $recipe['hindiLng'] = $hindiLang;
		 $name = strtolower($name);
     $post_data_new = CommonFunc::APiHindi(['recipe_name' => $name]);
   
     $recipe_details = NestleAPI::recipesDetail($post_data_new);
     $uid = CommonFunc::userId();
     $connection = \Drupal::database();
		 if($recipe_details['status'] == 'success') {
		 	$rid = $recipe_details['contents']['recipe_details'][0]['seo_name'];
		 	$rid_seo_alter = $recipe_details['contents']['recipe_details'][0]['seo_name_alternate'];
		 	$recipeTitle= $recipe_details['contents']['recipe_details'][0]['name'];
		 	
			$recipe['content'] = $recipe_details['contents']['recipe_details'][0];
			if ($hindiLang == 'hi') {
				$count = $connection->select('nestle_tried_recipe_data', 't')
					->condition('recipe_alter_seo_name', $rid, '=')
					->condition('t.uid', $uid, '=')->fields('t', ['id'])
					->execute()->fetchAll();
				$favCount = $connection->select('nestle_fav_recipe_data', 't')
					->condition('recipe_alter_seo_name', $rid, '=')
					->condition('t.uid', $uid, '=')->fields('t', ['id'])
					->execute()->fetchAll();
				$rateCount = $connection->select('nestle_rate_recipe_data', 't')
					->condition('recipe_alter_seo_name', $rid, '=')
					->condition('t.uid', $uid, '=')->fields('t', ['id'])
					->execute()->fetchAll();
					$post_data_new = array('recipe_name' => $rid_seo_alter, 'lang' =>"en");
					$recipe_details1 = NestleAPI::recipesDetail($post_data_new);
					$recipeTitleEng= $recipe_details1['contents']['recipe_details'][0]['name'];
					$recipe['recipeName']['recipeHindiName'] = $recipeTitle;
					$recipe['recipeName']['recipeEngName'] = $recipeTitleEng;
					$lang = 'hi';
					$recipe['globalRating'] = CommonFunc::getRecipeRatingBySeo($rid, $lang);
					$recipe['userRating'] = CommonFunc::getUserRecipeRatingBySeo($rid, $uid, $lang);
					$recipe['bookmark'] = CommonFunc::getBookmarkRecipeMarkUnmark($rid, $uid, $lang);
					$recipe['url_redirect'] = CommonFunc::encryptData($rid.'|recipes|detail|hi|fav');
					$recipe['url_redirect_tried'] = CommonFunc::encryptData($rid.'|recipes|detail|hi|tried');
					$recipe['url_redirect_bookmark'] = CommonFunc::encryptData($rid.'|recipes|detail|hi|bookmark');

			}else{
				$count = $connection->select('nestle_tried_recipe_data', 't')
					->condition('recipe_seo_name', $rid, '=')
					->condition('t.uid', $uid, '=')->fields('t', ['id'])
					->execute()->fetchAll();
				$favCount = $connection->select('nestle_fav_recipe_data', 't')
					->condition('recipe_seo_name', $rid, '=')
					->condition('t.uid', $uid, '=')->fields('t', ['id'])
					->execute()->fetchAll();
				$rateCount = $connection->select('nestle_rate_recipe_data', 't')
					->condition('recipe_seo_name', $rid, '=')
					->condition('t.uid', $uid, '=')->fields('t', ['id'])
					->execute()->fetchAll();
					$post_data_new = array('recipe_name' => $rid_seo_alter, 'lang' =>"hi");
					$recipe_details1 = NestleAPI::recipesDetail($post_data_new);
					$recipeTitleHindi= $recipe_details1['contents']['recipe_details'][0]['name'];
					$recipe['recipeName']['recipeHindiName'] = $recipeTitleHindi;
					$recipe['recipeName']['recipeEngName'] = $recipeTitle; 
					$recipe['globalRating'] = CommonFunc::getRecipeRatingBySeo($rid, $lang);
					$recipe['userRating'] = CommonFunc::getUserRecipeRatingBySeo($rid, $uid, $lang);
					$recipe['bookmark'] = CommonFunc::getBookmarkRecipeMarkUnmark($rid, $uid, $lang);
					$recipe['url_redirect'] = CommonFunc::encryptData($rid.'|recipes|detail|en|fav');
					$recipe['url_redirect_tried'] = CommonFunc::encryptData($rid.'|recipes|detail|en|tried');
					$recipe['url_redirect_bookmark'] = CommonFunc::encryptData($rid.'|recipes|detail|en|bookmark');
			}

			if (!empty($count)) {
				$recipe['tried'] = 'yes';
			}else{
				$recipe['tried'] = 'no';
			}
			if (!empty($favCount)) {
				$recipe['fav'] = 'dislike';
			}else{
				$recipe['fav'] = 'like';
			}
			if (!empty($rateCount)) {
				$recipe['rate'] = 'update';
			}else{
				$recipe['rate'] = 'add';
			}


			$recipe['recipe_rda_delivery'] = $recipe_details['contents']['recipe_rda_delivery'];
			 $recipe['recipe_rda_delivery_su'] = $recipe_details['contents']['recipe_rda_delivery_su'];
			 $recipe['gtm'] = $recipe_details['contents']['gtm'];
			 $globalrTag = array();
			 $globalTag = $recipe_details['contents']['recipe_details'][0]['tags'][0]['global_tags'];
			 if($globalTag != "NA") {
				 $globalTagarr = explode("@",$globalTag);
				 $globalTagarrff = '';
				 foreach($globalTagarr as $tagfVal) {
					 if($tagfVal !='') {
					 $globalTagarrff .='<span>'.$tagfVal.'</span>';
					 $globalrTag[] = $tagfVal;
					 }
				 }
			 } else {
				$globalTagarrff = '';
			 }
			 $recipe['qrecipeGlobalTag'] = $globalTagarrff;
			 $stepByStep = strip_tags($recipe_details['contents']['recipe_details'][0]['cooking_instructions']);
			 $stepByStepEx = explode(".",$stepByStep);
			 $recipe['stepbystep'] = $stepByStepEx;
			
			 /**
			   Bucket list for getting you may like recipe and you may like recipe data
			 **/
			 $bucketTag = !empty($recipe_details['contents']) ? explode("@", $recipe_details['contents']['recipe_details'][0]['tags'][0]['nestle_bucket']) : array();
			 $bucketTag = array_filter($bucketTag);
			 $category_tag_new = CommonFunc::APiHindi(['tag_type' => 'nestle_bucket_1']);
             $recipesTags_new = NestleAPI::recipesTags($category_tag_new);
			 $rest_category_new = NestleAPI::categaryListNew($recipesTags_new);
             $recipes_category_new = $rest_category_new['mainCat'];

			 if(!empty($recipes_category_new)){
				 foreach ($recipes_category_new as $keyCat => $valueCat) {
					if (in_array($valueCat['name'], $bucketTag)) {
					$seo_title[] = $valueCat['name'];
					$schema_seo_url[] = $valueCat['seo_name'];
					} 
				 }
			 }
			if (empty($seo_title[0])) {
				$seo_title[0] = "Tiffin";
				$schema_seo_url[0] = 'tiffin';
			}

			 /** Schema INT Code */
			 $recipe_schema_data['schema_category'] = $seo_title[0];
			 $recipe_schema_data['schema_category_seo_url'] = $base_url . '/' . $schema_seo_url[0];
			 $i = 0;
			 $post_data = CommonFunc::APiHindi(['nestle_bucket' => $seo_title[0]]);
			 $ur_data = NestleAPI::recipesData($post_data);
			 $gtm_array = $ur_data['contents']['gtm']['recipes'];
			 $ki = 0;
			 foreach ($ur_data['contents']['recipe_list'] as $recipeList) {
             if ($recipeList['seo_name'] == $name) {
                 $recipe_id = !empty($recipeList['id']) ? $recipeList['id'] : '';
             } else {
                 if ($i < 10) {
                     $youlike['name'] = $recipeList['name'];
                     $youlike['eng_name'] = $gtm_array[$ki]['name'];
                     $youlike['time'] = $recipeList['time_to_cook'];
                     $youlike['webp'] = $recipeList['webp_images'][0]['medium'];


                     if ($hindiLang) {
                        $youlike['link'] = $base_url . '/hindi/recipes/' . $recipeList['seo_name'];
                     } else {
                         $youlike['link'] = $base_url . '/recipes/' . $recipeList['seo_name'];
                     }

                     $youlikefinal['youlike'][] = $youlike;
                 }
                 $i++;
             }
             $ki++;
            }
             
			 /**
			    End Here for you may like
			 **/
			 if($recipe_details['contents']['recipe_details'][0]['video_link'] !='') {
				$videolink = explode('/', $recipe_details['contents']['recipe_details'][0]['video_link']);
				$recipe['videolinkN'] = $videolink[3];
			 } else {
				$recipe['videolinkN'] = ''; 
			 }
			
			 if (isset($recipe_details['contents']['recipe_details'][0]['id'])) {
             $recipe_id = $recipe_details['contents']['recipe_details'][0]['id'];
             }
			 
			 /* GA Counter Insert Function Call */
			  $insert_ga = CommonFunc::insertGa($recipe_id, 'recipe_detail');
			 /* GA Counter Count Function Call */
			 $count_ga = CommonFunc::countGa($recipe_id, 'recipe_detail');
            
			 $recipe['user_counter'] = $count_ga;
			 foreach($recipe_details['contents']['recipe_details'][0]['shopalyst_ingredients'] as $sKey => $sVal) {
				   
				 $inds[] = 'ASKNESTLE_'.$sVal['id'];
			 }
			 $recipe['ing_ids'] = implode(',', $inds);
			 
			 
			 /**
			  Best Paired Recipe code
			   API Name: Balanced-meal-list
			   datapaseed: recipe_id, food_preference,lang
			 **/
			    $bestpairedRId = $recipe['content']['id'];
				$bestfoodpreference = $recipe['content']['tags'][0]['veg_nonveg'];
				if($hindiLang) {
				 $bestlang ='hi';
				} else {
				 $bestlang ='en';	
				}
				$bestPairedPostData = array_filter(explode('@',$recipe['content']['tags'][0]['region']));
				$regionBestPaired = $bestPairedPostData[1];
				

				$betsPostData = [
				                 "food_preference" => $bestfoodpreference,
								 "region" => $regionBestPaired,
								 "recipe_id" => $bestpairedRId,
								 "balanced_meal_id" => '',
								 "lang" => $bestlang
				                ];	
						
			    $bestPaired_data = NestleAPI::getBalancedMealList($betsPostData);
                if($bestPaired_data['status'] =='success') {
					$bestPairedarray['bestpa'] = $bestPaired_data['contents']['recipe_list'];
					foreach ($bestPairedarray['bestpa'] as $key => $value) {
							$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value['seo_name']);
				$bestPairedarray['bestpa'][$key]['recipeMetadata']= $recipeMetaData;
				$bestPairedarray['bestpa'][$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value['seo_name'], $bestlang);
				$bestPairedarray['bestpa'][$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value['seo_name'], $bestlang);
				$bestPairedarray['bestpa'][$key]['url_redirect'] = CommonFunc::encryptData($value['seo_name'].'|recipes|card|'.$bestlang.'|fav');
						}
				} else {
					$bestPairedarray = array();
				}

				if($hindiLang) {
				 $bestPairedarray['url_link']	 = $base_url . '/hindi/recipes/';
				} else {
				 $bestPairedarray['url_link'] = 	$base_url . '/recipes/';
				}


			 /**
			  ENd Best Paired Code
			 **/
			 # get related article with global tag
			 # artcile content type : expert article
			 # condition field Name : tag(field_art_tags)
			 $taxonomyGlobaId = array();
			 $article = array();
			 if(!empty($globalrTag)) {
				 foreach($globalrTag as $globTagg) {
					 $globalTagtaxId = CommonFunc::getTermByName($globTagg);
					 $taxonomyGlobaId [] = $globalTagtaxId ;
				 }
			 }
			 if(!empty($taxonomyGlobaId)) {
				# get all article related to global tag 
				$ea_query = \Drupal::entityQuery('node')
				->range(0, 8)
				->condition('status', 1)
                ->condition('type', 'expert_advice', '=')
				->condition('field_art_tags', $taxonomyGlobaId);
				$ea_nids = $ea_query->sort('created', 'DESC')->execute();
				$ea_nodes = Node::loadMultiple($ea_nids);
				$langCode = CommonFunc::multilingualConvert("lang");
				if(!empty($ea_nodes)) {
					$article1 = array();
					foreach ($ea_nodes as $node) {
						$node = $node->getTranslation($langCode);
						$nid = $node->get('nid')->value;
						if($node->field_thum_image){
							if($node->field_thum_image->getValue()) {
								$file_image =File::load($node->field_thum_image->getValue()[0]['target_id']);
								$original_image = $file_image->getFileUri();
								$image_path = file_url_transform_relative(file_create_url($original_image));
								$style = \Drupal::entityTypeManager()->getStorage('image_style')->load('webp');
								$article1['thumb'] = file_create_url($style->buildUri($original_image));
								$article1['original'] = $image_path;
							} else {
								$article1['thumb'] = '';
								$article1['original'] =''; 
							}
						} else {
							$article1['thumb'] = '';
							$article1['original'] ='';
						}
						$date = $node->get('created')->value;
						$article1['created_date'] = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
						$article1['read_time'] = $node->get('field_read_time')->value;
						$article1['author'] = $node->get('field_author')->value;
						$term = Term::load($node->get('field_category')->target_id);
						$article1['term_name'] = $term->getName();
						$article1['title'] = $node->getTitle();
						$alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
						$article1['node_url'] = $alias_url;
						
						
						
						$art_tags = array();
						$article[] = $article1;
					  
					}
					
				}
				
			 }
			 # end code related article
			 $DataValue = array("recipes" => $recipe, 'youmaylike' => $youlikefinal, 'BestPairedRecipe' => $bestPairedarray, 'article' =>$article );
			 return $DataValue;
		 } else {
			throw new NotFoundHttpException(); 
			 
		 }
		
		
	}
	
	/**
     * Get Recipes list by category and page no.
     */
    public function getRecipesList(Request $request) {

        global $base_url;

        $catName = $request->query->get('catName');
        $pageNo = $request->query->get('pageNo');
        $ajax = $request->query->get('ajax');

        $post_data = CommonFunc::APiHindi(['nestle_bucket' => $catName, 'page' => $pageNo]);
        $r_data = NestleAPI::recipesData($post_data);
       
        $fileterData = $this->getRecipeshtmlData($r_data, $catName, $pageNo,$ajax);

        return new JsonResponse($fileterData);
    }
	
	 /**
     * Get Recipes list by details array and create html.
     */
    public function getRecipeshtmlData($filterData, $catName, $pageNo = NULL, $countUl = NULL,$ajax = NULL) {

        global $base_url;

        $hindi = CommonFunc::isHindi();
        if($hindi){
        	$lang = 'hi';
        }else{
        	$lang = 'en';
        }
        $list = $filterData['contents']['recipe_list'];
        $gtm = $filterData['contents']['gtm']['recipes'];
        $recipeLists = array_slice($list, 0, 12);
        $noRecipe = "No Recipes Available";

        if ($hindi) {
             
            $noRecipe = "कोई रेसिपी उपलब्ध नहीं";
        } 

        $listrecipesData = '';
        if (count($recipeLists) > 0) {
            $ki = 0;
            foreach ($recipeLists as $recipeList) {
            	$recipes = array();
                $recipeName = $recipeList['name'];
                $recipeeng_name = $gtm[$ki]['name'];
                $recipeseo_name = $recipeList['seo_name'];
                $recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($recipeList['seo_name']);
				$recipes = $recipeMetaData;
				$recipes['fav'] = CommonFunc::getRecipeFavlikeDislike($recipeList['seo_name'], $lang);
				$recipes['gRating'] = CommonFunc::getRecipeRatingBySeo($recipeList['seo_name'], $lang);
				$recipes['url_redirect'] = CommonFunc::encryptData($recipeList['seo_name'].'|recipes|card|'.$lang.'|fav');
				$recipeDesc = $recipeList['trivia'];
                $recipeTime = $recipeList['time_to_cook'];
                $recipeWebp = $recipeList['round_images'];
				$calories = $recipeList['calories'];
				$noofServings = $recipeList['no_of_servings'];
				$globalTag = $recipeList['global_tags'];

			$logged_in = \Drupal::currentUser()->isAuthenticated();
				if($globalTag != "NA") {
					$globalTagarr = explode("@",$globalTag);
					$globalTagarrff = '';
					foreach($globalTagarr as $tagfVal) {
						if($tagfVal !='') {
						 $globalTagarrff .='<span>'.$tagfVal.'</span>';
						}
						
					}
				} else {
					$globalTagarrff = '';
				}
                $lang_code = CommonFunc::multilingualConvert("lang");
                $recipeLink = $base_url . '/recipes/' . $recipeseo_name;
                if ($lang_code !== "en") {
                    $recipeLink = $base_url . '/hi/recipes/' . $recipeseo_name;
                }

                if ($hindi) {
					$hrefurl = $base_url.'/hi/recipes/'.$recipeseo_name;
                    $mins = ' मिनट';
					$cals ='कैलोरी';
					$servs ='सर्विंग्स';
					$redirecthrefurl = $base_url.'/hindi/user/login?destination=';

                } else {
                    $mins = ' mins';
					$cals ='calories';
					$servs ='Servings';
					$hrefurl = $base_url.'/recipes/'.$recipeseo_name;
					$redirecthrefurl = $base_url.'/user/login?destination=';
                }
                if($recipes['fav']=='like'){
			          $likeClass = '';
			          $likeAttr = 'like';
			        }else{
			          $likeClass = 'active-like';
			          $likeAttr = 'dislike';
			        }
			    if($recipes['gRating'] != 0.0){
					$rate = '<div class="rvw"><em></em>'.$recipes['gRating'].'</div>';
				}else{
					$rate = '<div class="rvw"><em></em>'.t('No rate').'</div>';
				}
			        if($logged_in){
			        	$like_html= '<div class="like '.$likeClass.' favBtn" id="favBtn" data-fav="'.$likeAttr.'" data-recipeid="'.$recipes['id'].'" data-recipeseoname="'.$recipes['seo_name'].'" data-recipeseoalternatename="'.$recipes['seo_name_alternate'].'" data-value="'.$recipes['seo_name'].'" data-hindiname = "'.$recipes['recipeMetadata']['hindi_name'].'" data-engname = "'.$recipes['recipeMetadata']['eng_name'].'" data-target="card"></div>';
			        }else{
			        	$like_html = '<a href="'.$redirecthrefurl.$recipes['url_redirect'].'"><div class="like"></div></a>';
			        }
                
				$listrecipesData .='<div class="item">
				                      <div class="cardscmn2">
									     <div class="imgWrp">
										  <a href="'.$hrefurl.'">
										  <img src="'.$recipeWebp.'" alt="'.$recipeName.'" width="1" height="1">
										  </a>
										  </div>
										 <div class="txtb">
											<a href="'.$hrefurl.'">
											 <h3>'.$recipeName.'</h3>
											</a> 
											<p>'.$recipeDesc.'</p>
											<ul class="list1">
											<li><em><img src="/themes/custom/nestle_new/images/icon-fire.svg" alt="calories" width="1" height="1"></em> '.$calories.' '.$cals.'</li>
											<li><em><img src="/themes/custom/nestle_new/images/icon-time.svg" alt="mins" width="1" height="1"></em> '.$recipeTime.' '.$mins.'</li>
											<li><em><img src="/themes/custom/nestle_new/images/icon-profile.svg" alt="Servings" width="1" height="1"></em> '.$noofServings.'  '.$servs.'</li>
											</ul>
											<div class="tagbox">'.$globalTagarrff.'</div>
										</div>
										<div class="crdsFtr">
											<div class="vn-tag-rvw">
											<div class="veg-nveg-mark"><i class="veg-icon"></i></div>
											'.$rate.'
											</div>
											'.$like_html.'
										</div> 
										 
									  </div>
				                     </div>';

                
                $ki++;
            }
            
        } else {

            $listrecipesData = "<div class='norescipes'>" . $noRecipe . "</div>";
        }
        return $listrecipesData;
    }
	
	/**
	* Get Recipes  by search data by serach value.
	*/
	public function RecipesSearch(Request $request) {
		global $base_url;
		$hindi = CommonFunc::isHindi();
		if($hindi){
			$lang = 'hi';
		}else{
			$lang = 'en';
		}
		$searchData = $request->query->get('searchRecData');
		$langCode = CommonFunc::multilingualConvert("lang");
		$pageNo = 1;
		\Drupal::service('page_cache_kill_switch')->trigger();
		if (trim($langCode) === "hi") {
			$post_data = ['q' => trim($searchData), 'page' => $pageNo, 'lang' => "hi"];
			$hindiLang = CommonFunc::isHindi();
			$listCount['hindiLng'] = $hindiLang;
		} else {
			$post_data = ['q' => trim($searchData), 'page' => $pageNo];
		}
		$r_data = NestleAPI::recipesData($post_data);
    $list = $r_data['contents']['recipe_list'];
    foreach ($list as $key => $value) {
			$list[$key]['recipeMetadata']= CommonFunc::getRecipeMetaDataBySeoName($value['seo_name']);
			$list[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value['seo_name'], $lang); 
			$list[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value['seo_name'], $lang);
		}
    $listCount['searchCount'] = $r_data['contents']['count'];
		$recipeLists = array_slice($list, 0, 12);
		return [
            '#theme' => 'RecipesSearch',
            '#searchKey' => $searchData,
            '#searchData' => $recipeLists,
            '#searchCount' => $listCount,
            '#attached' => [
                'library' => 'nestle_recipe/recipe_page',
            ],
        ];
	}
	
	/**
     * Get recipes list Advanced filter.
     */
    public function getFilterRecipes(Request $request) {
		global $base_url;
		$pageNo = $request->query->get('pageNo');
		
		if (!empty($request->query->get('time_slot'))) {
            $filterData['time_slot'] = $request->query->get('time_slot');
        } else {
            $filterData['time_slot'] = '';
        }
		
		if (!empty($request->query->get('time_too_cook'))) {
            $time_too_cook = $request->query->get('time_too_cook');
			$timeexp = explode("-",$time_too_cook);
			$filterData['min_time_to_cook'] = $timeexp[0];
			$filterData['max_time_to_cook'] = $timeexp[1];
        } else {
            $filterData['min_time_to_cook'] = '';
			$filterData['max_time_to_cook'] = '';
        }
		
		if (!empty($request->query->get('allingId'))) {
			$filterData['ingredients'] = implode('@', $request->query->get('allingId'));
        } else {
            $filterData['ingredients'] = '';
        }
		
		if (!empty($request->query->get('preferences'))) {
            $filterData['food_preference'] = implode('@', $request->query->get('preferences'));
        } else if (!empty($request->query->get('preferencesre'))) {
            $filterData['food_preference'] = $request->query->get('preferencesre');
        } else {
			$filterData['food_preference'] = '';
		}
		if (!empty($request->query->get('cuisine'))) {
            $filterData['region'] = implode('@', $request->query->get('cuisine'));
        } else {
            $filterData['region'] = '';
        }
		$filterData['nestle_bucket'] = $request->query->get('catKey');
		$filter_recipes_list = CommonFunc::APiHindi([
                    'region' => $filterData['region'],
                    'food_preference' => $filterData['food_preference'],
                    'ingredients' => $filterData['ingredients'],
					'time_slot' => $filterData['time_slot'],
					'min_time_to_cook' => $filterData['min_time_to_cook'],
					'max_time_to_cook' => $filterData['max_time_to_cook'],
                    'nestle_bucket' => $filterData['nestle_bucket'],
                    'page' => $pageNo,
        ]);
		 
		$filter_details = NestleAPI::recipesData($filter_recipes_list); 
		$fileterData1 = $this->getRecipeshtmlData($filter_details, $filterData['nestle_bucket'], $pageNo);
		return new JsonResponse($fileterData1);
		
	}

    
}
