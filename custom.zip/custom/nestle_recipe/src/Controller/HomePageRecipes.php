<?php

namespace Drupal\nestle_recipe\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Cmf\Component\Routing\RouteObjectInterface;
use Drupal\Core\Url;
use Drupal\Core\Language\LanguageManager;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\Core\Database\Schema;

/**
 * Provides controllers for Home Page.
 */
class HomePageRecipes extends ControllerBase {

    /**
     * Home page login user latest recipe.
     */
	public static function HomeLatestRecipe() {
		global $base_url;
        $hindi = CommonFunc::isHindi();
        if($hindi){
        	$lang = 'hi';
        }else{
        	$lang = 'en';
        }
		$latestRecipes = array();
		$post_datal = CommonFunc::APiHindi(['limit' => 6]);
	    $r_datal = NestleAPI::recipesData($post_datal);
		if($r_datal['status'] == 'success') {
		  $latestRecipes['lrecipe'] = $r_datal['contents']['recipe_list']; 	
		} else {
		 $latestRecipes['lrecipe'] = array();	
		}
		$latestRecipes['hindiLng'] = CommonFunc::isHindi();
		return [
			'#theme' => 'HomeExploreRecipe',
			'#params' => $latestRecipes,
		];
		
	}
	# Home Page bookmark Recipe
	# start date: 28-1--2022
	# Develop By : Digitas Drupal Dev Team
	public static function HomeBookmarkRecipe() {
		$uid = CommonFunc::userId();
		$connection = \Drupal::database();
		$hindiLang = CommonFunc::isHindi();
		$dataValue = array();
		
		$bookmarkRecipesTotalCount = $connection->select('nestle_bookmark_recipe_data', 't')
										->condition('t.uid', $uid, '=')
										->fields('t', ['id'])
										->execute()->fetchAll();
		if($hindiLang == 'hi'){
			$bookmarkRecipes = $connection->select('nestle_bookmark_recipe_data', 't')
				->condition('t.uid', $uid, '=')
				->range(0, 6)
				->orderBy('id', 'DESC')
				->fields('t', ['recipe_alter_seo_name'])
				->execute()->fetchAll();
			foreach ($bookmarkRecipes as $key => $value) {
				$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_alter_seo_name);
				$dataValue[$key] = $recipeMetaData;
				$dataValue[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_alter_seo_name, 'hi');
				$dataValue[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value->recipe_alter_seo_name, 'hi');
			}	
		} else {
			
			$bookmarkRecipes = $connection->select('nestle_bookmark_recipe_data', 't')
			->condition('t.uid', $uid, '=')
			->orderBy('id', 'DESC')
			->range(0, 6)
			->fields('t', ['recipe_seo_name'])
			->execute()->fetchAll();
			foreach ($bookmarkRecipes as $key => $value) {
				$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_seo_name);
				$dataValue[$key] = $recipeMetaData;
				$dataValue[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_seo_name, 'en');
				$dataValue[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value->recipe_seo_name, 'en');

			}
			
		}
		$data['bookmarkrecipe'] = $dataValue;
		$data['hindiLng'] = CommonFunc::isHindi();
		return [
			'#theme' => 'HomeBookMarkRecipe',
			'#params' => $data,
		];
		

	}	
	
	# Home Page favorite Recipe
	# start date: 28-1--2022
	# Develop By : Digitas Drupal Dev Team
	public static function HomeFavoriteRecipe() {
		$favoriteRecipes = array();
		$uid = CommonFunc::userId();
		$connection = \Drupal::database();
		$hindiLang = CommonFunc::isHindi();
		$pageNo = 1;
		$pagerRow = $pageNo*2-2;
		if($hindiLang == 'hi'){
			$favRecipes = $connection->select('nestle_fav_recipe_data', 't')
			->condition('t.uid', $uid, '=')
			->range($pagerRow, 6)
			->orderBy('id', 'DESC')
			->fields('t', ['recipe_alter_seo_name'])
			->execute()->fetchAll();

			foreach ($favRecipes as $key => $value) {
				$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_alter_seo_name);
				$favoriteRecipes[$key] = $recipeMetaData;
				$favoriteRecipes[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_alter_seo_name, 'hi');
			}
		}else{
			$favRecipes = $connection->select('nestle_fav_recipe_data', 't')
			->condition('t.uid', $uid, '=')
			->orderBy('id', 'DESC')
			->range($pagerRow, 6)
			->fields('t', ['recipe_seo_name'])
			->execute()->fetchAll();
			foreach ($favRecipes as $key => $value) {
				$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_seo_name);
				$favoriteRecipes[$key] = $recipeMetaData;
				$favoriteRecipes[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_seo_name, 'en');
			}
		}
		
		$data['favoriteRecipes'] = $favoriteRecipes;
		$data['hindiLng'] = CommonFunc::isHindi();
		return [
			'#theme' => 'HomeFavoriteRecipe',
			'#params' => $data,
		];
		

	}	
  
		
	
}
