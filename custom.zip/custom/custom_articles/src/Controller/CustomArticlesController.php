<?php

namespace Drupal\custom_articles\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\wework_form_data\WeworkFormDataStorage;
use Drupal\views\Views;
use Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\taxonomy\TermInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\Component\Utility\Xss;

class CustomArticlesController extends ControllerBase {
    
    public function articles_list(){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $roles = $user->getRoles();
        $user_id = $user->id();
        $data_val = array();
        
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        $language =  \Drupal::languageManager()->getCurrentLanguage()->getName();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
		/**
		 Get Config Value
		**/
		$data_val['config']['article_top_heading'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_subheading');
		
		$data_val['config']['article_top_desc'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_rda_description');
		
		$data_val['config']['recipe_heading'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_heading_1');
		
		$data_val['config']['recipe_desc'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_disclaimer');
		
		$data_val['config']['recipe_desc'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_disclaimer');
		
		$data_val['config']['recipe_banner_link'] = CommonFunc::getConfigPageLinkFieldValue('expert_article_config', 'field_button_link');
		
		$data_val['config']['article_banner_desktop_image'] = CommonFunc::getConfigPageImageFieldValue('expert_article_config', 'field_banner_first_desktop_image');
		
		$data_val['config']['article_banner_mobile_image'] = CommonFunc::getConfigPageImageFieldValue('expert_article_config', 'field_banner_first_mobile_image');
		
		$data_val['config']['article_banner_heading'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_heading_2');
		
		$data_val['config']['article_banner_desc'] = CommonFunc::getConfigPageFieldValue('expert_article_config', 'field_footer_disclaimer');
		
		$data_val['config']['article_banner_link'] = CommonFunc::getConfigPageLinkFieldValue('expert_article_config', 'field_banner_first_link');
		
		
        /* get tags: START */
        $tags_arr = array();
        $tag_query = \Drupal::entityQuery('taxonomy_term');
        $tag_query->condition('vid', "dsu_tag");
        $tag_term = $tag_query->execute();
        foreach ($tag_term as $tag) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($tag);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$tag] = $taxonomy_term_trans->name->value;
        }
        /* get tags: END */
        
        /* get categories: START */
        $art_cat = array();
        $cat_query = \Drupal::entityQuery('taxonomy_term');
        $cat_query->condition('vid', "expert_advice_topics");
		$cat_query->sort('weight', 'ASC');
        $cat_tids = $cat_query->execute();
        
        foreach($cat_tids as $cat_key=>$cat_val) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($cat_val);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);

            
            $art_cat[$cat_val]['name'] = $taxonomy_term_trans->name->value;
            $term_link = \Drupal::service('path_alias.manager')->getAliasByPath('/taxonomy/term/'.$cat_val);
            $art_cat[$cat_val]['url'] = ($lang_code == "hi") ? $base_url.'/hindi'.$term_link : $base_url.$term_link;
			$art_cat[$cat_val]['term_id'] = $cat_val;
			$art_cat[$cat_val]['short_desc'] = $taxonomy_term_trans->field_short_desc->value;
        }


        $data_val['art_cat'] = $art_cat;
		
        /* get categories: END */
        
        /* get article list: START */
		$i = 1;
        $j = 0;
		foreach($data_val['art_cat'] as $art_cat_key => $art_cat_val) {
	     if($art_cat_val['term_id'] == 55) {
			 
			 $query = \Drupal::entityQuery('node')
            ->condition('type','expert_advice')
            ->condition('langcode', $lang_code)
			->condition('status', 1)
            ->sort('changed', 'DESC')
            ->range(0, 4); 
			 
		 }	else {
			$query = \Drupal::entityQuery('node')
            ->condition('type','expert_advice')
            ->condition('langcode', $lang_code)
			->condition('field_category', $art_cat_val['term_id'], '=')
			->condition('status', 1)
            ->sort('created', 'DESC')
            ->range(0, 4); 
		 }	
        
        $nids = $query->execute();
		if(!empty($nids)) {

        $nodes =  \Drupal\node\Entity\Node::loadMultiple($nids);
		
        $articles = array();
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $nid = $val->id();

            $node_id = CommonFunc::encryptData($nid);
            $date_obj = $val->get('created')->getValue();
            $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = $banner[0]['target_id'];
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $title = $val->get('title')->getValue();
            $desc = $val->get('body')->getValue();
            $category = $val->get('field_category')->getValue();
            $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
            $term_name = "";
            if(!empty($category_id)){
                $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
                $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
            }
            $read_time = $val->get('field_length')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = array();
            foreach($tags AS $key1 => $val1){
                $art_tags[] = $tags_arr[$val1['target_id']];
            }
            

            if(!empty($user_id)){
                $qry = "SELECT * FROM custom_art_bookmark WHERE user_id = {$user_id} AND node_id = {$nid}";
                $query = $connection->query($qry);
                $query_res = $query->fetch();
            }
            $bookmark = !empty($query_res) ? "active-bm" : "";
            
            $articles[$i]['id'] = $node_id;
			$articles[$i]['node_id'] = $nid;
            $articles[$i]['title'] = !empty($title[0]) ? $title[0]['value'] : "";
            $articles[$i]['img'] = $banner_img;
            //$articles[$i]['desc'] = !empty($desc[0]) ? $desc[0]['value'] : "";
            $articles[$i]['cat'] = $term_name;
            $articles[$i]['read_time'] = !empty($read_time[0]) ? $read_time[0]['value']: "";
            $articles[$i]['tags'] = $art_tags;
            $articles[$i]['bookmark'] = $bookmark;

            $articles[$i]['redirect'] = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
			$art[$j]['node'] = $articles;
			$i++;
		}
		$art[$j]['caregory'] = $art_cat_val;
		 $j++;
        }
		if($j == 5) {
			break;
		}
		
	   }
	   
	   
        
        $data_val['articles'] = $art;
        $data_val['redirect_lang'] = $redirect_lang;
        $data_val['is_user'] = !empty($user_id) ? "1" : "";
        /* get article list: END */
		
        return array(
            '#theme' => 'articles_list',
            '#data' => $data_val,
            '#cache' => ['max-age' => 0],
        );
    }
    
    public function get_articles(Request $request){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $roles = $user->getRoles();
        $user_id = $user->id();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        
       
        $sort_val = $request->query->get('sort_val');
        $cur_cat = $request->query->get('cur_cat');
        $cur_page = $request->query->get('cur_page');
		$age_val = $request->query->get('age_val');
        $start = !empty($cur_page) ? $cur_page * 8-8 : 0;
        $asd = array($sort_val,$cur_cat,$cur_page,$age_val);
		
        $limit = 8;
        
        /* get tags: START */
        $tags_arr = array();
        $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
        foreach ($terms_data as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;

        }
		
        /* get tags: END */
        
        /* get article list: START */
        if($sort_val == '1'){
			if($cur_cat != 55) {
				$sort_field = "created";
                $sort_order = "DESC";
			} else {
				$sort_field = "changed";
                $sort_order = "DESC";
			}
            
        }elseif($sort_val == '2'){
            $sort_field = "field_art_popularity";
            $sort_order = "DESC";
        }else{
            if($cur_cat != 55) {
				$sort_field = "created";
                $sort_order = "DESC";
			} else {
				$sort_field = "changed";
                $sort_order = "DESC";
			}
        }
        
        $query = \Drupal::entityQuery('node');
        
        
        if(!empty($group)){
            $query->condition($group);
        }
		
        if(!empty($cur_cat)){
			if($cur_cat != 55) {
			 $query->condition('field_category', $cur_cat);	
			}
            
        }
		if(!empty($age_val)){
            $query->condition('field_age_group', $age_val);
        }
		$query->condition('status', 1);
        $results = $query->condition('type','expert_advice')
            ->sort($sort_field, $sort_order)
            ->range($start, $limit)
            ->execute();
			
        
        $nodes =  \Drupal\node\Entity\Node::loadMultiple($results);
        $articles = array();
        $html = "";
		if(!empty($nodes)) {
			$return['countrow'] = count($results);
			
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $nid = $val->id();

            $node_id = CommonFunc::encryptData($nid);
            $date_obj = $val->get('created')->getValue();
            $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = $banner[0]['target_id'];
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $title_obj = $val->get('title')->getValue();
			if($redirect_hindiLang) {
				 $node_link = $base_url.'/hindi'.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$key);
			} else {
				 $node_link = $base_url.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$key);
			}
           
            $desc_obj = $val->get('body')->getValue();
            $category = $val->get('field_category')->getValue();
            $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
            $term_name = "";
            if(!empty($category_id)){
                $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
                $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
            }
            $read_time_obj = $val->get('field_read_time')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = "";
            foreach($tags AS $key1 => $val){
                $art_tags .= "<span>".$tags_arr[$val['target_id']]."</span>";
            }
            
            $title = !empty($title_obj[0]) ? $title_obj[0]['value'] : "";
            $img = $banner_img;
            $desc = !empty($desc_obj[0]) ? $desc_obj[0]['value'] : "";

            $read_time = !empty($read_time_obj[0]) ? $read_time_obj[0]['value'] : "";
            
            if(!empty($user_id)){
                $qry = "SELECT * FROM custom_art_bookmark WHERE user_id = {$user_id} AND node_id = {$nid}";
                $query = $connection->query($qry);
                $query_res = $query->fetch();
            }
            $bookmark = !empty($query_res) ? "active-bm" : "";

            $redirect = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
           
            
            $html .= '<div class="grid-item">
                <div class="thumBox">
                    <div class="thumBoxinr">
                        <div class="thumCont"> 
                            <a href="javascript:void(0);" class="bookmark art-bookmark '.$bookmark.'" data-id="'.$node_id.'" data-re="'.$redirect.'"><span></span></a>
                            <div class="thumImg articlethumbimg">
                                <a href="'.$node_link.'"><img src="'.$img.'" alt="'.t($title).'"></a>
                            </div>
                            <div class="thumText">
                                <div class="meal-read">
                                    <div class="meal-type">'.t($term_name).'</div>
                                    <div class="time-read">'.$read_time.'</div>
                                </div>
                                <p><a href="'.$node_link.'">'.t($title).'</a></p>
                                <div class="tagbox">
                                    '.t($art_tags).'
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
        }
	   } else {
		   if($redirect_hindiLang) {
			  $html = '<div class="recordntfd">कोई रिकॉर्ड नहीं मिला</div>'; 
		   } else {
			   $html = '<div class="recordntfd">No Record Found</div>'; 
		   }
		   $return['countrow'] = 0;
		   
	   }
        /* get article list: END */
        
        $return['html'] = $html;
		
       return new JsonResponse($return);
    }
    
    public function search_articles(){
        global $base_url;
		$hindi = CommonFunc::isHindi();
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $roles = $user->getRoles();
        $user_id = $user->id();
        $data_val = array();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        
//        echo $sort_val = $request->query->get('sort_val');
        $src_cont = !empty($_POST['src_cont']) ? $_POST['src_cont'] : "";
        $src_txt = !empty($_POST['src_txt']) ? $_POST['src_txt'] : "";
        $sort_val = !empty($_POST['sort_val']) ? $_POST['sort_val'] : "";
        $cur_cat = !empty($_POST['cur_cat']) ? $_POST['cur_cat'] : "";
//        $start = !empty($cur_page) ? $cur_page * 8 : 0;
        $start = 0;
        $limit = 8;
        /* get tags: START */
        $tags_arr = array();
        $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
        foreach ($terms_data as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;
//            $tags_arr[$term->tid] = $term->name;
        }
        /* get tags: END */
        
        /* get article list: START */
        if($sort_val == '1'){
            $sort_field = "created";
            $sort_order = "DESC";
        }elseif($sort_val == '2'){
            $sort_field = "field_art_popularity";
            $sort_order = "DESC";
        }else{
            $sort_field = "created";
            $sort_order = "DESC";
        }
        
//        $query = \Drupal::entityQuery('node');
//        $group = $query
//            ->orConditionGroup()
//            ->condition('title', $src_txt, 'CONTAINS')
//            ->condition('body', $src_txt, 'CONTAINS');
//        if(!empty($src_cont)){
//            if(!empty($cur_cat)){
//                $results = $query->condition($group)
//                    ->condition('type','expert_advice')
//                    ->condition('field_category', $cur_cat)
//                    ->sort($sort_field, $sort_order)
//                    ->range($start, $limit)
//                    ->execute();
//            }else{
//                $results = $query->condition($group)
//                    ->condition('type','expert_advice')
//                    ->sort($sort_field, $sort_order)
//                    ->range($start, $limit)
//                    ->execute();
//            }
//        }else{
//            if(!empty($cur_cat)){
//                $results = $query->condition($group)
//                    ->condition('type','expert_advice')
//                    ->condition('field_category', $cur_cat)
//                    ->sort($sort_field, $sort_order)
//    //                ->range($start, $limit)
//                    ->execute();
//            }else{
//                $results = $query->condition($group)
//                    ->condition('type','expert_advice')
//                    ->sort($sort_field, $sort_order)
//    //                ->range($start, $limit)
//                    ->execute();
//            }
//        }
        
        $query = \Drupal::entityQuery('node');
        $group = $query
            ->orConditionGroup()
            ->condition('title', $src_txt, 'CONTAINS')
            ->condition('body', $src_txt, 'CONTAINS');
        
        if(!empty($cur_cat)){
            $query->condition('field_category', $cur_cat);
        }
        
        $query->condition($group)
            ->condition('type','expert_advice')
            ->sort($sort_field, $sort_order);
        if(!empty($src_cont)){
            $query->range($start, $limit);
        }
        
        $results = $query->execute();
        
        $nodes =  \Drupal\node\Entity\Node::loadMultiple($results);
        $articles = array();
        $html = "";
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $nid = $val->id();
//            $node_id = $this->encrypt_data($val->id());
            $node_id = CommonFunc::encryptData($nid);
            $date_obj = $val->get('created')->getValue();
            $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = !empty($banner) ? $banner[0]['target_id'] : "";
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $title_obj = $val->get('title')->getValue();
			if($hindi){
				$node_link = $base_url.'/hindi'.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$key);
			} else {
				$node_link = $base_url.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$key); 
			}
            
            $desc_obj = $val->get('body')->getValue();
            $category = $val->get('field_category')->getValue();
            $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
            $term_name = "";
//            if(!empty($category_id)){
//                $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
//                $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
//            }
            $read_time_obj = $val->get('field_length')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = "";
            foreach($tags AS $key1 => $val){
                $art_tags .= "<span>".$tags_arr[$val['target_id']]."</span>";
            }
            
            $title = !empty($title_obj[0]) ? $title_obj[0]['value'] : "";
            $img = $banner_img;
            $desc = !empty($desc_obj[0]) ? $desc_obj[0]['value'] : "";
//            $cat = $term_name;
            $tags = $art_tags;
            $read_time = !empty($read_time_obj[0]) ? $read_time_obj[0]['value']." min read" : "";
            $redirect = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
            
            if(!empty($src_cont)){
                $html .= '<div class="grid-item">
                    <div class="thumBox">
                        <div class="thumBoxinr">
                            <div class="thumCont"> <a href="javascript:void(0);" class="bookmark art-bookmark" data-id="'.$node_id.'" data-re="'.$redirect.'"><span></span></a>
                                <div class="thumImg">
                                    <a href="'.$node_link.'"><img src="'.$img.'" alt="'.$title.'"></a>
                                </div>
                                <div class="thumText">
                                    <div class="meal-read">
                                        <div class="meal-type">Vegan</div>
                                        <div class="time-read">'.$read_time.'</div>
                                    </div>
                                    <p><a href="'.$node_link.'">'.$title.'</a></p>
                                    <div class="tagbox">
                                        '.$art_tags.'
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
            }else{
                $html .= '<div class="src-art-cont srchDataItm"><a href="'.$node_link.'">'.$title.'</a></div>';
            }
            
        }
        /* get article list: END */
        
        $return['html'] = $html;
        return new JsonResponse($return);
    }
    
    public function add_bookmark(){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        $msg = "";
        
        if(!empty($user_id)){
//            $node_id = !empty($_POST['node_id']) ? $this->decrypt_data($_POST['node_id']) : "";
            $node_id = !empty($_POST['node_id']) ? CommonFunc::decryptData($_POST['node_id']) : "";
            $bookmark = !empty($_POST['bookmark']) ? $_POST['bookmark'] : "";
            $user_bookmarks = !empty($_POST['user_bookmarks']) ? $_POST['user_bookmarks'] : "";
            $current_ip = \Drupal::request()->getClientIp();
            $lead_date = date("Y-m-d H:i:s");
            $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
            
            if(!empty($bookmark)){
                $node_data = \Drupal\node\Entity\Node::load($node_id);
                $title = $node_data->get('title')->getValue()[0]['value'];
                $popularity = $node_data->get('field_art_popularity')->getValue()[0]['value'];
                
                $connection->insert('custom_art_bookmark')
                    ->fields([
                        'user_id' => $user_id,
                        'ip_add' => $current_ip,
                        'node_id' => $node_id,
                        'page' => 'articles',
                        'page_title' => $title,
                        'art_popularity' => $popularity,
                        'lang_code' => $lang_code,
                        'created_at' => $lead_date,
                    ])
                    ->execute();
            }else{
                $query = $connection->delete('custom_art_bookmark');
                $query->condition('user_id', $user_id);
                $query->condition('node_id', $node_id);
                $query->condition('page', 'articles');
                $query->execute();
            }
            
            $msg = "success";
        }
        
        $return['msg'] = $msg;
        return new JsonResponse($return);
    }
    
    public function trend_bookmark(Request $request){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        $redirect = "";
        
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        
        $nid = $request->get('data_re');
        if(!empty($nid)){
            $redirect = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
        }
        
        $return['redirect'] = $redirect;
        return new JsonResponse($return);
    }
    
    public function user_bookmarks(){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        $data_val = array();
        
        if(!empty($user_id)){
            /* get tags: START */
            $tags_arr = array();
            $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
            foreach ($terms_data as $term) {
                $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
                $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
                $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;
//                $tags_arr[$term->tid] = $term->name;
            }
            /* get tags: END */

//            $qry = "SELECT node_id FROM custom_art_bookmark WHERE user_id = {$user_id} LIMIT 0, 8";
//            $query = $connection->query($qry);
//            $query_res = $query->fetchAll();
            
            $qry = "SELECT cab.*, nfd.title FROM `custom_art_bookmark` cab
                LEFT JOIN node_field_data nfd ON nfd.nid = cab.node_id
                WHERE nfd.langcode = 'en' 
                AND cab.user_id = {$user_id}
                ORDER BY cab.id DESC
                LIMIT 0, 8";
            $query = $connection->query($qry);
            $query_res = $query->fetchAll();
            
//            $nids = !empty($query_res) ? explode(",",$query_res->nids) : "";
            
//            $results = \Drupal::entityQuery('node')
//                ->condition('type','expert_advice')
//                ->condition('nid',$nids,"IN")
//                ->sort('created', 'DESC')
//                ->range(0, 8)
//                ->execute();
//                ->__toString();

//            $nodes =  \Drupal\node\Entity\Node::loadMultiple($results);
//            $articles = array();
            
            $articles = array();
			$data_val['articles_count'] = 0;
            if(!empty($query_res)){
                foreach($query_res AS $key => $val){
                    $nid = $val->node_id;
//                    $node_id = $this->encrypt_data($nid);
                    $node_id = CommonFunc::encryptData($nid);
                    $node_data = \Drupal\node\Entity\Node::load($nid);
                    $node_data = $node_data->getTranslation($lang_code);
                    $date_obj = $node_data->get('created')->getValue();
                    $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
                    $banner = $node_data->get('field_thum_image')->getValue();
                    $banner_id = $banner[0]['target_id'];
                    $banner_img = "";
                    if(!empty($banner_id)){
                        $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
                    }
                    $title = $node_data->get('title')->getValue();
                    $desc = $node_data->get('body')->getValue();
                    $category = $node_data->get('field_category')->getValue();
                    $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
                    $term_name = "";
                    if(!empty($category_id)){
                        $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
                        $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
                    }
                    $read_time = $node_data->get('field_length')->getValue();
                    $tags = $node_data->get('field_art_tags')->getValue();
                    $art_tags = array();
                    foreach($tags AS $key1 => $val1){
                        $art_tags[] = $tags_arr[$val1['target_id']];
                    }

                    $articles[$key]['nid'] = $nid;
                    $articles[$key]['node_id'] = $node_id;
                    $articles[$key]['title'] = !empty($title[0]) ? $title[0]['value'] : "";
                    $articles[$key]['img'] = $banner_img;
                    $articles[$key]['desc'] = !empty($desc[0]) ? $desc[0]['value'] : "";
                    $articles[$key]['cat'] = $term_name;
                    $articles[$key]['read_time'] = !empty($read_time[0]) ? $read_time[0]['value']." min read" : "";
                    $articles[$key]['tags'] = $art_tags;
                    $articles[$key]['bookmark'] = "active-bm";
                }
				$data_val['articles_count'] = count($articles);
            }
            
            $data_val['articles'] = $articles;
        }else{
            $redirect_url = $base_url . "/expert-advice";
            return new RedirectResponse($redirect_url);
        }
		
        $data_val['hindiLang'] = CommonFunc::isHindi();
        return array(
            '#theme' => 'user_bookmarks',
            '#data' => $data_val,
            '#cache' => ['max-age' => 0],
        );
    }
    
    public function get_bookmarks(){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        
        $cur_page = !empty($_POST['cur_page']) ? $_POST['cur_page'] : 0;
        $src_cont = !empty($_POST['src_cont']) ? $_POST['src_cont'] : "";
        $src_txt = !empty($_POST['src_txt']) ? $_POST['src_txt'] : "";
        $sort_val = !empty($_POST['sort_val']) ? $_POST['sort_val'] : "";
        
        /* get tags: START */
        $tags_arr = array();
        $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
        foreach ($terms_data as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;
//            $tags_arr[$term->tid] = $term->name;
        }
        /* get tags: END */
        
        $rec_start = !empty($cur_page) ? $cur_page * 8 : 0;
        $rec_limit = 8;
        
        $and_condition = "";
        if(!empty($src_txt)){
            /* search text in content body: START */
            $desc_qry = "SELECT GROUP_CONCAT(cab.node_id) AS node_ids FROM custom_art_bookmark cab LEFT JOIN `node__body` nb ON cab.node_id = nb.entity_id LEFT JOIN node_revision__body nrb ON nrb.revision_id = nb.revision_id WHERE nrb.bundle LIKE 'expert_advice' AND nrb.body_value LIKE '%".addslashes($src_txt)."%'";
            $desc_query = $connection->query($desc_qry);
            $desc_query_res = $desc_query->fetch();
            $desc_cond = "";
            if(!empty($desc_query_res)){
                $desc_cond = !empty($desc_query_res->node_ids) ? " OR cab.node_id IN(".$desc_query_res->node_ids.")" : "";
            }
            /* search text in content body: END */
            
            /* make a and condition for search: START */
            if(!empty($desc_cond)){
                $and_condition = " AND (nfd.title LIKE '%".addslashes($src_txt)."%' ".$desc_cond.")";
            }else{
                $and_condition = " AND nfd.title LIKE '%".addslashes($src_txt)."%'";
            }
            /* make a and condition for search: END */
        }
        
        if($sort_val == '1'){
            $sort_field = "cab.created_at";
            $sort_order = "DESC";
        }elseif($sort_val == '2'){
            $sort_field = "cab.art_popularity";
            $sort_order = "DESC";
        }else{
            $sort_field = "cab.id";
            $sort_order = "DESC";
        }
        
        $limit_condition = "";
        if(!empty($src_cont)){
            $limit_condition = " LIMIT {$rec_start}, {$rec_limit}";
        }
        
//        $qry = "SELECT node_id FROM custom_art_bookmark WHERE user_id = {$user_id} ORDER BY {$sort_field} {$sort_order} LIMIT {$rec_start}, {$rec_limit}";
//        $qry = "SELECT cab.*, nfd.title, (SELECT body_value FROM `node_revision__body` WHERE `entity_id` = cab.node_id ORDER BY `node_revision__body`.`revision_id` DESC LIMIT 1) AS body_value FROM `custom_art_bookmark` cab LEFT JOIN node_field_data nfd ON nfd.nid = cab.node_id WHERE nfd.langcode = 'en' AND cab.user_id = 1";
        $qry = "SELECT cab.*, nfd.title FROM `custom_art_bookmark` cab
            LEFT JOIN node_field_data nfd ON nfd.nid = cab.node_id
            WHERE nfd.langcode = 'en' 
            AND cab.user_id = {$user_id}
            {$and_condition}
            ORDER BY {$sort_field} {$sort_order}
            {$limit_condition}";
        $query = $connection->query($qry);
        $query_res = $query->fetchAll();
        
        $html = "";
        foreach($query_res AS $key => $val){
            $nid = $val->node_id;
//            $node_id = $this->encrypt_data($nid);
            $node_id = CommonFunc::encryptData($nid);
            $node_data = \Drupal\node\Entity\Node::load($nid);
            $node_data = $node_data->getTranslation($lang_code);
            $date_obj = $node_data->get('created')->getValue();
            $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
            $banner = $node_data->get('field_thum_image')->getValue();
            $banner_id = $banner[0]['target_id'];
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $title = $node_data->get('title')->getValue();
            $desc = $node_data->get('body')->getValue();
            $category = $node_data->get('field_category')->getValue();
            $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
            $term_name = "";
            if(!empty($category_id)){
                $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
                $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
            }
            $read_time = $node_data->get('field_length')->getValue();
            $tags = $node_data->get('field_art_tags')->getValue();
            
            $node_link = $base_url.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
            $art_title = !empty($title[0]) ? $title[0]['value'] : "";
            $ar_read_time = !empty($read_time[0]) ? $read_time[0]['value']." min read" : "";
            $art_tags = "";
            foreach($tags AS $key1 => $val1){
                $art_tags .= "<span>".$tags_arr[$val1['target_id']]."</span>";
            }
            
            if(!empty($src_cont)){
                $html .= '<div class="grid-item">
                    <div class="thumBox">
                        <div class="thumBoxinr">
                            <div class="thumCont"> <a href="javascript:void(0);" class="bookmark art-bookmark user-bookmarks active-bm" data-id="'.$node_id.'"><span></span></a>
                                <div class="thumImg">
                                    <a href="'.$node_link.'"><img src="'.$banner_img.'" alt="'.$art_title.'"></a>
                                </div>
                                <div class="thumText">
                                    <div class="meal-read">
                                        <div class="meal-type">Vegan</div>
                                        <div class="time-read">'.$ar_read_time.'</div>
                                    </div>
                                    <p><a href="'.$node_link.'">'.$art_title.'</a></p>
                                    <div class="tagbox">'.$art_tags.'</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
            }else{
                $html .= '<div class="src-art-cont srchDataItm"><a href="'.$node_link.'">'.$art_title.'</a></div>';
            }
        }
        
        $return['html'] = $html;
        return new JsonResponse($return);
    }
    
    public function related_articles(){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        $data_val = array();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        
        $article_str = \Drupal::request()->query->get('article');
        $nid = CommonFunc::decryptData($article_str);
        
        /* get categories: START */
        $art_cat = array();
        $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('expert_advice_topics');
        foreach ($terms as $term) {
//            $art_cat[$term->tid]['name'] = $term->name;
//            $term_link = \Drupal::service('path_alias.manager')->getAliasByPath('/taxonomy/term/'.$term->tid);
//            $art_cat[$term->tid]['url'] = $base_url.$term_link;
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $art_cat[$term->tid]['name'] = $taxonomy_term_trans->name->value;
            $term_link = \Drupal::service('path_alias.manager')->getAliasByPath('/taxonomy/term/'.$term->tid);
            $art_cat[$term->tid]['url'] = ($lang_code == "hi") ? $base_url.'/hindi'.$term_link : $base_url.$term_link;
        }
       
        $data_val['art_cat'] = $art_cat;
        /* get categories: END */
        
        /* reated articles: START */
        /* get tags: START */
        $tags_arr = array();
        $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
        foreach ($terms_data as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;
//            $tags_arr[$term->tid] = $term->name;
        }
        /* get tags: END */
        
        $node_data = \Drupal\node\Entity\Node::load($nid);
        $art_tags = $node_data->get('field_art_tags')->getValue();
        $art_tag[] = 0;
        foreach($art_tags AS $key1 => $val){
            $art_tag[] = $val['target_id'];
        }
//        $art_tag_ids = implode(",",$art_tag);
        
//        $query = \Drupal::entityQuery('node');
//        $group = $query
//            ->orConditionGroup()
//            ->condition('field_art_tags', $art_tag, 'IN')
//            ->condition('nid', $nid, '!=');
//        $query->condition('type','expert_advice')
////            ->condition('nid', '0', '>')
//            ->condition($group)
//            ->sort('created', 'DESC')
//            ->sort('field_art_tags', 'DESC')
//            ->range(0, 8);
        
        $query = \Drupal::entityQuery('node');
        $group1 = $query
            ->orConditionGroup()
            ->condition('field_art_tags', $art_tag, 'IN')
            ->condition('nid', $nid, '!=');
        
        $query->condition('type','expert_advice')
            ->condition('langcode', $lang_code)
            ->condition($group1)
            ->sort('field_art_tags', 'DESC')
            ->sort('created', 'DESC');
            
        $query->range(0, 8);
        
        $results = $query->execute();
//        dump($query->__toString());
//        print_r($results);
//        die();
        $nodes =  \Drupal\node\Entity\Node::loadMultiple($results);
        $related_art = array();
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $art_nid = $val->id();
            $node_id = CommonFunc::encryptData($art_nid);
            $title_obj = $val->get('title')->getValue();
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = !empty($banner) ? $banner[0]['target_id'] : "";
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }

            $read_time = $val->get('field_length')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = array();
            foreach($tags AS $key1 => $val1){
                $art_tags[] = $tags_arr[$val1['target_id']];
            }
            if(!empty($user_id)){
                $qry = "SELECT * FROM custom_art_bookmark WHERE user_id = {$user_id} AND node_id = {$art_nid}";
                $bookmark_query = $connection->query($qry);
                $bookmark_query_res = $bookmark_query->fetch();
            }
            $art_bookmark = !empty($bookmark_query_res) ? "active-bm" : "";
            
            $related_art[$key]['id'] = $node_id;
            $related_art[$key]['node_id'] = $art_nid;
            $related_art[$key]['title'] = !empty($title_obj[0]) ? $title_obj[0]['value'] : "";
            $related_art[$key]['img'] = $banner_img;
            $related_art[$key]['tags'] = $art_tags;
            $related_art[$key]['read_time'] = !empty($read_time[0]) ? $read_time[0]['value']. " min read" : "";
            $related_art[$key]['bookmark'] = $art_bookmark;
            $related_art[$key]['redirect'] = CommonFunc::encryptData($art_nid.'|articles|list'.$redirect_lang);
        }
//        echo "<pre>";
//        print_r($related_art);
//        die();
        $data_val['article_str'] = $article_str;
        $data_val['related_art'] = $related_art;
        /* reated articles: END */
        
        return array(
            '#theme' => 'related_articles',
            '#data' => $data_val,
            '#cache' => ['max-age' => 0],
        );
    }
    
    public function get_related_articles(Request $request){
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        $data_val = array();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        
//        echo $article_str = \Drupal::request()->query->get('cur_art');
        $article_str = $request->get('cur_art');
        $nid = CommonFunc::decryptData($article_str);
        $cur_page = $request->get('cur_page');
        $sort_val = $request->get('sort_val');
        $src_txt = $request->get('src_txt');
        $src_cond = $request->get('src_cond');
        
        /* reated articles: START */
        /* get tags: START */
        $tags_arr = array();
        $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
        foreach ($terms_data as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;
//            $tags_arr[$term->tid] = $term->name;
        }
        /* get tags: END */
        
        $node_data = \Drupal\node\Entity\Node::load($nid);
        $art_tags = $node_data->get('field_art_tags')->getValue();
        $art_tag[] = 0;
        foreach($art_tags AS $key1 => $val){
            $art_tag[] = $val['target_id'];
        }
//        $art_tag_ids = implode(",",$art_tag);
        
        $rec_start = !empty($cur_page) ? $cur_page * 8 : 0;
        $rec_limit = 8;
        
        if($sort_val == '1'){
            $sort_field = "created";
            $sort_order = "DESC";
        }elseif($sort_val == '2'){
            $sort_field = "field_art_popularity";
            $sort_order = "DESC";
        }else{
            $sort_field = "created";
            $sort_order = "DESC";
        }
        

        
        $query = \Drupal::entityQuery('node');
        $group1 = $query
            ->orConditionGroup()
            ->condition('field_art_tags', $art_tag, 'IN')
            ->condition('nid', $nid, '!=');
        
        if(!empty($src_txt)){
            $group2 = $query
                ->orConditionGroup()
                ->condition('title', $src_txt, 'CONTAINS')
                ->condition('body', $src_txt, 'CONTAINS');
        }
        
        if(!empty($group2)){
            $query->condition($group2);
        }
        
        $query->condition('type','expert_advice')
            ->condition('langcode', $lang_code)
            ->condition($group1)
            ->sort($sort_field, $sort_order)
            ->sort('field_art_tags', 'DESC');
            
        if(empty($src_cond)){
            $query->range($rec_start, $rec_limit);
        }
        $results = $query->execute();
        
        $nodes =  \Drupal\node\Entity\Node::loadMultiple($results);
        $html = "";
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $art_nid = $val->id();
            $node_id = CommonFunc::encryptData($art_nid);
            $title_obj = $val->get('title')->getValue();
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = !empty($banner) ? $banner[0]['target_id'] : "";
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }

            $read_time = $val->get('field_length')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = '';
            foreach($tags AS $key1 => $val1){
                $art_tags .= "<span>".$tags_arr[$val1['target_id']]."</span>";
            }
            if(!empty($user_id)){
                $qry = "SELECT * FROM custom_art_bookmark WHERE user_id = {$user_id} AND node_id = {$art_nid}";
                $bookmark_query = $connection->query($qry);
                $bookmark_query_res = $bookmark_query->fetch();
            }
            $art_bookmark = !empty($bookmark_query_res) ? "active-bm" : "";
            
            $title = !empty($title_obj[0]) ? $title_obj[0]['value'] : "";
            $node_link = $base_url.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$art_nid);
            $art_read_time = !empty($read_time[0]) ? $read_time[0]['value']. " min read" : "";
            $redirect = CommonFunc::encryptData($art_nid.'|articles|list'.$redirect_lang);
            
            if(empty($src_cond)){
                $html .= '<div class="grid-item">
                        <div class="thumBox">
                            <div class="thumBoxinr">
                                <div class="thumCont">
                                    <a href="javascript:void(0);" class="bookmark art-bookmark '.$art_bookmark.'" data-id="'.$node_id.'" data-re="'.$redirect.'"><span></span></a>
                                    <div class="thumImg">
                                        <a href="'.$node_link.'"><img src="'.$banner_img.'" alt="'.$title.'"></a>
                                    </div>
                                    <div class="thumText">
                                        <div class="meal-read">
                                            <div class="meal-type">Vegan</div>
                                            <div class="time-read">'.$art_read_time.'</div>
                                        </div>
                                        <p><a href="'.$node_link.'">'.$title.'</a></p>
                                        <div class="tagbox">'.$art_tags.'</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
            }else{
                $html .= '<div class="src-art-cont srchDataItm"><a href="'.$node_link.'">'.$title.'</a></div>';
            }
        }

        
        $return['html'] = $html;
        return new JsonResponse($return);
    }
    
	public function ExpertSearch() {
		
		global $base_url;
		
		$keyword = \Drupal::request()->query->get('searchExpertData');

        $keyword = Xss::filter($keyword, []);
	     	
   
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $roles = $user->getRoles();
        $user_id = $user->id();
        $data_val = array();
        $data_val['searchkeyword'] = $keyword;
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        $language =  \Drupal::languageManager()->getCurrentLanguage()->getName();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        /* get tags: START */
        $tags_arr = array();
        $tag_query = \Drupal::entityQuery('taxonomy_term');
        $tag_query->condition('vid', "dsu_tag");
        $tag_term = $tag_query->execute();
        foreach ($tag_term as $tag) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($tag);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$tag] = $taxonomy_term_trans->name->value;
        }
        /* get tags: END */
        
        /* get categories: START */
        
        
        /* get categories: END */
        
        /* get article list: START */
        $query = \Drupal::entityQuery('node')
            ->condition('type', 'expert_advice', '=')
			->condition('status', 1)
            ->condition('langcode', $lang_code);
        // OR Condition
      $ea_group = $query->orConditionGroup()
        ->condition('title', $keyword, 'CONTAINS')
        ->condition('body', $keyword, 'CONTAINS');
       $nids = $query->condition($ea_group)->sort('created', 'DESC')->execute();		
       $articles = array();
		
        if(!empty($nids)) {
         $data_val['searchCount'] = count($nids);		 
         $nodes =  \Drupal\node\Entity\Node::loadMultiple($nids);
        $i = 0;
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $nid = $val->id();

            $node_id = CommonFunc::encryptData($nid);
            $date_obj = $val->get('created')->getValue();
            $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = $banner[0]['target_id'];
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $title = $val->get('title')->getValue();
            $desc = $val->get('body')->getValue();
            $category = $val->get('field_category')->getValue();
            $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
            $term_name = "";
            if(!empty($category_id)){
                $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
				if($term_data ) {
                $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
				}
            }
            $read_time = $val->get('field_length')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = array();
            foreach($tags AS $key1 => $val1){
                $art_tags[] = $tags_arr[$val1['target_id']];
            }
            
            if(!empty($user_id)){
                $qry = "SELECT * FROM custom_art_bookmark WHERE user_id = {$user_id} AND node_id = {$nid}";
                $query = $connection->query($qry);
                $query_res = $query->fetch();
            }
            $bookmark = !empty($query_res) ? "active-bm" : "";
            
            $articles[$key]['id'] = $node_id;
            $articles[$key]['title'] = !empty($title[0]) ? $title[0]['value'] : "";
            $articles[$key]['img'] = $banner_img;
            $articles[$key]['cat'] = $term_name;
            $articles[$key]['read_time'] = !empty($read_time[0]) ? $read_time[0]['value']." min read" : "";
            $articles[$key]['tags'] = $art_tags;
            $articles[$key]['bookmark'] = $bookmark;

            $articles[$key]['redirect'] = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
			if($i==7){

             break;
            }
			$i++;
        }
        
	    }
		
        $data_val['articles'] = $articles;
		
        $data_val['redirect_lang'] = $redirect_lang;
		$data_val['is_hindi'] = CommonFunc::isHindi();
        $data_val['is_user'] = !empty($user_id) ? "1" : "";
		
        /* get article list: END */
        //echo "<pre>";
		//print_r($data_val);
		//die;
        return array(
            '#theme' => 'articleSearch',
            '#data' => $data_val,
            '#cache' => ['max-age' => 0],
        );
		
	}
	
	public function expertsearchLoadMore(Request $request) {
		global $base_url;
		\Drupal::service('page_cache_kill_switch')->trigger();
		$hindi = CommonFunc::isHindi();
		
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $roles = $user->getRoles();
        $user_id = $user->id();
        $data_val = array();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        

        $keyword = $request->query->get('src_txt');

		$pageNo = $request->query->get('cur_page');
		if($pageNo) {
			$pagerRow = $pageNo*8-8;
		} else {
			$pagerRow = 1;
		}
        
       
        /* get tags: START */
        $tags_arr = array();
        $terms_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree('dsu_tag');
        foreach ($terms_data as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term->tid);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term->tid] = $taxonomy_term_trans->name->value;

        }
        /* get tags: END */
        
        /* get article list: START */
        

        
        $query = \Drupal::entityQuery('node');
		if(!empty($keyword)){
            $group = $query
                ->orConditionGroup()
                ->condition('title', $keyword, 'CONTAINS')
                ->condition('body', $keyword, 'CONTAINS');
        }
        
       if(!empty($group)){
            $query->condition($group);
        }
        
		$results = $query->condition('type','expert_advice')
			->condition('status',1)
            ->range($start, $limit)
			->range($pagerRow, 8)
            ->execute();
			
	    
        $nodes =  \Drupal\node\Entity\Node::loadMultiple($results);
        $articles = array();
        $html = "";
        foreach($nodes AS $key => $val){
            $val = $val->getTranslation($lang_code);
            $nid = $val->id();
//            $node_id = $this->encrypt_data($val->id());
            $node_id = CommonFunc::encryptData($nid);
            $date_obj = $val->get('created')->getValue();
            $created = !empty($date_obj[0]) ? date("Y-m-d", $date_obj[0]['value']) : "";
            $banner = $val->get('field_thum_image')->getValue();
            $banner_id = !empty($banner) ? $banner[0]['target_id'] : "";
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $title_obj = $val->get('title')->getValue();
			if($hindi){
				$node_link = $base_url.'/hindi'.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$key);
			} else {
				$node_link = $base_url.\Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$key); 
			}
            
            $desc_obj = $val->get('body')->getValue();
            $category = $val->get('field_category')->getValue();
            $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
            $term_name = "";
            
            $read_time_obj = $val->get('field_length')->getValue();
            $tags = $val->get('field_art_tags')->getValue();
            $art_tags = "";
            foreach($tags AS $key1 => $val){
                $art_tags .= "<span>".$tags_arr[$val['target_id']]."</span>";
            }
            
            $title = !empty($title_obj[0]) ? $title_obj[0]['value'] : "";
            $img = $banner_img;
            $desc = !empty($desc_obj[0]) ? $desc_obj[0]['value'] : "";

            $tags = $art_tags;
            $read_time = !empty($read_time_obj[0]) ? $read_time_obj[0]['value']." min read" : "";
			
            //$redirect = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
            
            
                $html .= '<div class="grid-item">
                    <div class="thumBox">
                        <div class="thumBoxinr">
                            <div class="thumCont"> <a href="javascript:void(0);" class="bookmark art-bookmark" data-id="'.$node_id.'" data-re="'.$redirect.'"><span></span></a>
                                <div class="thumImg articlethumbimg">
                                    <a href="'.$node_link.'"><img src="'.$img.'" alt="'.$title.'"></a>
                                </div>
                                <div class="thumText">
                                    <div class="meal-read">
                                        <div class="meal-type">Vegan</div>
                                        <div class="time-read">'.$read_time.'</div>
                                    </div>
                                    <p><a href="'.$node_link.'">'.$title.'</a></p>
                                    <div class="tagbox">
                                        '.$art_tags.'
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
            
            
        }
        /* get article list: END */
        
        $return['html'] = $html;
        return new JsonResponse($return);
		
		
	}
    
}