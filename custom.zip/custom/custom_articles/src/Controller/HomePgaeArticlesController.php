<?php

namespace Drupal\custom_articles\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\file\Entity\File;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\Response;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\comment\Entity\Comment;
use Drupal\Core\Language\LanguageManager;
use Drupal\Component\Utility\Xss;
use Drupal\taxonomy\Entity\Term;

class HomePgaeArticlesController extends ControllerBase {

    public static function HomeLatestArticle() {
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();

        $article = array();
        $langCode = CommonFunc::multilingualConvert("lang");
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";

        $ea_query = \Drupal::entityQuery('node')
            ->range(0, 4)
            ->condition('status', 1)
            ->condition('type', 'expert_advice', '=');
        $ea_nids = $ea_query->sort('created', 'DESC')->execute();

        $ea_nodes = Node::loadMultiple($ea_nids);
        $search['countArticlePage'] = count($ea_nids);

        # get tag list
        $tags_arr = array();
        $tag_query = \Drupal::entityQuery('taxonomy_term');
        $tag_query->condition('vid', "dsu_tag");
        $tag_term = $tag_query->execute();
        foreach ($tag_term as $term) {
            $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term);
            $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
            $tags_arr[$term] = $taxonomy_term_trans->name->value;
        }
        
        foreach ($ea_nodes as $node) {
            $node = $node->getTranslation($langCode);
            $nid = $node->get('nid')->value;
            $node_id = CommonFunc::encryptData($nid);
//            if ($node->field_thum_image) {
//                if ($node->field_thum_image->getValue()) {
//                    $file_image = File::load($node->field_thum_image->getValue()[0]['target_id']);
//                    $original_image = $file_image->getFileUri();
//                    $image_path = file_url_transform_relative(file_create_url($original_image));
//                    $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('webp');
//                    $article1['thumb'] = file_create_url($style->buildUri($original_image));
//                    $article1['original'] = $image_path;
//                } else {
//                    $article1['thumb'] = '';
//                    $article1['original'] = '';
//                }
//            } else {
//                $article1['thumb'] = '';
//                $article1['original'] = '';
//            }
            $banner = $node->field_thum_image->getValue();
            $banner_id = $banner[0]['target_id'];
            $banner_img = "";
            if(!empty($banner_id)){
                $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
            }
            $article1['thumb'] = $banner_img;

            if (!empty($user_id)) {
                $qry = "SELECT * FROM custom_art_bookmark WHERE user_id = {$user_id} AND node_id = {$nid}";
                $query = $connection->query($qry);
                $query_res = $query->fetch();
            }
            $bookmark = !empty($query_res) ? "active-bm" : "";

            $date = $node->get('created')->value;
            $article1['created_date'] = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
            $article1['read_time'] = $node->get('field_read_time')->value;
            $article1['author'] = $node->get('field_author')->value;
//            $term = Term::load($node->get('field_category')->target_id);
//            $article1['tag'] = $term->getName();
            $tags = $node->get('field_art_tags')->getValue();
            $art_tags = array();
            foreach ($tags AS $key1 => $val1) {
                $art_tags[] = $tags_arr[$val1['target_id']];
            }
            $article1['tags'] = $art_tags;
            $article1['title'] = $node->getTitle();
            $alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/' . $nid);
            $article1['node_url'] = $alias_url;
            $article1['bookmark'] = $bookmark;
            $article1['id'] = $node_id;
            $article1['redirect'] = CommonFunc::encryptData($nid . '|articles|list' . $redirect_lang);

            $article[] = $article1;
        }

        $data['article'] = $article;
        $data['hindiLng'] = CommonFunc::isHindi();
        return [
            '#theme' => 'HomeRecentArticle',
            '#params' => $data,
        ];
    }

    public static function HomeBookMarkArticle() {
        global $base_url;
        $connection = \Drupal::database();
        $user = \Drupal::currentUser();
        $user_id = $user->id();
        
        $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
        $redirect_hindiLang = CommonFunc::isHindi();
        $redirect_lang = ($redirect_hindiLang) ? "|hi" : "";

        if (!empty($user_id)) {
            # get tag list
            $tags_arr = array();
            $tag_query = \Drupal::entityQuery('taxonomy_term');
            $tag_query->condition('vid', "dsu_tag");
            $tag_term = $tag_query->execute();
            foreach ($tag_term as $term) {
                $taxonomy_term = \Drupal\taxonomy\Entity\Term::load($term);
                $taxonomy_term_trans = \Drupal::service('entity.repository')->getTranslationFromContext($taxonomy_term, $lang_code);
                $tags_arr[$term] = $taxonomy_term_trans->name->value;
//                $tags_arr[$term->tid] = $term->name;
            }
            $data['alltag'] = $tags_arr;
            
            $qry = "SELECT cab.*, nfd.title FROM `custom_art_bookmark` cab
                LEFT JOIN node_field_data nfd ON nfd.nid = cab.node_id
                WHERE nfd.langcode = 'en' 
                AND cab.user_id = {$user_id}
                ORDER BY cab.id DESC
                LIMIT 0, 4";
            $query = $connection->query($qry);
            $query_res = $query->fetchAll();
            $article1 = array();
            if (!empty($query_res)) {
                foreach ($query_res AS $key => $val) {
                    $nid = $val->node_id;
                    $node_id = CommonFunc::encryptData($nid);
                    $node_data = \Drupal\node\Entity\Node::load($nid);
                    $node_data = $node_data->getTranslation($lang_code);
                    $date_obj = $node_data->get('created')->getValue();
//                    if ($node_data->field_thum_image) {
//                        if ($node_data->field_thum_image->getValue()) {
//                            $file_image = File::load($node_data->field_thum_image->getValue()[0]['target_id']);
//                            $original_image = $file_image->getFileUri();
//                            $image_path = file_url_transform_relative(file_create_url($original_image));
//                            $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('webp');
//                            $article1['thumb'] = file_create_url($style->buildUri($original_image));
//                            $article1['original'] = $image_path;
//                        } else {
//                            $article1['thumb'] = '';
//                            $article1['original'] = '';
//                        }
//                    } else {
//                        $article1['thumb'] = '';
//                        $article1['original'] = '';
//                    }
                    $banner = $node_data->get('field_thum_image')->getValue();
                    $banner_id = $banner[0]['target_id'];
                    $banner_img = "";
                    if(!empty($banner_id)){
                        $banner_img = \Drupal\file\Entity\File::load($banner_id)->createFileUrl();
                    }
                    $article1['thumb'] = $banner_img;
                    $article1['id'] = $node_id;
                    $article1['title'] = $node_data->get('title')->getValue()[0]['value'];
                    $article1['read_time'] = $node_data->get('field_length')->getValue()[0]['value'];
                    $article1['author'] = $node_data->get('field_author')->getValue()[0]['value'];
                    $category = $node_data->get('field_category')->getValue();
                    $category_id = !empty($category[0]['target_id']) ? $category[0]['target_id'] : "";
                    $term_name = "";
                    if (!empty($category_id)) {
                        $term_data = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($category_id);
                        $term_name = !empty($term_data->get('name')->getValue()) ? $term_data->get('name')->getValue()[0]['value'] : "";
                    }
                    $article1['term_name'] = $term_name;
                    $alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/' . $nid);
                    $article1['node_url'] = $alias_url;
                    $tags = $node_data->get('field_art_tags')->getValue();
                    $art_tags = array();
                    foreach ($tags AS $key1 => $val1) {
                        $art_tags[] = $tags_arr[$val1['target_id']];
                    }
                    $article1['tags'] = $art_tags;
                    $article1['bookmark'] = "active-bm";
                    $article1['redirect'] = CommonFunc::encryptData($nid.'|articles|list'.$redirect_lang);
                    
                    $article[] = $article1;
                }
            }
            $data['article'] = $article;
            $data['hindiLng'] = CommonFunc::isHindi();
        } else {
            $data = array();
        }

        return [
            '#theme' => 'HomeBookMarkArticle',
            '#params' => $data,
        ];
    }

    public function encrypt_data($data) {
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'unique_secret_key';
        $secret_iv = 'unique_secret_iv';
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16);
        $output = openssl_encrypt($data, $encrypt_method, $key, 0, $iv);

        return base64_encode($output);
    }

}
