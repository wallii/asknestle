<?php

namespace Drupal\nestle_health_tracker\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\taxonomy\Entity\Term;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\Core\Language\LanguageManager;


/**
 * Defines a controller to fetching records and return growth tracker data.
 */
class HomeGrowthTracker extends ControllerBase {
	
	/**
	* Display child growth data with parameters for register user .
	*/
	public static function homeTracking() {
		global $base_url;
		$hindi = CommonFunc::isHindi();
		$vital_data = '';
		if (\Drupal::currentUser()->isAnonymous()) {
			if ($hindi) {
				return new RedirectResponse($base_url . '/hindi/growth-track');
			} 
			else {
				return new RedirectResponse($base_url . '/growth-track');
			}
		} else {
			$vitals = NestleAPI::showVitals();
			$gender = 1;
			if($gender == 1) {
				$heightImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_image_1');
				$widthtImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_image_2');
			} else {
				$heightImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_female_1');
				$widthtImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_female_2');
			}
			if ($vitals != 0) {
				$keys = array_keys($vitals);
				$childageinMonth = $vitals[$keys[0]]['age_in_months'];
				
				if($childageinMonth >= 24 &&  $childageinMonth <= 60) {
				$childBMICondition = 'bmitoddler';
				} elseif($childageinMonth >= 61 &&  $childageinMonth <= 215) {
				$childBMICondition = 'bmikids';
				} elseif($childageinMonth >= 216 &&  $childageinMonth <= 600) {
				$childBMICondition = 'bmiadult';
				} else {
				$childBMICondition = 'bmiadult';
				}
				$vital['vitalbmiconditions'] = $childBMICondition;
				$vital['vitalbmiconditions'] = $childBMICondition;
				$vital['vitalbmivalue'] = $vitals[$keys[0]]['bmi']['value'];
				$vital['bmifooterdesc'] = $vitals[$keys[0]]['bmi_category']['meal_plan_dec'];
				$height = $vitals[$keys[0]]['height'];
				$ideal_height_from = $vitals[$keys[0]]['height_range'][0];

				$ideal_height_to = $vitals[$keys[0]]['height_range'][1];

				$weight = number_format($vitals[$keys[0]]['weight'], 1);
				if (is_numeric($vitals[$keys[0]]['weight_range'][0])) {
					$ideal_weight_from = number_format($vitals[$keys[0]]['weight_range'][0], 1);
				} 
				else {
					$ideal_weight_from = $vitals[$keys[0]]['weight_range'][0];
				}
				$ideal_weight_to = number_format($vitals[$keys[0]]['weight_range'][1], 1);
				$keys = array_keys($vitals);
				
				$vital['name'] = ucwords('test');
				$vital['date'] = $keys[0];
				$vital['height'] = $height;
				$vital['weight'] = $weight;
				$vital['ideal_height_from'] = $ideal_height_from;
				$vital['ideal_height_to'] = $ideal_height_to;
				$vital['ideal_weight_from'] = $ideal_weight_from;
				$vital['ideal_weight_to'] = $ideal_weight_to;
				$hgtWeightVal = [
					'height' => $height,
					'weight' => $weight,
					'ideal_height_from' => $ideal_height_from,
					'ideal_height_to' => $ideal_height_to,
					'ideal_weight_from' => $ideal_weight_from,
					'ideal_weight_to' => $ideal_weight_to,
				];
				$childhgtwgtStatus = CommonFunc::childHeightWgt($hgtWeightVal);
				$vital['weightClass'] = $childhgtwgtStatus['weightClass'];
				$vital['heightClass'] = $childhgtwgtStatus['heightClass'];
				
				$vital['heightImg'] = $heightImg;

				$vital['weightImg'] = $widthtImg;
				
				if ($hindi) {
					$checkBmi_type = $vitals[$keys[0]]['bmi_category']['bmi'];
					$vital_bmi_type = explode(" और ", $checkBmi_type);
					if (array_key_exists(0, $vital_bmi_type)) {
					$vital['weight_title'] = $vital_bmi_type[0];
					} 
					else {
					$vital['weight_title'] = '';
					}
					if (array_key_exists(1, $vital_bmi_type)) {
					$vital['height_title'] = $vital_bmi_type[1];
					} 
					else {
					$vital['height_title'] = '';
					}
				} else {
					$checkBmi_type = $vitals[$keys[0]]['bmi_category']['bmi_type'];
					$vital_bmi_type = explode("_", $checkBmi_type);
					if (array_key_exists(0, $vital_bmi_type)) {
					$vital['weight_title'] = ucfirst($vital_bmi_type[0]);
					} 
					else {
					$vital['weight_title'] = '';
					}
					if (array_key_exists(2, $vital_bmi_type)) {
					$vital['height_title'] = ucfirst($vital_bmi_type[2]);
					} 
					else {
					$vital['height_title'] = '';
					}
					$growth_tracker_weight_desc = $vitals[$keys[0]]['bmi_category']['growth_tracker_weight_desc'];
					if(isset($growth_tracker_weight_desc) && !empty($growth_tracker_weight_desc)){

						$vital['growth_tracker_weight_desc'] = $vitals[$keys[0]]['bmi_category']['growth_tracker_weight_desc'];

						$vital['desc'] = $vitals[$keys[0]]['bmi_category']['growth_tracker_desc'];
					}else{

						$vital['desc'] = $vitals[$keys[0]]['bmi_category']['growth_tracker_desc'];

					}
				}
				
				
				
				
				
			} else {
			  $vital = array(); 
			}
			
			$vital['welcomepage_txt'] = CommonFunc::getConfigPageFieldValue('nestle_health_tracker_form', 'field_faq_text');
			$vital['hindi'] = $hindi;
			$vital['base_url'] = $base_url;
			return [
				'#theme' => 'HomeRegTracking',
				'#params' => $vital,
				'#attached' => [
					'library' => 'nestle_health_tracker/nestle_health_tracker_style',
				],
			];
		}
	}

  
}
