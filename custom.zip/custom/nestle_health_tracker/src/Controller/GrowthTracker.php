<?php

namespace Drupal\nestle_health_tracker\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\taxonomy\Entity\Term;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\Core\Language\LanguageManager;


/**
 * Defines a controller to fetching records and return growth tracker data.
 */
class GrowthTracker extends ControllerBase {
	/**
	* Get unregister user child growth data .
	*/
	public function unregTracking() {
		global $base_url;
		$hindi = CommonFunc::isHindi();
		$session = \Drupal::request()->getSession();
        $growth_data = $session->get('growth_data');
		if (empty($growth_data)) {
			if ($hindi) {
				return new RedirectResponse($base_url . '/hi/growth-track');
			} 
			else {
				return new RedirectResponse($base_url . '/growth-track');
			}
		} else {
			$data = [
				'year' => $growth_data['dobYr'],
				'month' => $growth_data['dobMth'],
				'gender_id' => $growth_data['gender'],
				'height' => $growth_data['height'],
				'weight' => $growth_data['weight'],
			];
			$data = CommonFunc::APiHindi($data);
			$response = NestleAPI::saveVitalNotLogin($data);
			if($growth_data['gender'] == 1) {
				$heightImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_image_1');
				$widthtImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_image_2');
			} else {
				$heightImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_female_1');
				$widthtImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_female_2');
			}
			$unregResTopHeading = CommonFunc::getConfigPageFieldValue('nestle_health_tracker_form', 'field_inner_welcome');
			$unregResTopDesc = CommonFunc::getConfigPageFieldValue('nestle_health_tracker_form', 'field_inner_desclaimer');
			$unregResFooterDesc = CommonFunc::getConfigPageFieldValue('nestle_health_tracker_form', 'field_footer_disclaimer');
			$height = $response['contents']['height'];
			$weight = $response['contents']['weight'];
			$childageyeracond = (int)$response['contents']['age'];
			if($childageyeracond >= 2 &&  $childageyeracond <= 5) {
				$childBMICondition1 = 'bmitoddler';
			} elseif($childageyeracond >= 6 &&  $childageyeracond <= 17) {
				$childBMICondition1 = 'bmikids';
			} elseif($childageyeracond >= 18 &&  $childageyeracond <= 50) {
				$childBMICondition1 = 'bmiadult';
			} else {
				$childBMICondition1 = 'bmiadult';
			}
			$gTrack['vitalbmiconditions'] = $childBMICondition1;
			$gTrack['vitalbmivalue'] = $response['contents']['bmi_value'];
			$gTrack['gender'] = $growth_data['gender'];
			$gTrack['height'] = $height;
			$gTrack['weight'] = $weight;
			$heightRange = $response['contents']['ideal_body_height_range'];
			$ideal_height_range = explode('-', $heightRange);
			$weightRange = $response['contents']['ideal_body_weight_range'];
			$ideal_weight_range = explode('-', $weightRange);
			$ideal_height_from = $ideal_height_range[0];
			$ideal_height_to = $ideal_height_range[1];
			if (is_numeric($ideal_weight_range[0])){
				$ideal_weight_from = number_format($ideal_weight_range[0], 1);
			} 
			else {
				$ideal_weight_from = $ideal_weight_range[0];
			}
			$ideal_weight_to = number_format($ideal_weight_range[1], 1);
			$gTrack['ideal_height_from'] = $ideal_height_from;
			$gTrack['ideal_height_to'] = $ideal_height_to;
			$gTrack['ideal_weight_from'] = $ideal_weight_from;
			$gTrack['ideal_weight_to'] = $ideal_weight_to;
			$gTrack['heightImg'] = $heightImg;
			$gTrack['weightImg'] = $widthtImg;
			$hgtWeightVal = [
				'height' => $height,
				'weight' => $weight,
				'ideal_height_from' => $ideal_height_from,
				'ideal_height_to' => $ideal_height_to,
				'ideal_weight_from' => $ideal_weight_from,
				'ideal_weight_to' => $ideal_weight_to,
			];
			$childhgtwgtStatus = CommonFunc::childHeightWgt($hgtWeightVal);
			$gTrack['weightClass'] = $childhgtwgtStatus['weightClass'];
            $gTrack['heightClass'] = $childhgtwgtStatus['heightClass'];
			$gTrack['height_title'] = "";
            $gTrack['weight_title'] = $response['contents']['bmi'];
			$gTrack['output_header_txt'] = $unregResTopHeading;
			$gTrack['output_header_desc'] = $unregResTopDesc;
			$gTrack['output_footer_desc'] = $unregResFooterDesc;
            $gTrack['hindi'] = $hindi;
			
			return [
				'#theme' => 'Tracking',
				'#params' => $gTrack,
				'#attached' => [
					'library' => 'nestle_health_tracker/nestle_health_tracker_style',
				],
			];
		}

	}
	
	/**
	* Display child growth data with parameters for register user .
	*/
	public function tracking() {
		global $base_url;
		$hindi = CommonFunc::isHindi();
		$vital_data = '';
		if (\Drupal::currentUser()->isAnonymous()) {
			if ($hindi) {
				return new RedirectResponse($base_url . '/hindi/growth-track');
			} 
			else {
				return new RedirectResponse($base_url . '/growth-track');
			}
		} else {
			$vitals = NestleAPI::showVitals();
			$gender = 1;
			if($gender == 1) {
				$heightImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_image_1');
				$widthtImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_image_2');
			} else {
				$heightImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_female_1');
				$widthtImg = CommonFunc::getConfigPageImageFieldValue('global_site_settings', 'field_health_track_male_female_2');
			}
			if ($vitals != 0) {
				$keys = array_keys($vitals);
				$childageinMonth = $vitals[$keys[0]]['age_in_months'];
				
				if($childageinMonth >= 24 &&  $childageinMonth <= 60) {
				$childBMICondition = 'bmitoddler';
				} elseif($childageinMonth >= 61 &&  $childageinMonth <= 215) {
				$childBMICondition = 'bmikids';
				} elseif($childageinMonth >= 216 &&  $childageinMonth <= 600) {
				$childBMICondition = 'bmiadult';
				} else {
				$childBMICondition = 'bmiadult';
				}
				$vital['vitalbmiconditions'] = $childBMICondition;
				$vital['vitalbmiconditions'] = $childBMICondition;
				$vital['vitalbmivalue'] = $vitals[$keys[0]]['bmi']['value'];
				$vital['bmifooterdesc'] = $vitals[$keys[0]]['bmi_category']['meal_plan_dec'];
				$height = $vitals[$keys[0]]['height'];
				$ideal_height_from = $vitals[$keys[0]]['height_range'][0];

				$ideal_height_to = $vitals[$keys[0]]['height_range'][1];

				$weight = number_format($vitals[$keys[0]]['weight'], 1);
				if (is_numeric($vitals[$keys[0]]['weight_range'][0])) {
					$ideal_weight_from = number_format($vitals[$keys[0]]['weight_range'][0], 1);
				} 
				else {
					$ideal_weight_from = $vitals[$keys[0]]['weight_range'][0];
				}
				$ideal_weight_to = number_format($vitals[$keys[0]]['weight_range'][1], 1);
				$keys = array_keys($vitals);
				
				$vital['name'] = ucwords('test');
				$vital['date'] = $keys[0];
				$vital['height'] = $height;
				$vital['weight'] = $weight;
				$vital['ideal_height_from'] = $ideal_height_from;
				$vital['ideal_height_to'] = $ideal_height_to;
				$vital['ideal_weight_from'] = $ideal_weight_from;
				$vital['ideal_weight_to'] = $ideal_weight_to;
				$hgtWeightVal = [
					'height' => $height,
					'weight' => $weight,
					'ideal_height_from' => $ideal_height_from,
					'ideal_height_to' => $ideal_height_to,
					'ideal_weight_from' => $ideal_weight_from,
					'ideal_weight_to' => $ideal_weight_to,
				];
				$childhgtwgtStatus = CommonFunc::childHeightWgt($hgtWeightVal);
				$vital['weightClass'] = $childhgtwgtStatus['weightClass'];
				$vital['heightClass'] = $childhgtwgtStatus['heightClass'];
				
				$vital['heightImg'] = $heightImg;

				$vital['weightImg'] = $widthtImg;
				
				if ($hindi) {
					$checkBmi_type = $vitals[$keys[0]]['bmi_category']['bmi'];
					$vital_bmi_type = explode(" और ", $checkBmi_type);
					if (array_key_exists(0, $vital_bmi_type)) {
					$vital['weight_title'] = $vital_bmi_type[0];
					} 
					else {
					$vital['weight_title'] = '';
					}
					if (array_key_exists(1, $vital_bmi_type)) {
					$vital['height_title'] = $vital_bmi_type[1];
					} 
					else {
					$vital['height_title'] = '';
					}
				} else {
					$checkBmi_type = $vitals[$keys[0]]['bmi_category']['bmi_type'];
					$vital_bmi_type = explode("_", $checkBmi_type);
					if (array_key_exists(0, $vital_bmi_type)) {
					$vital['weight_title'] = ucfirst($vital_bmi_type[0]);
					} 
					else {
					$vital['weight_title'] = '';
					}
					if (array_key_exists(2, $vital_bmi_type)) {
					$vital['height_title'] = ucfirst($vital_bmi_type[2]);
					} 
					else {
					$vital['height_title'] = '';
					}
					$growth_tracker_weight_desc = $vitals[$keys[0]]['bmi_category']['growth_tracker_weight_desc'];
					if(isset($growth_tracker_weight_desc) && !empty($growth_tracker_weight_desc)){

						$vital['growth_tracker_weight_desc'] = $vitals[$keys[0]]['bmi_category']['growth_tracker_weight_desc'];

						$vital['desc'] = $vitals[$keys[0]]['bmi_category']['growth_tracker_desc'];
					}else{

						$vital['desc'] = $vitals[$keys[0]]['bmi_category']['growth_tracker_desc'];

					}
				}
				
				
				
				
				
			} else {
			  $vital = $vital_data; 
			}
			
			$vital['footer_disclaimer'] = CommonFunc::getConfigPageFieldValue('nestle_health_tracker_form', 'field_unreg_meal_head_desc');
			$vital['welcomepage_txt'] = CommonFunc::getConfigPageFieldValue('nestle_health_tracker_form', 'field_recipe_top_tab');
			$vital['hindi'] = $hindi;
			$vital['base_url'] = $base_url;
			return [
				'#theme' => 'RegTracking',
				'#params' => $vital,
				'#attached' => [
					'library' => 'nestle_health_tracker/nestle_health_tracker_style',
				],
			];
		}
	}

  
}
