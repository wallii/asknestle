<?php

namespace Drupal\nestle_health_tracker\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\config_pages\Entity\ConfigPages;

/**
 * Form to handle growth tracking form functionality.
 */
class HealthTrackerForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'health_tracker_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $base_url;
    //get the field value from the custom ]health tracker config page
    $healthTrackerConfigPage = ConfigPages::config('nestle_health_tracker_form');
    $heading_1 = $healthTrackerConfigPage->get('field_api_key')->value;
	$heading_desc = $healthTrackerConfigPage->get('field_unreg_meal_paragraph')->value;
    $heading_2 = $healthTrackerConfigPage->get('field_heading_2')->value;
    $disclaimer = $healthTrackerConfigPage->get('field_disclaimer')->value;
    $btn_text = $healthTrackerConfigPage->get('field_button_text')->value;
    if (\Drupal::currentUser()->isAnonymous()) {
      $form['form_heading'] =[
        '#markup' => $heading_1
      ];
	  $form['form_heading_desc'] =[
        '#markup' => $heading_desc
      ];
      $form['form_select_gender_head'] = [
        '#markup' => $heading_2
      ];
      $options = [
        '1' => t('Male'),
        '2' => t('Female'),
      ];
      $form['gender'] = [
        '#type' => 'radios',
        '#options' => $options,
        '#default_value' => 1,
      ];
      $form['dobYr'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('input-filed'), 'id' => array('home-tack_year') ,'autocomplete' => array('off')),
        '#placeholder' => 'Eg. 2',
        '#min' => 2,
        '#max' => 50,
        '#required' =>TRUE
      ];
      $form['dobMth'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('input-filed'), 'id' => array('home-tack_month') ,'autocomplete' => array('off')),
        '#placeholder' => 'Eg. 1',
        '#min' => 0,
        '#max' => 11,
        '#default_value' => 0,
        '#required' =>TRUE
      ];
      $form['height'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('input-filed'), 'id' => array('home-tack_height') ,'autocomplete' => array('off')),
        '#placeholder' => t('Eg.').' 168',
        '#min' => 80,
        '#max' => 214,
        '#required' =>TRUE
      ];
      $form['weight'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('input-filed'), 'id' => array('home-tack_weight') ,'autocomplete' => array('off')),
        '#placeholder' => t('Eg.').' 168',
        '#min' => 7,
        '#max' => 150,
        '#required' =>TRUE
      ];
      $form['form_disclaimer'] = [
        '#markup' => $disclaimer
      ];
      $form['submit'] = [
        '#type' => 'submit',
        '#value' => $btn_text,
        '#attributes' => array('class' => array('redbutton primary-button')),
        '#validate' => ['::submitValidateTG'],
      ];

      $form['#theme'] = 'HealthTrackerForm';
      return $form;
    }
  }

  /**
   * Validation growth tracking form functionality.
   */
  public function submitValidateTG(array &$form, FormStateInterface $form_state) { 
    $age = (int) $form_state->getValue('dobYr') . '.' . $form_state->getValue('dobMth');
    $heights = (int) $form_state->getValue('height');
    $weight = $form_state->getValue('weight');
    if ($age == '') {
        $form_state->setErrorByName('dobYr', 'Please select date of birth');
    } 
    elseif ($age < 2) {
      $form_state->setErrorByName('dobYr', 'Minimum required age is 2 year.');
    } 
    elseif ($age > 50) {
      $form_state->setErrorByName('dobYr', 'The recommendations are for healthy children between 2 year to 50 years of age. Please enter appropriate age.');
    }
    if ($heights == '') {
      $form_state->setErrorByName('height', 'Please select height');
    } 
    elseif ($heights < 80) {
      $form_state->setErrorByName('height', 'Minimum required height is 80 cms.');
    } 
    elseif ($heights > 214) {
      $form_state->setErrorByName('height', 'Maximun height should not be greater then 214 cms');
    }
    if ($weight == '') {
      $form_state->setErrorByName('weight', 'Please select weight');
    } 
    elseif ($weight < 7) {
      $form_state->setErrorByName('weight', 'Minimum required weight is 7 KG.');
    } 
    elseif ($weight > 150) {
      $form_state->setErrorByName('weight', 'Maximun weight should not be greater then 150 KG');
    }
  }

  /**
   * Submit growth tracking form functionality.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    global $base_url;
    $dobYr = $form_state->getValue('dobYr');
    $dobMth = $form_state->getValue('dobMth');
    $gender = $form_state->getValue('gender');
    $height = $form_state->getValue('height');
    $weight = $form_state->getValue('weight');
    $growth_data = [
      'dobYr' => $dobYr,
      'dobMth' => $dobMth,
      'gender' => $gender,
      'height' => $height,
      'weight' => $weight,
    ];
    $session = \Drupal::request()->getSession();
    $session->set('growth_data', $growth_data);
    $form_state->setRedirect('nestle_health_tracker.unreg_tracking');
  }
}
