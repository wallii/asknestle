<?php

namespace Drupal\nestle_health_tracker\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\config_pages\Entity\ConfigPages;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\nestle_api\Controller\NestleAPI;

/**
 * Form to handle growth tracking form functionality that used in the inner page.
 */
class updateVital extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'health_tracker_update_vital';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $base_url;
	$hindi = CommonFunc::isHindi();
	$vitals = NestleAPI::showVitals();
    //get the field value from the custom ]health tracker config page
    $healthTrackerConfigPage = ConfigPages::config('nestle_health_tracker_form');
    $heading_1 = $healthTrackerConfigPage->get('field_heading_1')->value;
    $heading_2 = $healthTrackerConfigPage->get('field_heading_2')->value;
    $subheading = $healthTrackerConfigPage->get('field_subheading')->value;
    $select_child_details = $healthTrackerConfigPage->get('field_select_child_details')->value;
    $health_chart_detail = $healthTrackerConfigPage->get('field_health_chart_detail')->value;
     $form_header_disclaimer = $healthTrackerConfigPage->get('field_inner_desclaimer')->value;
     $form_footer_disclaimer = $healthTrackerConfigPage->get('field_footer_disclaimer')->value;
    $disclaimer = $healthTrackerConfigPage->get('field_disclaimer')->value;
    $btn_text = $healthTrackerConfigPage->get('field_button_text')->value;
    if (!\Drupal::currentUser()->isAnonymous()) {
      $form['form_heading'] =[
        '#markup' => $heading_1
      ];
      $form['form_header_disclaimer'] =[
        '#markup' => $form_header_disclaimer
      ];
      $form['form_footer_disclaimer'] =[
        '#markup' => $form_footer_disclaimer
      ];
      $form['form_health_chart_detail'] =[
        '#markup' => $health_chart_detail
      ];
      $form['form_select_gender_head'] = [
        '#markup' => $heading_2
      ];
      $form['form_select_child_details'] = [
        '#markup' => $select_child_details
      ];
	  if ($vitals != 0) {
		 $vitalsKey = CommonFunc::arrayKeyFirst($vitals);
		 $vitalArr = $vitals[$vitalsKey];
         $vitalhgt = $vitalArr['height'];
         $vitalwgt = $vitalArr['weight'];
         //echo $vitalhgt;
         //echo "</br>"; 
         //echo $vitalwgt;
         //die;		 
	  }
     
      
      $form['height'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('input-filed'), 'id' => array('home-tack_height') ,'autocomplete' => array('off')),
        '#placeholder' => t('Eg.').' 168',
		'#default_value' => floor($vitalhgt),
        '#min' => floor($vitalhgt),
        '#max' => 214,
        '#required' =>TRUE
      ];
      $form['weight'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('input-filed'), 'id' => array('home-tack_height') ,'autocomplete' => array('off')),
        '#placeholder' => t('Eg.').' 168',
        '#min' => 4,
        '#max' => 150,
		'#default_value' => floor($vitalwgt),
        '#required' =>TRUE
      ];
      $form['form_disclaimer'] = [
        '#markup' => $disclaimer
      ];
      $form['form_subheading'] = [
        '#markup' => $subheading
      ];
      $form['submit'] = [
        '#type' => 'submit',
        '#value' => t('Save Vitals'),
        '#attributes' => array('class' => array('redbutton primary-button')),
        '#validate' => ['::submitValidateTG'],
      ];

      $form['#theme'] = 'updateVital';
      return $form;
    } else {
	  if ($hindi) {
		 
        return new RedirectResponse($base_url . '/hindi/growth-track/tracking');
      } 
      else {
		  
        return new RedirectResponse($base_url . '/growth-track/tracking');
      }
	}
  }

  /**
   * Validation growth tracking form functionality.
   */
  public function submitValidateTG(array &$form, FormStateInterface $form_state) { 
   
    $heights = (int) $form_state->getValue('height');
    $weight = $form_state->getValue('weight');
    
    if ($heights == '') {
      $form_state->setErrorByName('height', 'Please select height');
    } 
    elseif ($heights < 80) {
      $form_state->setErrorByName('height', 'Minimum required height is 80 cms.');
    } 
    elseif ($heights > 214) {
      $form_state->setErrorByName('height', 'Maximun height should not be greater then 214 cms');
    }
    if ($weight == '') {
      $form_state->setErrorByName('weight', 'Please select weight');
    } 
    elseif ($weight < 7) {
      $form_state->setErrorByName('weight', 'Minimum required weight is 7 KG.');
    } 
    elseif ($weight > 150) {
      $form_state->setErrorByName('weight', 'Maximun weight should not be greater then 150 KG');
    }
  }

  /**
   * Submit growth tracking form functionality.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    global $base_url;
    $hindi =  CommonFunc::isHindi();
    $height = $form_state->getValue('height');
    $weight = $form_state->getValue('weight');
	$child_id = CommonFunc::childField('field_child_key');
    $entry_for = date("d-m-Y");
    $data = [
        'client_key' => $child_id,
        'entry_for' => $entry_for,
        'height' => $height,
        'weight' => $weight,
      ];
	$response = NestleAPI::saveVitalLogin($data); 
	if($response['status'] == 'success') {
		$form_state->setRedirect('nestle_health_tracker.tracking');
		
	} else {
		$form_state->setRedirect('nestle_health_tracker.update_vitals');
	}
    
	
  }
}
