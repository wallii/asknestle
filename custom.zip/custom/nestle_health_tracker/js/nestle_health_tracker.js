(function ($) {
	Drupal.behaviors.healthTrackBMI = {
	attach: function (context, settings) {
	let bmiVal = $("#vitalbmivalue").val();
	if(bmiVal) {
	var BMI = bmiVal;
	var rot = 0;
	if(BMI<= 18){
	rot = (BMI*2);
	}
	if(BMI> 18 &&  BMI<= 22.9){
	var BMIDIF = (BMI - 18);
	rot = (BMIDIF*9.1 + 45);
	}
	if(BMI>= 23 &&  BMI<= 24.9){
	var BMIDIF = (BMI - 22.9);
	rot = (BMIDIF*26.4 + (45*2));
	}
	if(BMI>= 25){

	if(BMI>30){

	BMI = 30;

	}
	var BMIDIF = (BMI - 24);
	rot = (BMIDIF*8.2 + (45*3));
	}
	$('.charthand').css('transform','rotate('+ rot +'deg)');	
	} 	
	}
	};
   
})(jQuery);
