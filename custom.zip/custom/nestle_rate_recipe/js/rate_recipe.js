(function ($, Drupal) {
  'use strict';
  function setRating(selector, starVal){
      var $this = selector;
      var $thisParent = $this.parent();
      var recipeAction= $thisParent.attr('data-action');
      var recipeId= $thisParent.attr('data-value');
       var recipeHindiName = $thisParent.attr('data-hindiname');
       var recipeEngName = $thisParent.attr('data-engname');
        var lang = drupalSettings.language;
        if (lang == "hi") {
          var short_url ="hindi/";
          var recipeAltSeoName = $thisParent.attr('data-recipeseoname');
          var recipeSeoName= $thisParent.attr('data-recipeseoalternatename');
        } 
        else {
          var recipeSeoName= $thisParent.attr('data-recipeseoname');
          var recipeAltSeoName= $thisParent.attr('data-recipeseoalternatename');
            var short_url = "";
        }
      $.ajax({
        url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
        type: 'post',
        cache: false,
        data: {
          "action": "saveRateRecipe",
          "id": recipeId,
          "recipeAction": recipeAction,
          "recipeSeoName": recipeSeoName,
          "recipeAltSeoName": recipeAltSeoName,
          "recipeHindiName": recipeHindiName,
          "recipeEngName": recipeEngName,
          "starValue": starVal,
          "lang": lang
        },
        success: function (response) {
          console.log(response);
          //console.log(recipeHindiName);
          if(response.action == 'added'){
            $('.rating-value').html('');
            $('.rate.markrating').attr('data-action','update');
            $('.rating-value').append('<i class="rating-icon"></i>'+response.star);
            $('.rating-thankyou').show();
            $(".rating-thankyou").delay(5000).fadeOut(1000);
          }else{
            $('.rating-value').html('');
            $('.rating-value').append('<i class="rating-icon"></i>'+response.star);
            $('.rating-thankyou').show();
            $(".rating-thankyou").delay(5000).fadeOut(1000);
          }
        }
        });
     }
    $(document).on('click', '.markrating .rate_number', function () {
      //var target = $(this).attr('data-target');
      var $this = $(this);
      var starVal = $this.val();
      setRating($this, starVal);
    });

    $(document).on('click', '.nologgedIn', function () {
      //var target = $(this).attr('data-target');
      $('.rating-signup').show();
    });
    

})(jQuery, Drupal);
