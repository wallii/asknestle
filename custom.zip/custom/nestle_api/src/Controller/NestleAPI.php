<?php

namespace Drupal\nestle_api\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_common\Controller\CommonFunc;

/**
 * This class is used to retrive data from Fitter Fly APIs.
 */
class NestleAPI extends ControllerBase {

  /**
   * Use to authenticate the API from Token.
   *
   * @var string
   */
  
  /**
   * Child Registration.
   */
  public static function saveData($data) {
    $allergies = '';
    $alergy = array_filter($data['allergies']);
    $count = count($alergy);
    $i = 1;
    foreach ($alergy as $value) {
      if ($value == 100) {
        $allergies .= '';
      }
      else {
        if ($count != $i) {
          $allergies .= $value . ',';
        }
        else {
          $allergies .= $value;
        }
      }

      $i++;
    }

    $post_data = [
      'client_first_name' => $data['childNm'],
      'client_last_name' => $data['lname'],
      'client_dob' => $data['dob'],
      'client_gender_id' => $data['gender'],
      'height' => $data['height'],
      'weight' => $data['weight'],
      'food_preference' => $data['food_type'],
      'region' => $data['regional_food'],
      'allergies' => $allergies,
      'client_key' => $data['client_key'],
    ];

    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/client-save';
    $client = \Drupal::httpClient();

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Get child data information.
   */
  public static function getChild() {
    $child_key = CommonFunc::childField('field_child_key');
    $post_data = [
      'client_key' => $child_key,
    ];

    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/client-details';
    $client = \Drupal::httpClient();

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    $body = json_decode($body, TRUE);
    return $body['contents'];
  }

  /**
   * Get child data information.
   */
  public static function getChildDetails($child_key) {
    // $child_key = CommonFunc::childField('field_child_key');
    $post_data = [
      'client_key' => $child_key,
    ];

    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/client-details';
    $client = \Drupal::httpClient();

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    $body = json_decode($body, TRUE);
    return $body['contents'];
  }

  /**
   * Get meal plan for logged in user.
   */
  public static function mealPlanLogin($post_data) {
	try {  
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/retrieve-diet-plan-v2';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);

    $data = $response->getBody()->getContents();
	if($data !='') {
		return json_decode($data, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
    return json_decode($data, TRUE);
	
	} catch (\Exception $error) {
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Get meal plan for non logged in user.
   */
  public static function mealPlanNotLogin($post_data) {
	try {  
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-meal-plans-v2';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);

    $data = $response->getBody()->getContents();
	if($data !='') {
		return json_decode($data, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
    
	
	} catch (\Exception $error) {
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Get child's growth data for logged in user.
   */
  public static function showVitals() {
	
    try {	
    $hindi = CommonFunc::isHindi();
    $child_key = CommonFunc::childField('field_child_key');

    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/get-growth-parameters';
    $client = \Drupal::httpClient();

    if ($hindi) {
      $post_data = ['client_key' => $child_key, 'lang' => 'hi'];
    }
    else {
      $post_data = ['client_key' => $child_key];
    }

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);

    $body = $response->getBody()->getContents();
	if($body !='') {
		$data = json_decode($body, TRUE);
		if(is_array($data)) {
			if (array_key_exists('contents', $data) && count($data['contents']) != 0) {
			$vital = $data['contents'];
			}
			else {
			$vital = '0';
			}
		} else {
			$vital = '0';
		}
		
	} else {
		
		$vital = '0';
	}
    

    return $vital;
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Save child's growth data for logged in user.
   */
  public static function saveVitalLogin($post_data) {
    
	try {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/set-growth-parameters';
    $client = \Drupal::httpClient();

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
		return json_decode($body, TRUE);
    } else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    

  }

  /**
   * Save child's growth data for non-logged in user.
   */
  public static function saveVitalNotLogin($post_data) {
    try{
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-vital-info';
    $client = \Drupal::httpClient();

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);

    $body = $response->getBody()->getContents();
	if($body !='') {
		return json_decode($body, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
    
	} catch (\Exception $error) {
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}		
  }

  /**
   * Delete child's growth data for logged in user.
   */
  public static function deleteVital() {
    $post_data = [
      'client_key' => 'pT9a6XZChVrAmdez',
      'entry_for' => '01-07-2019',
    ];

    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/delete-growth-parameters';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);

    $body = $response->getBody()->getContents();
    
  }

  /**
   * Show Vitals list of logged in user.
   */
  public static function vitalsList($param) {
	  
    try { 
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/get-growth-parameters';
    $client = \Drupal::httpClient();

    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($param),
    ]);

    $data = $response->getBody()->getContents();
	if($data !='') {
	   return json_decode($data, TRUE);	
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
    
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Search meal for both log a meal and food diary.
   */
  public static function searchItem($post_data) {
	try {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/search-food-items';

    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);

    $body = $response->getBody()->getContents();
    $data = json_decode($body, TRUE);
    if (!$data['contents']) {
      return 0;
    }
    else {
      return $data['contents'];
    }
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Add new entry in food diary for logged in users.
   */
  public static function addFoodEntry($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/add-meal-entry';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Add new entry in immunity for anonymous users.
   */
  public static function addImmunityEntry($post_data) {
\Drupal::logger('add immunity')->notice('<pre><code>' . print_r($post_data, TRUE) . '</code></pre>' );
   try {
   $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/immunity-calculator';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
	   return json_decode($body, TRUE);	
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
    } catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Edit entry in immunity for anonymous users.
   */
  public static function editImmunityEntry($post_data) {
\Drupal::logger('edit immunity')->notice('<pre><code>' . print_r($post_data, TRUE) . '</code></pre>' );
   try {    
   $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-update-meal-entry';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
	 return json_decode($body, TRUE);	
	} else {
	 return array("status" =>'error' , "message" => 'some time out error occur'); 	
	}
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }

  /**
   * Delete entry in immunity for anonymous users.
   */
  public static function deleteImmunityEntry($post_data) {
\Drupal::logger('delete immunity')->notice('<pre><code>' . print_r($post_data, TRUE) . '</code></pre>' );
    try {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-delete-meal-entry';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
		return json_decode($body, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }

  /**
   * Retrive entry in immunity for anonymous users.
   */
  public static function retriveImmunityEntry($post_data) {
\Drupal::logger('retrive immunity')->notice('<pre><code>' . print_r($post_data, TRUE) . '</code></pre>' );
    try {
	$url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-retrieve-meal-entries';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
		return json_decode($body, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }

  /**
   * Create user in immunity for anonymous users.
   */
  public static function CreateImmunityEntry($post_data) {
	try {  
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-client';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
		return json_decode($body, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }

  /**
   * Update entry of food diary for logged in users.
   */
  public static function updateFoodEntry($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/update-meal-entry';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Delete entry of food diary for logged in users.
   */
  public static function deleteFoodEntry($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/delete-meal-food-entry';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Retrieve food entry details.
   */
  public static function retrieveFoodEntry($post_data) {
	  
	try {   
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/retrieve-meal-entries';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
	  return json_decode($body, TRUE);	
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }

  /**
   * Log a meal for not logged in users.
   */
  public static function logMeal($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/unreg-meal-tracker';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Get Recipes data from categories name.
   */
  public static function recipesData($post_data) {
    
	try {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/recipe-list';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
		if($body !='') {
			return json_decode($body, TRUE);
		} else {
			return array("status" =>'error' , "message" => 'Time out error occur');
		}
    
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
		$logger->error($error->getMessage()); 
		return array("status" =>'error' , "message" => $error->getMessage()); 
		
	}
  }

  /**
   * Get recipe detail from recipe id.
   */
  public static function recipesDetail($post_data) {

    // $lang_code = CommonFunc::multilingualConvert('lang');
    /* if (isset($post_data['recipe_name'])) {
    $expRecipename = explode('-', $post_data['recipe_name']);
    $endvalRecipe = end($expRecipename);
    $countArr = count($post_data);

    if(($endvalRecipe == 'विधि' && ($countArr == 1 || ($countArr == 2 && isset($post_data['client_key'])))) ||  (($countArr == 2 && empty($post_data['client_key'])) && $endvalRecipe != 'विधि')){
    $falsErecipeName = $post_data['recipe_name'].'recipe';
    $post_data1 = array('recipe_name'=>$falsErecipeName);
    $post_data = array_merge($post_data,$post_data1);
    }

    if(($endvalRecipe == 'विधि' &&  $lang_code == 'en') || ($endvalRecipe != 'विधि' && $lang_code == 'hi')){
    // $falsErecipeName = $post_data['recipe_name'].'recipe';
    $post_data1 = array('recipe_name'=>'');
    $post_data = array_merge($post_data,$post_data1);
    }

    }*/
	
	try { 

    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/recipe-details';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
		if($body !='') {
			return json_decode($body, TRUE);
		} else {
			return array("status" =>'error' , "message" => 'some time out error occur');
		}
    
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
		$logger->error($error->getMessage());
		return array("status" =>'error' , "message" => $error->getMessage());
		
	}
  }

  /**
   * Get Recipe Tag List.
   */
  public static function recipesTags($post_data) {
	  
    try {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/get-recipe-tags';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
	  'timeout' => 7,
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
	if($body !='') {
		return json_decode($body, TRUE);
	} else {
		return array("status" =>'error' , "message" => 'some time out error occur');
	}
    
	
	} catch (\Exception $error) {
		
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
  }

  /**
   * Get alternate food item on the basis of recipe_entry_id.
   */
  public static function getAlternateFood($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/get-alternate-food-items';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Get alternate food item on the basis of recipe_entry_id.
   */
  public static function replaceFoodItem($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/replace-with-alternate-food-item';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }

  /**
   * Get current time slot basis of current date and info.
   */
  public static function mealListTimeslot($post_data) {
    $url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/meal-list';
    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => [
        'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($post_data),
    ]);
    $body = $response->getBody()->getContents();
    return json_decode($body, TRUE);
  }
  
   /**
   * Get current time slot basis of current date and info.
   */
  public static function getIngredientsList($post_data) {
	
    try {	
		$url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/get-ingredients-list';
		$client = \Drupal::httpClient();
		$response = $client->request('POST', $url, [
		  'headers' => [
			'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
			'Content-Type' => 'application/json',
		  ],
		  'body' => json_encode($post_data),
		]);
		$body = $response->getBody()->getContents();
		if($body !='') {
			return json_decode($body, TRUE);
		} else {
			return array("status" =>'error' , "message" => 'some time out error occur');
		}
	} catch (\Exception $error) {
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }
  
   /**
   * Get Balanced meal list or Best peared with a particular recipe.
        
   */
  public static function getBalancedMealList($post_data) {
	
    try {	
		$url = 'https://fu2gz4iut4.execute-api.ap-south-1.amazonaws.com/AskNestle2/balanced-meal-list';
		$client = \Drupal::httpClient();
		$response = $client->request('POST', $url, [
		  'headers' => [
			'x-api-key' => CommonFunc::getConfigPageFieldValue('global_site_settings', 'field_api_key'),
			'Content-Type' => 'application/json',
		  ],
		  'body' => json_encode($post_data),
		]);
		$body = $response->getBody()->getContents();
		if($body !='') {
			return json_decode($body, TRUE);
		} else {
			return array("status" =>'error' , "message" => 'some time out error occur');
		}
	} catch (\Exception $error) {
		$logger = \Drupal::logger('HTTP Client error');
        $logger->error($error->getMessage());		
		return array("status" =>'error' , "message" => $error->getMessage()); 
	}
    
  }

  /**
   * Get UID from gigya accountsearch api.
   */
  public static function getAccountSearchUID($api_key, $application_key, $secret_key, $parent_email) {

    // $url = 'https://accounts.us1.gigya.com/accounts.search?apiKey=$api_key&userKey=$application_key&secret=$secret_key&query= select UID from emailAccounts where profile.email = '$parent_email'';
    $url = 'https://accounts.us1.gigya.com/accounts.search';

    $query = "select UID from emailAccounts where profile.email = '$parent_email'";

    $post_data = [
      'apiKey' => $api_key,
      'userKey' => $application_key,
      'secret' => $secret_key,
      'query' => $query,
    ];

    $client = \Drupal::httpClient();
    $response = $client->request('POST', $url, [
      'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      'form_params' => $post_data,
      'verify' => FALSE,
    ]);
    $data = $response->getBody()->getContents();

    return json_decode($data, TRUE);

  }

  /**
   * Get UID from gigya accountInfo api.
   */
  public static function getAccountChildInfo($api_key, $application_key, $secret_key, $parentDataID) {

    $urlChild = 'https://accounts.us1.gigya.com/accounts.getAccountInfo';

    $post_data = [
      'apiKey' => $api_key,
      'userKey' => $application_key,
      'secret' => $secret_key,
      'UID' => $parentDataID,
    ];

    $client = \Drupal::httpClient();
    $responseChildData = $client->request('POST', $urlChild, [
      'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      'form_params' => $post_data,
      'verify' => FALSE,
    ]);

    $childdata = $responseChildData->getBody()->getContents();

    return json_decode($childdata, TRUE);

  }

  /**
   * Get category(Main Cat Arr) details from nestle_bucket type.
   */
  public static function categaryList($rest_category_arr) {
    foreach ($rest_category_arr['contents'] as $catKey => $catVal) {
      if (is_array($catVal[0])) {
        foreach ($catVal[0] as $catKey => $catVal) {
          $categoryName['allCat'][][$catKey] = $catVal;
          $categoryName['mainCat'][] = $catKey;
          foreach ($catVal as $subCatval) {
            $categoryName['subCat'][$catKey][] = $subCatval;
          }
        }
      }
      else {
        $categoryName['mainCat'][] = $catVal[0];
        $categoryName['allCat'][] = $catVal[0];
      }
    }
    return $categoryName;
  }

  /**
   * Get category(Main Cat Arr) details from nestle_bucket type.
   */
  public static function categaryListNew($rest_category_arr) {
    $i = 0;
    $categoryName = [];
	if(!empty($rest_category_arr)) {
    if (count($rest_category_arr['contents'][0]) > 0) {
      foreach ($rest_category_arr['contents'][0] as $catVal1) {
        $j = 0;
        if (isset($catVal1['sub_categories'][0])) {
          foreach ($catVal1['sub_categories'][0] as $subCatKey => $subCatval) {
            if (isset($categoryName['subCat'])) {
              if (!in_array($subCatval, $categoryName['subCat'])) {
                $categoryName['subCat'][$catVal1['seo_name']][$j][] = $subCatval;
                $categoryName['subCat'][$catVal1['seo_name']][$j][] = $subCatKey;
              }
            }
            $j++;
          }
        }
        $categoryName['mainCat'][$i]['name'] = $catVal1['name'];
        $categoryName['mainCat'][$i]['seo_name'] = $catVal1['seo_name'];
        $categoryName['mainCat'][$i]['seo_title'] = $catVal1['seo_title'];
        $categoryName['mainCat'][$i]['seo_desc'] = $catVal1['seo_desc'];
        $categoryName['mainCat'][$i]['image'] = $catVal1['image'];
        $categoryName['mainCat'][$i]['desc'] = $catVal1['desc'];
        $categoryName['SeoName'][] = $catVal1['seo_name'];
        $categoryName['allCat'][$i] = $catVal1['name'];
        $i++;
      }
    }
	}
    return $categoryName;
  }

}
