<?php

namespace Drupal\nestle_meal_plan\Controller;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\Core\Language\LanguageManager;
use Symfony\Component\HttpFoundation\Request;
use Drupal\config_pages\Entity\ConfigPages;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Provides controllers for Custom Meal Plan.
 */
class HomePageMealPlan extends ControllerBase {

   /**
   * Home Page Meal Plan Data
   */
  public static function HomePageLoginUserMealPlan() {
	  
		$client_key = CommonFunc::childField('field_child_key');
		$participation_key = CommonFunc::childField('field_participation_key');
		$hindi = CommonFunc::isHindi();
		/** Config field value **/
		//get the field value from the custom meal plan config page
       $globmealVarable['reg_meal_welcome'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_recipe_top_tab');
	    $globmealVarable['reg_meal_rdapopup'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_reg_rda_popup');
		 $globmealVarable['reg_meal_nutripopup'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_reg_nutrient_popup');
		 
		 $globmealVarable['reg_meal_clickrda'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_what_is_immunity');
		 
		 $globmealVarable['reg_meal_show_entire'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_red_rda_text');
	   
	   $mealPlanCustom['configValue'] = $globmealVarable;	
	   /** End ***/

		$today = CommonFunc::currentTime('d-m-Y');
		$intervals = CommonFunc::currentWeekDate($today);
        if($hindi) {
			$mealPlanCustom['weekly_data_mon'] = date('dS', strtotime($intervals['सोम']));	
            $mealPlanCustom['weekly_data_sun'] = date('dS', strtotime($intervals['रवि']));
		} else {
			$mealPlanCustom['weekly_data_mon'] = date('dS', strtotime($intervals['Mon']));	
            $mealPlanCustom['weekly_data_sun'] = date('dS', strtotime($intervals['Sun']));
		}
        
		
		$mealPlanCustom['weekly_data'] = $intervals;
		$mealPlanCustom['current_data'] = $today;
		$post_data = [
			"client_key" => $client_key,
			"participation_key" => $participation_key,
			"from_date" => $today,
			"to_date" => $today
		];
		$post_data = CommonFunc::APiHindi($post_data);
		$plan = NestleAPI::mealPlanLogin($post_data);
		if($hindi){
			$cur_lang = 'hi';
		}else{
			$cur_lang = 'en';
		}
        if ($plan['status'] == 'success') {
			$meal_plans = $plan['contents']['day_plans'][0]['meal_plans'];
			$meal_index = $plan['contents']['day_plans'][0]['current_meal_key'];
			if (!empty($meal_plans)) {
				$current_meal_key = $plan['contents']['day_plans'][0]['current_meal_key'];
				$current_meal_name = $plan['contents']['day_plans'][0]['current_meal_name'];
				$meal_rda = $plan['contents']['rda_entries'];
				$meal_nutrients = $plan['contents']['nutrients'];
				$consumed_nutrients = $plan['contents']['nutritional_values'];
				foreach ($meal_plans as $key => $meal_plan) {
				$data['name'] = $meal_plan['name'];
				$data['key'] = $meal_plan['key'];
				if(!empty($meal_plan['recipe_entries'])){
					foreach ($meal_plan['recipe_entries'] as $mealkey => $meal_plan_value) {
						$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($meal_plan_value['seo_name'])['recipeMetadata'];
						$recipeFavData = CommonFunc::getRecipeFavlikeDislike($meal_plan_value['seo_name'], $cur_lang);
						$meal_plan['recipe_entries'][$mealkey]['fav'] = $recipeFavData;
						$meal_plan['recipe_entries'][$mealkey]['recipeMetadata'] = $recipeMetaData;
						$recipeRatingData =  CommonFunc::getRecipeRatingBySeo($meal_plan_value['seo_name'], $cur_lang);;
						$meal_plan['recipe_entries'][$mealkey]['gRating'] = $recipeRatingData;
					}
				}
				$data['recipe_entries'] = $meal_plan['recipe_entries'];
				if(is_array($meal_plan) && array_key_exists('key', $meal_plan) && $meal_plan['key'] == $plan['contents']['day_plans'][0]['current_meal_key']) {
				$data['status'] = 'mp-active';
				$data['sub_status'] = 'mpactive';
				$data['nutrients'] = CommonFunc::mealNutrient($meal_rda, $meal_nutrients, $consumed_nutrients);
			
				} else {
				$data['status'] = 'mp-inactive';
				$data['sub_status'] = 'mpinactive';
				$data['nutrients'] = 'NA';
				}

				$meal_data[] = $data;
				}
			} else {
				$meal_data = '';
			}
		}
        $mealPlanCustom['meals'] = $meal_data;		
		return [
			'#theme' => 'HomeCustmMealPlan',
			'#params' => $mealPlanCustom,
			'#attached' => [
				'library' => 'nestle_meal_plan/nestle_meal_plan_homepage_js',
			]
		];
	  
	  
  }
  /**
    Date Wise Meal Plan
  **/
  public function loadDateWiseMealPlan(Request $request) {
	global $base_url;  
	$hindi = CommonFunc::isHindi();
	$reg_meal_footer_rda = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_reg_footer_rda');
	$mealDate = $request->query->get('mealDate');
	$client_key = CommonFunc::childField('field_child_key');
	$participation_key = CommonFunc::childField('field_participation_key');
	$MealDate = CommonFunc::currentTime($mealDate);
	$post_data = [
		"client_key" => $client_key,
		"participation_key" => $participation_key,
		"from_date" => $MealDate,
		"to_date" => $MealDate
	];
	if($hindi){
		$cur_lang = 'hi';
	}else{
		$cur_lang = 'en';
	}
	$html = '';
	$post_data = CommonFunc::APiHindi($post_data);
	$plan = NestleAPI::mealPlanLogin($post_data);
	if ($plan['status'] == 'success') {
		
		$meal_plans = $plan['contents']['day_plans'][0]['meal_plans'];
		$meal_index = $plan['contents']['day_plans'][0]['current_meal_key'];
		if (!empty($meal_plans)) {
			
			$current_meal_key = $plan['contents']['day_plans'][0]['current_meal_key'];
			$current_meal_name = $plan['contents']['day_plans'][0]['current_meal_name'];
			$meal_rda = $plan['contents']['rda_entries'];
			$meal_nutrients = $plan['contents']['nutrients'];
			$consumed_nutrients = $plan['contents']['nutritional_values'];
			foreach ($meal_plans as $key1 => $meal_plan) {
			$name = $meal_plan['name'];
			$key = $meal_plan['key'];
			if(!empty($meal_plan['recipe_entries'])){
				foreach ($meal_plan['recipe_entries'] as $mealkey => $meal_plan_value) {
					$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($meal_plan_value['seo_name'])['recipeMetadata'];
					$recipeFavData = CommonFunc::getRecipeFavlikeDislike($meal_plan_value['seo_name'], $cur_lang);
					$meal_plan['recipe_entries'][$mealkey]['fav'] = $recipeFavData;
					$meal_plan['recipe_entries'][$mealkey]['recipeMetadata'] = $recipeMetaData;
					$recipeRatingData =  CommonFunc::getRecipeRatingBySeo($meal_plan_value['seo_name'], $cur_lang);;
					$meal_plan['recipe_entries'][$mealkey]['gRating'] = $recipeRatingData;
				}
			}
			$recipe_entries = $meal_plan['recipe_entries'];
			if(is_array($meal_plan) && array_key_exists('key', $meal_plan) && $meal_plan['key'] == $plan['contents']['day_plans'][0]['current_meal_key']) {
			$status = 'mp-active';
			$sub_status = 'mpactive';
			$nutrients = CommonFunc::mealNutrient($meal_rda, $meal_nutrients, $consumed_nutrients);

			} else {
			$status = 'mp-inactive';
			$sub_status = 'mpinactive';
			$nutrients = 'NA';
			}
			if($name == '') {
				$name = $key;
			}
			if($hindi) {
				$short_url = "/hindi";
			} else {
				$short_url = "";
			}
			
			$html .= '<div class="entireday_'.$status.'">
		              <h4 class="'.$status.'" data-time="'.$key.'">
			          <i class="early-morning-icon"></i>
			          <span>'.$name.'</span>
		             </h4>
		            <div class="mealplan-acodn-cont '.$sub_status.'" data-time="'.$key.'">
			         <div class="rcips-list">';
                   foreach($recipe_entries as $mrkey => $mrVal) {
                                        if($mrVal['veg_nonveg'] == 'Veg') {
											$vegN = "Veg";
											$vegicon ="veg-icon";
										} else {
											$vegN = "Non-Veg";
											$vegicon ="noVeg-icon";
										}
										if($mrVal['fav']=='like'){
											$likeClass = '';
											$likeAttr = 'like';
										}else{
											$likeClass = 'active-like';
											$likeAttr = 'dislike';
										}
										if($mrVal['gRating'] != 0.0){
											$rate = '<div class="rvw"><em></em>'.$mrVal['gRating'].'</div>';
										}else{
											$rate = '<div class="rvw"><em></em>'.t('No rate').'</div>';
										}
										$like_html= '<div class="like '.$likeClass.' favBtn" id="favBtn" data-fav="'.$likeAttr.'" data-recipeid="'.$mrVal['recipeMetadata']['id'].'" data-recipeseoname="'.$mrVal['seo_name'].'" data-recipeseoalternatename="'.$mrVal['recipeMetadata']['seo_alt_name'].'" data-value="'.$mrVal['seo_name'].'" data-hindiname = "'.$mrVal['recipeMetadata']['hindi_name'].'" data-engname = "'.$mrVal['recipeMetadata']['eng_name'].'" data-target="card"></div>';

				   $html .='<div class="item '.$vegN.'" id="'.$mrVal['recipe_id'].'">
					     <div class="cardscmn2">
						<div class="imgWrp">
							<a href="'.$base_url.$short_url.'/recipes/'.$mrVal['seo_name'].'">
							<img src="'.$mrVal['round_images'].'" alt="'.$mrVal['name'].'" width="1" height="1">
							</a>
						</div>
						<div class="txtb">
							<a href="'.$base_url.$short_url.'/recipes/'.$mrVal['seo_name'].'">
								<h3>'.$mrVal['name'].'</h3>
							</a> 
							<p>'.$mrVal['trivia'].'</p>
							<ul class="list1">
								<li><em><img src="themes/custom/nestle_new/common/images/icon-fire.svg" alt="fire" width="1" height="1"></em> '.$mrVal['aggregated_nutrients'][34].' calories</li>
								<li><em><img src="themes/custom/nestle_new/common/images/icon-time.svg" alt="time" width="1" height="1"></em> '.$mrVal['time_to_cook'].' mins</li>
							</ul>
							<div class="tagbox">

							</div>
						</div>
						<div class="crdsFtr">
              <div class="vn-tag-rvw">
                <div class="veg-nveg-mark"><i class="'.$vegicon.'"></i></div>
                  '.$rate.'
                </div>
                '.$like_html.'
             </div> 
						<ul class="seereplace"> 
						<li> 
							<div class="mlsee">
							<a href="'.$base_url.$short_url.'/recipes/'.$mrVal['seo_name'].'" class="nLink"> See Recipe</a>
							</div> 
						</li>
						<li> 
							<div class="meal-refresh nLink" data-mkey="'.$key1.'" data-rid="'.$mrVal['recipe_id'].'" data-id="'.$mrVal['recipe_entry_id'].'" data-sngcount="'.$mrVal['meal_recipe_index'].'"> Replace Meal</div> 
						</li>
					 </ul>
					</div>
					


				</div>';
			   }
			$html .= '</div>
			<div class="rda-tabslider">
				
				'.$nutrients.'

			</div>

			<div class="rda-tabcont">
			<div class="rda-contcommon"></div>
			</div>
			<div class="meal-replace-section">
			 <div class="meal-replace-section-in">
			 <span class="closepop">x</span>
			<ul class="meal_replace_section_data" id="meal_replace_section_data_'.$key1.'">
			</ul>
			</div>
			</div>
			<div class="disc-rda">'.$reg_meal_footer_rda.'</div>

		</div>
	</div>';

			$meal_data[] = $data;
			
			}
			
		} else {
			
			$html = '';
		
		}
		
	}
	
	return new JsonResponse($html);
	  
  }
   
 
}
