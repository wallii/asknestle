<?php

namespace Drupal\nestle_meal_plan\Controller;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\Core\Language\LanguageManager;
use Symfony\Component\HttpFoundation\Request;
use Drupal\config_pages\Entity\ConfigPages;

/**
 * Provides controllers for Custom Meal Plan.
 */
class MealPlan extends ControllerBase {

   /**
   * Use for unregistered user's meal plan.
   */
   public function unregRoutine() {
	   global $base_url;
	   $language_manager = \Drupal::languageManager();
       $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
	   $hindi = CommonFunc::isHindi();
	   $session = \Drupal::request()->getSession();
	   $post_data = $session->get('meal_form_data');
	   $post_data_new = CommonFunc::APiHindi($post_data);
	   $date = new DrupalDateTime();
	   $nutritions = CommonFunc::nutritionTags();
       $current_time = $date->format('H:i');
       $time = explode(':', $current_time);
       $time = $time[0] * 60 + $time[1];
	   if($hindi){
			$cur_lang = 'hi';
		}else{
			$cur_lang = 'en';
		}
	   //get the field value from the custom meal plan config page
       $customMealPlanConfigPage = ConfigPages::config('nestle_custom_meal_plan_form');
	   
	   $content['inner_heading'] = $customMealPlanConfigPage->get( 
                                	   'field_inner_balanced_meal_desc'
									   )->value;
	   $content['inner_rdapopup'] = $customMealPlanConfigPage->get( 
                                	   'field_unreg_meal_head_desc'
									   )->value;
       $content['inner_nutrientpopup'] = $customMealPlanConfigPage->get( 
                                	   'field_unreg_meal_paragraph'
									   )->value;
       $content['inner_rdaabove'] = $customMealPlanConfigPage->get( 
                                	   'field_inner_balanced_meal_text'
									   )->value;									   
	   $content['inner_desclaimer'] = $customMealPlanConfigPage->get( 
                                	   'field_inner_desclaimer'
									   )->value;					 
	   $content['unregMeal_showentireday'] = $customMealPlanConfigPage->get(
	                                         'field_unreg_show_entire_day'
											  )->value;
	  
	   /** Banner ConfigPages **/ 									      
       $content['banner_first_heading'] = CommonFunc::getConfigPageFieldValue(
                   	                      'common_page_headings', 'field_red_rda_text'
					                      );
		$content['banner_first_desc'] = CommonFunc::getConfigPageFieldValue(
		                                'common_page_headings', 'field_green_rda_text'
										);
		$content['banner_first_desktop_image'] = CommonFunc::getConfigPageImageFieldValue(
		                                         'common_page_headings', 'field_banner_first_desktop_image'
												  );
		$content['banner_first_mobile_image'] = CommonFunc::getConfigPageImageFieldValue(
		                                        'common_page_headings', 'field_banner_first_mobile_image'
												);
		$content['banner_first_link'] = CommonFunc::getConfigPageLinkFieldValue(
		                                'common_page_headings', 'field_banner_first_link'
										);										  
	   if (!empty($post_data_new)) {
		 $plan = NestleAPI::mealPlanNotLogin($post_data_new);
		 
		 if($plan['status'] == 'success') {
			$meal_plans = $plan['contents']['day_plans'][0]['meal_plans'];
			$meal_nutrients = $plan['contents']['nutrients'];
			$consumed_nutrients = $plan['contents']['nutritional_values'];
			$meal_rda = $plan['contents']['entries'];
			if (!empty($meal_plans)) {
				$current_meal_key = $plan['contents']['day_plans'][0]['current_meal_key'];
				$current_meal_name = $plan['contents']['day_plans'][0]['current_meal_name'];		
				foreach ($meal_plans as $key => $meal_plan) {
				$data['name'] = $meal_plan['name'];
				$data['key'] = $meal_plan['key'];
				
				
				foreach ($meal_plan['recipe_entries'] as $mealkey => $meal_plan_value) {
					
				$recipeRedirectData = CommonFunc::encryptData($meal_plan_value['seo_name'].'|recipes|card|'.$cur_lang.'|fav');
				$meal_plan['recipe_entries'][$mealkey]['url_redirect'] = $recipeRedirectData;
				
				$recipeRatingData =  CommonFunc::getRecipeRatingBySeo($meal_plan_value['seo_name'], $cur_lang);
				$meal_plan['recipe_entries'][$mealkey]['gRating'] = $recipeRatingData;
				
				}
				$data['recipe_entries'] = $meal_plan['recipe_entries'];
				
				if(is_array($meal_plan) && array_key_exists('key', $meal_plan) && $meal_plan['key'] == $plan['contents']['day_plans'][0]['current_meal_key']) {
				$data['status'] = 'mp-active';
				$data['sub_status'] = 'mpactive';
				$data['nutrients'] = CommonFunc::mealNutrient($meal_rda, $meal_nutrients, $consumed_nutrients);
				} else {
				$data['status'] = 'mp-inactive';
				$data['sub_status'] = 'mpinactive';
				$data['nutrients'] = 'NA';
				}

				$meal_data[] = $data;
				}
			} else {
				$meal_data = '';
			}		
			 
		 } 
		 $content['hindi'] = $hindi;
		return [
			'#theme' => 'Routine',
			'#meals' => $meal_data,
			'#hindi' => $hindi,
			'#base_url' => $base_url,
			'#content' => $content,
			'#attached' => [
				'library' => 'nestle_meal_plan/nestle_meal_plan_style',
				'drupalSettings' => [
					'lang' => $lang_code,
				],
			],
		];
		 
	   } else {
		  if ($hindi) {
				return new RedirectResponse($base_url . '/hindi/meal-plan');
			} 
			else {
				return new RedirectResponse($base_url . '/meal-plan');
			} 
	   }
   }
   
   /**
   * Use for registered user's meal plan.
   */
    public function routine() {
	global $base_url;
	$language_manager = \Drupal::languageManager();
	$lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
	$hindi = CommonFunc::isHindi();
	//get the field value from the custom meal plan config page
       $globmealVarable['reg_meal_welcome'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_what_is_immunity');
	   
	   $globmealVarable['reg_meal_welcome_desc'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_recipe_top_tab');
	   
	   $globmealVarable['reg_meal_custom_Meal'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_immunity_page_subheading');
	   
	   $globmealVarable['reg_meal_footer_rda'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_reg_footer_rda');
	   
	   $globmealVarable['reg_meal_show_entire'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_red_rda_text');
	   $content['reg_meal_rda_popup'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_reg_rda_popup');
	   $content['reg_meal_nutirnt_popup'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_reg_nutrient_popup');
	   
	   if($hindi){
			$cur_lang = 'hi';
		}else{
			$cur_lang = 'en';
		}
	
	if (\Drupal::currentUser()->isAnonymous()) {
      if ($hindi) {
        return new RedirectResponse($base_url . '/hindi/meal-plan');
      } 
      else {
        return new RedirectResponse($base_url . '/meal-plan');
      }
    } else {
		$today = CommonFunc::currentTime('d-m-Y');
		$client_key = CommonFunc::childField('field_child_key');
        $participation_key = CommonFunc::childField('field_participation_key');
		$post_data = [
			"client_key" => $client_key,
			"participation_key" => $participation_key,
			"from_date" => $today,
			"to_date" => $today
        ];
		$post_data = CommonFunc::APiHindi($post_data);
		$plan = NestleAPI::mealPlanLogin($post_data);
		if ($plan['status'] == 'success') {
			$meal_plans = $plan['contents']['day_plans'][0]['meal_plans'];
			


			$meal_index = $plan['contents']['day_plans'][0]['current_meal_key'];
			if (!empty($meal_plans)) {
				$current_meal_key = $plan['contents']['day_plans'][0]['current_meal_key'];
				$current_meal_name = $plan['contents']['day_plans'][0]['current_meal_name'];
				$meal_rda = $plan['contents']['rda_entries'];
				$meal_nutrients = $plan['contents']['nutrients'];
				$consumed_nutrients = $plan['contents']['nutritional_values'];
				foreach ($meal_plans as $key => $meal_plan) {
				$data['name'] = $meal_plan['name'];
				$data['key'] = $meal_plan['key'];

				if(!empty($meal_plan['recipe_entries'])){
					foreach ($meal_plan['recipe_entries'] as $mealkey => $meal_plan_value) {
						$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($meal_plan_value['seo_name'])['recipeMetadata'];
						$recipeFavData = CommonFunc::getRecipeFavlikeDislike($meal_plan_value['seo_name'], $cur_lang);
						$meal_plan['recipe_entries'][$mealkey]['fav'] = $recipeFavData;
						$meal_plan['recipe_entries'][$mealkey]['recipeMetadata'] = $recipeMetaData;
						$recipeRatingData =  CommonFunc::getRecipeRatingBySeo($meal_plan_value['seo_name'], $cur_lang);;
						$meal_plan['recipe_entries'][$mealkey]['gRating'] = $recipeRatingData;
					}
				}
				$data['recipe_entries'] = $meal_plan['recipe_entries'];
				if(is_array($meal_plan) && array_key_exists('key', $meal_plan) && $meal_plan['key'] == $plan['contents']['day_plans'][0]['current_meal_key']) {
				$data['status'] = 'mp-active';
				$data['sub_status'] = 'mpactive';
				$data['nutrients'] = CommonFunc::mealNutrient($meal_rda, $meal_nutrients, $consumed_nutrients);
			
				} else {
				$data['status'] = 'mp-inactive';
				$data['sub_status'] = 'mpinactive';
				$data['nutrients'] = 'NA';
				}

				$meal_data[] = $data;
				}
			} else {
				$meal_data = '';
			}
		} else {
			$meal_data = '';
		}			
		 $content['hindi'] = $hindi;
		 $content['reg_meal_welcome'] = $globmealVarable['reg_meal_welcome'];
		 $content['reg_meal_welcome_desc'] = $globmealVarable['reg_meal_welcome_desc'];
		 $content['reg_meal_custom_Meal'] = $globmealVarable['reg_meal_custom_Meal'];
		 $content['reg_meal_footer_rda'] = $globmealVarable['reg_meal_footer_rda'];
		 $content['reg_meal_show_entire'] = $globmealVarable['reg_meal_show_entire'];
		return [
			'#theme' => 'RegRoutine',
			'#meals' => $meal_data,
			'#hindi' => $hindi,
			'#base_url' => $base_url,
			'#content' => $content,
			'#attached' => [
				'library' => 'nestle_meal_plan/nestle_meal_plan_style',
				'drupalSettings' => [
					'lang' => $lang_code,
				],
			],
		];
	}
   }
   
 
}
