<?php

namespace Drupal\nestle_meal_plan\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\nestle_meal_plan\Controller\HomePageMealPlan;

/**
 * @Block(
 *   id = "home_custom_meal_Login_data_block",
 *   admin_label = @Translation("Custom Meal Plan for Login user Block"),
 *   category = @Translation("Custom Meal Plan for Login user Block")
 * )
 */
 
class HomePageMealPlanBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
	  
	# Home page registerd user custom meal plan code
	# start date : 24-11-2022
	# data come from Custom Module: nestle_meal_plan
	# controller Name : HomePageMealPlan

	$h_page_custom_meal_plan = HomePageMealPlan::HomePageLoginUserMealPlan();
	return $h_page_custom_meal_plan;


  }
}