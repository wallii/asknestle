<?php

namespace Drupal\nestle_meal_plan\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\config_pages\Entity\ConfigPages;

/**
 * Provides meal plan form.
 *
 * @internal
 */
class MealPlanForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'meal_plan_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $base_url;
    //get the field value from the custom meal plan config page
    $customMealPlanConfigPage = ConfigPages::config('nestle_custom_meal_plan_form');
    $heading_1 = $customMealPlanConfigPage->get('field_faq_text')->value;
	$heading_p = $customMealPlanConfigPage->get('field_faq_answer')->value;
	$choose_pref = $customMealPlanConfigPage->get('field_meal_plan_form_pref')->value;
    $tell_age = $customMealPlanConfigPage->get('field_tell_age')->value;
    $disclaimer = $customMealPlanConfigPage->get('field_footer_disclaimer')->value;
    $btn_text = $customMealPlanConfigPage->get('field_button_text')->value;

    if (\Drupal::currentUser()->isAnonymous()) {
      $form['form_heading'] =[
        '#markup' => $heading_1
      ];
	  $form['form_heading_p'] =[
        '#markup' => $heading_p
      ];
	  $form['choose_pref'] =[
        '#markup' => $choose_pref
      ];
      $options = [
        'Veg' => t('Veg'),
        'Nonveg' => t('Non-Veg'),
      ];
      $form['food_type'] = [
        '#type' => 'radios',
        '#options' => $options,
        '#default_value' => 'Veg',
        '#required' => TRUE,
      ];
      $form['tell_age'] = [
        '#markup' => $tell_age
      ];
      
      $form['age'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('inptFld'), 'id' => array('home-meal-age') ,'autocomplete' => array('off')),
        '#default_value' => '',
        '#placeholder' => t('Eg.').' 2',
        '#min' => 2,
        '#max' => 50,
        '#required' =>TRUE
      ];
      $form['month'] = [
        '#type' => 'number',
        '#attributes' => array('class' => array('inptFld'), 'id' => array('home-meal-month') ,'autocomplete' => array('off')),
        '#default_value' => 0,
        '#placeholder' => t('Eg.').' 1',
        '#min' => 0,
        '#max' => 11,
        '#required' =>TRUE
      ];
      $form['form_disclaimer'] = [
        '#markup' => $disclaimer
      ];
      $form['submit'] = [
        '#type' => 'submit',
        '#value' => $btn_text,
        '#attributes' => array('class' => array('primary-button hvr-ripple-out'),'id' => array('homemealplanbutton')),
        '#validate' => ['::submitValidateMeal'],
      ];

      $form['#theme'] = 'MealPlanForm';
      return $form;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitValidateMeal(array &$form, FormStateInterface $form_state) {
    if ($form_state->getValue('age') == '') {
        $form_state->setErrorByName('age', 'Please select date of birth');
    } 
	else if ($form_state->getValue('month') == '') {
		if($form_state->getValue('age') ==50) {
			parent::validateForm($form, $form_state);
			$form_state->setValue('month', 0);
			$form_state->setRebuild();
		} else {
		$form_state->setErrorByName('month', 'Please select Month');
		}
		
        
    } 
    elseif ($form_state->getValue('age') < 2) {
      $form_state->setErrorByName('age', 'Minimum required age is 2 year.');
    } 
    elseif ($form_state->getValue('age') > 50) {
      $form_state->setErrorByName('age', 'The recommendations are for healthy children between 2 year to 12 years of age. Please enter appropriate age.');
    } else if ($form_state->getValue('month') > 11) {
		$form_state->setErrorByName('month', 'Maximum required month is 11 month.');
	}
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
	  
	  $age = (int)$form_state->getValue('age');
	  $month = (int)$form_state->getValue('month');
	if($age == 50) {
		$month = 0;
	}
	$sepr = '.';
    $food_type = $form_state->getValue('food_type');
    
	$finalAge = $age .$sepr.$month;
	$finalint = $finalAge;
	$meal_data = ['age' => $finalint, 'food_preference' => $food_type];
    $session = \Drupal::request()->getSession();
    $session->set('meal_form_data', $meal_data);
    $form_state->setRedirect('nestle_meal_plan.unreg_routine');
    
  }

}
