<?php

namespace Drupal\nestle_meal_plan\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\nestle_common\Controller\CommonFunc;

/**
 * Provides meal plan form.
 *
 * @internal
 */
class MealPlanInnerForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'meal_plan_inner_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $base_url;
    //get the field value from the custom meal plan config page
	$globMealPlanVar['meal_mlan_form_heading'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_heading_1');
	$globMealPlanVar['meal_mlan_form_heading_2'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_heading_2');
	$globMealPlanVar['meal_mlan_form_Subheading'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_subheading');
	$globMealPlanVar['meal_mlan_form_Subheading'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_subheading');
	$globMealPlanVar['meal_mlan_form_Disclaimer'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_disclaimer');
	
	$globMealPlanVar['meal_mlan_form_button_text'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_button_text');
	
	$globMealPlanVar['meal_mlan_form_footer_desc'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_footer_disclaimer');
	$globMealPlanVar['meal_mlan_form_rda_desc'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_rda_description');


    $globMealPlanVar['meal_mlan_form_pref'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_meal_plan_form_pref');

    $globMealPlanVar['meal_mlan_form_tell_age'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_tell_age');

    $globMealPlanVar['meal_mlan_form_page_footer_dis'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_meal_page_footer');
	$globMealPlanVar['meal_mlan_form_page_rdapopup'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_unreg_meal_head_desc');
    

    if (\Drupal::currentUser()->isAnonymous()) {
      $options = [
        'Veg' => t('Vegetarian'),
        'Nonveg' => t('Non-Vegetarian'),
      ];

      $form['food_type'] = [
        '#type' => 'radios',
        '#options' => $options,
        '#default_value' => 'Veg',
        '#required' => TRUE,
      ];
	  $form['age'] = [
          '#type' => 'number',
		  '#attributes' => array('class' => array('input-filed'), 'id' => array('meal-form-age') ,'autocomplete' => array('off')),
          '#default_value' => '',
          '#placeholder' => 'Eg. 2',
		  '#min' => 2,
		  '#max' => 50,
          '#required' =>TRUE
      ];
	  $form['month'] = [
          '#type' => 'number',
		  '#attributes' => array('class' => array('input-filed'), 'id' => array('meal-form-month') ,'autocomplete' => array('off')),
          '#default_value' => 0,
          '#placeholder' => 'Eg. 1',
		  '#min' => 0,
		  '#max' => 11,
          '#required' =>TRUE
        ];
      $form['submit'] = [
        '#type' => 'submit',
        '#value' => $globMealPlanVar['meal_mlan_form_button_text'],
        '#attributes' => array('class' => array('primary-button'),'id' => array('mealplancustom')),
        '#validate' => ['::submitValidateMeal'],
      ];
	  
	  
        $form['#theme'] = 'MealPlanInnerForm';
	  $form['#meal_mlan_form_heading'] = $globMealPlanVar['meal_mlan_form_heading'];
	  $form['#meal_mlan_form_heading_2'] = $globMealPlanVar['meal_mlan_form_heading_2'];
	  $form['#meal_mlan_form_Subheading'] = $globMealPlanVar['meal_mlan_form_Subheading'];
	  $form['#meal_mlan_form_Disclaimer'] = $globMealPlanVar['meal_mlan_form_Disclaimer'];
	  $form['#meal_mlan_form_footer_desc'] = $globMealPlanVar['meal_mlan_form_footer_desc'];
	  $form['#meal_mlan_form_rda_desc'] = $globMealPlanVar['meal_mlan_form_rda_desc'];

    $form['#meal_mlan_form_pref'] = $globMealPlanVar['meal_mlan_form_pref'];
    $form['#meal_mlan_form_tell_age'] = $globMealPlanVar['meal_mlan_form_tell_age'];
    $form['#meal_mlan_form_page_footer_dis'] = $globMealPlanVar['meal_mlan_form_page_footer_dis'];
     $form['#meal_mlan_form_page_rdapopup'] = $globMealPlanVar['meal_mlan_form_page_rdapopup'];
	 $form['#click_above_rda'] = CommonFunc::getConfigPageFieldValue('nestle_custom_meal_plan_form', 'field_inner_balanced_meal_text');
    
	  $form['#attached']['library'][] = 'nestle_meal_plan/nestle_meal_plan_style';
      return $form;
    } else {
		return new RedirectResponse($base_url . '/meal-plan/routine');
	}
  }

  /**
   * {@inheritdoc}
   */
  public function submitValidateMeal(array &$form, FormStateInterface $form_state) {
    if ($form_state->getValue('age') == '') {
        $form_state->setErrorByName('age', 'Please select date of birth');
    } 
	else if ($form_state->getValue('month') == '') {
		if($form_state->getValue('age') ==50) {
			parent::validateForm($form, $form_state);
			$form_state->setValue('month', 0);
			$form_state->setRebuild();
		} else {
		$form_state->setErrorByName('month', 'Please select Month');
		}
		
        
    } 
    elseif ($form_state->getValue('age') < 2) {
      $form_state->setErrorByName('age', 'Minimum required age is 2 year.');
    } 
    elseif ($form_state->getValue('age') > 50) {
      $form_state->setErrorByName('age', 'The recommendations are for healthy children between 2 year to 12 years of age. Please enter appropriate age.');
    } else if ($form_state->getValue('month') > 11) {
		$form_state->setErrorByName('month', 'Maximum required month is 11 month.');
	}
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
	  $age = (int)$form_state->getValue('age');
	$month = (int)$form_state->getValue('month');
	if($age == 50) {
		$month = 0;
	}
	$sepr = '.';
    $food_type = $form_state->getValue('food_type');
    
	$finalAge = $age .$sepr.$month;
	$finalint = $finalAge;
	$meal_data = ['age' => $finalint, 'food_preference' => $food_type];
    $session = \Drupal::request()->getSession();
    $session->set('meal_form_data', $meal_data);
    $form_state->setRedirect('nestle_meal_plan.unreg_routine');
    
  }

}
