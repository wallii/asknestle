(function ($, Drupal) {
	
	$('.rda-tabslider').slick({
  slidesToShow: 4,
  arrows: true,
  loop: false,
  dots: false,
  responsive: [
    {
      breakpoint: 1023,
      settings: {
        arrows: false,
              infinite: false,
        centerMode: false,
        slidesToShow: 3.4,
        dots: false
      }
    },
    {
      breakpoint: 767,
      settings: {
        arrows: false,
              infinite: false,
        centerMode: false,
        dots: true,
        slidesToShow: 2.4
      }
    },
    {
      breakpoint: 420,
      settings: {
        arrows: false,
              infinite: false,
        centerMode: false,
        dots: true,
        slidesToShow: 2.2
      }
    }
  ]
});          
         

	
	$(document).on('click', '.open-dietpopup', function () {
       $("#diet-popup").show();	
	});
	$(".mpactive").show();
	function hindiUrl(){
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
			var short_url = "hindi/";
		} 
		else {
			var short_url = "";
		}
		return short_url;
	}
    var short_url = hindiUrl();
	var laoderHtml = '<div class="loader"><span></span></div>';
	
	$(document).on('click', '.rda_show', function () {
       $("#rda-popup").show();	
	});
	
	$(document).on('click', '.nitrient_show', function () {
       $("#nutrient-popup").show();	
	});
	
	$(document).on('click', '.mealplan-acodn h4', function () {

		var mealTime = $(this).attr('data-time');
		if($(this).attr('class') !='mp-active') {
			$(laoderHtml).appendTo(".mealplan-acodn");
			$.ajax({
				url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
				type: 'post',
				cache: false,
					data: {
					"action": "customMealData",
					"mealTime": mealTime,
					"date": ''
				},
				success: function (response) {
					$(".loader").remove();
					var res = response.nutrients;
					$(".mp-active").next().children().eq(1).html(res);
					destroyCarouselrda();
                    slickCarouselrda();         

					/*
					$( ".rda-tab li a" ).bind( "click", function() {
						$(this).parents('.mealplan-acodn-cont').find(".rda-tab li a").removeClass("rda-active");		
						$(this).addClass("rda-active");	
						var dataContent= $(this).attr("data-cont");
						$(this).parents('.mealplan-acodn-cont').find(".rda-contcommon").html(dataContent);	
					});
					*/
				}

			});

		}

		$(this).next(".mealplan-acodn-cont").slideDown("slow");
		$(".mealplan-acodn .mealplan-acodn-cont:visible").not($(this).next(".mealplan-acodn-cont")).slideUp("slow");
		$(this).addClass("mp-active");
		$(this).removeClass("mp-inactive");
		$(this).siblings("h4").removeClass("mp-active");
		$(".mealplan-acodn h4").not($(this)).removeClass("mp-active");
		
		
	});	
	if($(".rda-tabslider .rda-thum a").hasClass( "rda-active" )) {
	  $(".rda-tabcont .rda-contcommon").html($(".rda-active").attr('data-cont'));	
	}
	$(document).on('click', '.rda-tabslider .rda-thum a', function (e) {
		e.preventDefault();
		$(this).parents('.mealplan-acodn-cont').find(".rda-tabslider .rda-thum a").removeClass("rda-active");		
		$(this).addClass("rda-active");	
		var dataContent= $(this).attr("data-cont");
		$(this).parents('.mealplan-acodn-cont').find(".rda-contcommon").html(dataContent);	
	});
	/**
	Entire day show hide
	**/
	$("#entire_day").on("click", function (e) {

		if($('#entire_day').is(':checked')) {
			$(".entireday_mp-inactive").show();
			
		} else {
			$(".entireday_mp-inactive").hide();
		}

	});

	if($('#entire_day').is(':checked')) {
		$(".entireday_mp-inactive").show();
	} else {
		$(".entireday_mp-inactive").hide();
	}
	/**
	 Replace Meal Code
	**/
	$(document).on('click', '.seereplace div.meal-refresh', function (e) {
		var replaId = $(this).data('mkey');
		$.ajax({
			url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
			type: 'post',
			cache: false,
			data: {
				"action": "getAlternateFood",
				"r_id": $(this).data('id'),
				"innerNutriId": $(this).data('rid'),
				"replaId": $(this).data('mkey'),
				"sngcount": $(this).data('sngcount')
			},
			beforeSend: function () {
				$(laoderHtml).appendTo(".rcips-list");
			},
			success: function (response) {
				console.log(response);
				$(".loader").remove();
				$("#meal_replace_section_data_"+replaId).html(response);
				$(".meal-replace-section").addClass("openpp");
			}					
		});
	});
	/**
	 Replace Meal close popup
	**/
	$(document).on('click', '.meal-replace-section span.closepop', function (e) {
		$(".meal-replace-section").removeClass("openpp");
	});
	
	/**
	Set alternative Food
	**/
	$(document).on('click', '.meal-replace-section ul li', function (e) {
	
		var e_id = $(this).data('e_id');
		var r_id = $(this).data('r_id');
		var replaceDivId = $(this).data('repid');
		var replaId = $(this).data('mkey');
		$.ajax({
			url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
			type: 'post',
			cache: false,
			data: {
				"action": "setAlternateFood",
				"e_id": $(this).data('e_id'),
				"replaId": $(this).data('mkey'),
				"r_id": $(this).data('r_id')
			},
			beforeSend: function () {
				$(laoderHtml).appendTo(".rcips-list");
			},
			success: function (response) {
				$('#'+replaceDivId).replaceWith(response);
				$(".loader").remove();
				$(".meal-replace-section").removeClass("openpp");
			}
		});

	});
		

		
		
	
   
})(jQuery, Drupal);

function slickCarouselrda() {
	
	$('.rda-tabslider').slick({
	slidesToShow: 4,
	arrows: true,
	loop: false,
	dots: false,
	responsive: [
	{
	breakpoint: 1023,
	settings: {
	arrows: false,
		  infinite: false,
	centerMode: false,
	slidesToShow: 3.4,
	dots: false
	}
	},
	{
	breakpoint: 767,
	settings: {
	arrows: false,
		  infinite: false,
	centerMode: false,
	dots: true,
	slidesToShow: 2.4
	}
	},
	{
	breakpoint: 420,
	settings: {
	arrows: false,
		  infinite: false,
	centerMode: false,
	dots: true,
	slidesToShow: 2.2
	}
	}
	]
	}); 
	
}

function destroyCarouselrda() {
  if ($('.rda-tabslider').hasClass('slick-initialized')) {
    $('.rda-tabslider').slick('destroy');
  }      
}