/**
 * @file
 * Handles gtm_custom data.
 */

/**
 * Expert Advice Filter Click : functionality in expert advice module
 * Custom Meal Plan : functionality in meal plan module
 * Healty Recipe : functionality in cms pages module
 */
!(function (e, t, a) {
	var count = 0;
	var countclick = 0;
	t.behaviors.gtm_custom = {
		attach: function (n, i) {
			
			var r = a.hindi,
                c = a.category_name,
                o = /^[0-9]+$/,
                l = new RegExp(/^\d*\.?\d*$/),
                s = ["Veg", "Nonveg"],
                p = new RegExp(/^\d*\-?\d*$/);
				
			function h(e) {
                for (var t = e + "=", a = decodeURIComponent(document.cookie).split(";"), n = 0; n < a.length; n++) {
                    for (var i = a[n]; " " == i.charAt(0); ) i = i.substring(1);
                    if (0 == i.indexOf(t)) return i.substring(t.length, i.length);
                }
                return "";
            }
			 function d() {
                return t.checkPlain(window.location.href);
            }
            function u(e) {
                var a = "";
                return (null == e && "" == e) || (a = t.checkPlain(e)), a;
            }
            function v(e) {
                var a = (e = t.checkPlain(e)).trim();
                return 1 == a || 2 == a ? a : "no";
            }
            function g(e) {
                var a = (e = t.checkPlain(e)).trim();
                return a.match(/^[0-9]+$/) && a <= 12 && a >= 0 ? a : "no";
            }
            function m(e) {
                var a = (e = t.checkPlain(e)).trim();
                return a.match(/^[0-9]+$/) && a <= 11 && a >= 0 ? a : "no";
            }
			function k(n, i) {
                var c,
                    d,
                    k = t.checkPlain(h("_ga")),
                    y = t.checkPlain(h("_ga")),
                    f = k.split("GA1.2.")[1];
                if (((user_type = null == y ? "New" : "Returning"), (lang = r ? "Hindi" : "English"), "PageLoad" == n))
                    dataLayer.push({
                        event: "GAPageveiw",
                        VisitorID: f,
                        URL1: u(a.current_path1),
                        URL2: u(a.current_path2),
                        PageName: u(a.page_title),
                        UserType: u(user_type),
                        UserId: u(a.user_id),
                        LoginStatus: u(a.login_status),
                        ChildId: u(a.child_id),
                        RegisterationStatus: u(a.registration_status),
                        Mobile: u(a.mobile),
                        Email: u(a.email),
                        UserChild: u(a.user_childs),
                        PageType: u(a.page_type),
                        ArticleName: u(a.article_name),
                        ArticleCategory: u(a.article_category),
                        RecipeName: u(a.recipe_name),
                        RecipeCategory: u(a.recipe_category),
                        Websitelanguage: u(lang),
                    });
                else if ("LinkClick" == n) dataLayer.push({ event: "LinkClick", EventLabel: i, EventValue: i, EventAction: "Internal Link Click" });
                else if ("ExpertAdviceCategory" == n) dataLayer.push({ event: "ExpertAdvice", EventAction: "Expert Article Category Click", EventLabel: i, ArticleCategory: i });
                else if ("ExpertAdviceCategoryArticle" == n) {
                    var L = i.split("_");
                    dataLayer.push({ event: "ExpertAdvice", EventAction: "Expert Article Click", EventLabel: L[0], ArticleName: L[0], ArticleCategory: L[1] });
                } else if ("HomePageTopNavigation" == n)
                    dataLayer.push({ event: "HomePageTopNavigation", EventAction: "Top Navigation Click", EventLabel: i }),
                        a.user_id && "Custom Meal Plan" == i && dataLayer.push({ event: "CustomMealPlan", EventAction: "Get Meal Plan", EventLabel: "Meal Plan Generate" });
                else if ("PreCustomMealPlan" == n) {
                    var E = t.checkPlain(e('input[name="food_type"]:checked').val()),
                        b = ((c = e("#vital_height").val()), (d = (c = t.checkPlain(c)).trim()), l.test(d) && d <= 12 && d >= 1 ? d : "no");
                    "Exist" ==
                        (function (e, t) {
                            for (var a = "Not exist", n = 0; n < t.length; n++)
                                if (t[n] == e) {
                                    a = "Exist";
                                    break;
                                }
                            return a;
                        })(E, s) &&
                        "no" != b &&
                        dataLayer.push({ event: "GetCustomMealPlan", EventAction: "Get Meal Plan", EventLabel: "Meal Plan Generate", ChildAge: b, FoodPreference: E });
                } else if ("PreGrowthTracker" == n) {
                    var A = v(e('input[name="gender"]:checked').val()),
                        C = (function (e) {
                            var a = (e = t.checkPlain(e)).trim();
                            return a.match(o) && a <= 150 && a >= 40 ? a : "no";
                        })(e("#vital_height").val()),
                        _ = (function (e) {
                            var a = (e = t.checkPlain(e)).trim();
                            return l.test(a) && a <= 100 && a >= 5 ? a : "no";
                        })(e("#vital_weight").val()),
                        x = g(e("#vital_dobYr").val()),
                        w = m(e("#vital_dobMth").val());
                    "no" != A &&
                        "no" != C &&
                        "no" != _ &&
                        "no" != x &&
                        "no" != w &&
                        dataLayer.push({ event: "GrowthTracker", EventAction: "Track Growth", EventLabel: "Begin Tracking", ChildAge: x + "." + w, ChildGender: 1 == A ? "Boy" : "Girl", ChildHeight: C + " Cms", ChildWeight: _ + " Kgs" });
                } else if ("PreImmunityTracker" == n) {
                    (A = v(e('input[name="gender"]:checked').val())), (x = g(e("#vital_dobYr").val())), (w = m(e("#vital_dobMth").val()));
                    "no" != A && "no" != x && "no" != w && dataLayer.push({ event: "ChildImmunity", EventAction: "Submit Details", EventLabel: "See Child's Immunity", ChildAge: x + "." + w, ChildGender: 1 == A ? "Boy" : "Girl" });
                } else if ("Filters" == n) {
                    var S = new Array();
                    e('#regionPrefrence[name="regionPrefrence[]"] option:selected').each(function () {
                        var t = e(this).data("eng");
                        S.push(t);
                    });
                    var P = new Array();
                    e('#mealPrefrence[name="mealPrefrence[]"] option:selected').each(function () {
                        var t = e(this).data("eng");
                        P.push(t);
                    });
                    var N = new Array();
                    e('#allrgPrefrence[name="allrgPrefrence[]"] option:selected').each(function () {
                        var t = e(this).data("eng");
                        N.push(t);
                    });
                    var M = (function (e) {
                        var a = (e = t.checkPlain(e)).trim();
                        return p.test(a) && "" != a ? a : "no";
                    })(e("#agegrp").val());
                    if ("no" != M) {
                        var R = "",
                            I = "",
                            G = "",
                            T = "";
                        void 0 !== S && (R = S.toString()),
                            void 0 !== P && (I = P.toString()),
                            void 0 !== N && (G = N.toString()),
                            (0 == M && null == M) || (T = M),
                            ("" == R && "" == I && "" == G && "" == T) || dataLayer.push({ event: "Filters", EventAction: "Apply Filter", EventLabel: "Filter Type", RegionalPreference: R, MealPreference: I, AllergyFood: G, AgeGroup: T });
                    }
                }
            }
			
			e(window, n)
			 .on("load", function () {
				 if(count == 0) {
					var n;
				   (null == (n = (n = t.checkPlain(a.active_theme)).trim()) && 0 == n.length) || ("nestle_new" != n) || k("PageLoad", 0);
				   
				 }
				 count++;
				 
			 });
			 
			 
			 e("body", n).on("click", ".eu-cookie-compliance-default-button", function () {
					dataLayer.push({
                        event: "CookiePermissionAction",
						EventAction: "Cookie Compaliance",
						EventLabel: "Ok",
                        
                    });
             });
			 e("body", n).on("click", ".eu-cookie-compliance-more-button", function () {
					dataLayer.push({
                        event: "CookiePermissionAction",
						EventAction: "Cookie Compaliance",
						EventLabel: "Know More",
                        
                    });
             });
			 
			 e("#mealplancustom", n).on("click", function () {
				  var loginstatus = u(a.login_status);
				  var pageName = u(a.page_title);
				  var mobileNumber = u(a.mobile);
				  var EmailId = u(a.email);
				  var foodpref =  e('.featbxask.active input[name="food_type"]').val();
				  var mealage = e("#meal-form-age").val();
				  var mealmonth = e("#meal-form-month").val();
				  var language = u(lang);
				  if(mealage != '') {
					dataLayer.push({ 
						event: "Get CustomMealPlan", 
						EventAction: "Get Meal Plan", 
						EventLabel: "Meal Plan Generate",
						ChildAge: mealage+'.'+mealmonth,
						FoodPreference: foodpref,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
                        Websitelanguage: language,						
					});
					  
				  } 
             });
			 
			 e("#homemealplanbutton", n).on("click", function () {
				  var loginstatus = u(a.login_status);
				  var pageName = u(a.page_title);
				  var mobileNumber = u(a.mobile);
				  var EmailId = u(a.email);
				  var foodpref =  e('.featbxask.active input[name="food_type"]').val();
				  var mealage = e("#home-meal-age").val();
				  var mealmonth = e("#home-meal-month").val();
				  var language = u(lang);
				  if(mealage != '') {
					dataLayer.push({ 
						event: "Get CustomMealPlan", 
						EventAction: "Get Meal Plan", 
						EventLabel: "Meal Plan Generate",
						ChildAge: mealage+'.'+mealmonth,
						FoodPreference: foodpref,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
                        Websitelanguage: language,						
					});
					  
				  } 
             });
			 
			 e(".measur-health-inr .form-submit", n).on("click", function () {
				  var loginstatus = u(a.login_status);
				  var pageName = u(a.page_title);
				  var mobileNumber = u(a.mobile);
				  var EmailId = u(a.email);
				  var gender =  (e('.measur-health-inr .gender-tab .active-gender input[name="gender"]').val()==1? "Male": "Female");
				  var mealage = e("#home-tack_year").val();
				  var mealmonth = e("#home-tack_month").val();
				  var height = e("#home-tack_height").val();
				  var weight = e("#home-tack_weight").val();
				  var language = u(lang);
				  
				  if(mealage != '' && height !='' && weight !='') {
					 
					dataLayer.push({ 
						event: "HealthTracker", 
						EventAction: "HealthTracker", 
						EventLabel: "Begin Tracking",
						ChildAge: mealage+'.'+mealmonth,
						ChildGender: gender,
						Height: height,
						Weight: weight,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
                        Websitelanguage: language,						
					});
				
					  
				  } 
             });
			 
			 e("#ask_global_search_btn", n).on("click", function () {
				 var serachVal = e('#ask_global_search').val();
				 if (serachVal) {
					serachVal = serachVal.trim();
				}
				var serachValrecipe = serachVal.replace(/\s/g, ''.length);
				if (serachValrecipe.length !== 0) {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "WebsiteSearch", 
						EventAction: "Site Search", 
						EventLabel: "Search Term",
						ResultSection: "GlobalSearch",
						SearchValue: serachValrecipe,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
                        Websitelanguage: language,						
					});
				}
				 
			 });
			 
			 e("#ask_global_search_button_mobile", n).on("click", function () {
				 var serachVal = e('#ask_global_search_mobile').val();
				 if (serachVal) {
					serachVal = serachVal.trim();
				}
				var serachValrecipe = serachVal.replace(/\s/g, ''.length);
				if (serachValrecipe.length !== 0) {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "WebsiteSearch", 
						EventAction: "Site Search", 
						EventLabel: "Search Term",
						ResultSection: "GlobalSearch",
						SearchValue: serachValrecipe,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
                        Websitelanguage: language,						
					});
				}
				 
			 });
			 
			 e("#ask_global_search", n).on("keydown", function (evnt) {
				 if (evnt.keyCode === 13) {
					var serachVal = e('#ask_global_search').val();
					if (serachVal) {
						serachVal = serachVal.trim();
					}
					var serachValrecipe = serachVal.replace(/\s/g, ''.length);
					if (serachValrecipe.length !== 0) {
						
						var loginstatus = u(a.login_status);
						var pageName = u(a.page_title);
						var mobileNumber = u(a.mobile);
						var EmailId = u(a.email);
						var language = u(lang);
						dataLayer.push({ 
							event: "WebsiteSearch", 
							EventAction: "Site Search", 
							EventLabel: "Search Term",
							ResultSection: "GlobalSearch",
							SearchValue: serachValrecipe,
							Mobile: mobileNumber,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});
					}
				 }
			 });
			 
			 e("#ask_global_search_mobile", n).on("keydown", function (evnt) {
				 if (evnt.keyCode === 13) {
					var serachVal = e('#ask_global_search_mobile').val();
					if (serachVal) {
						serachVal = serachVal.trim();
					}
					var serachValrecipe = serachVal.replace(/\s/g, ''.length);
					if (serachValrecipe.length !== 0) {
						
						var loginstatus = u(a.login_status);
						var pageName = u(a.page_title);
						var mobileNumber = u(a.mobile);
						var EmailId = u(a.email);
						var language = u(lang);
						dataLayer.push({ 
							event: "WebsiteSearch", 
							EventAction: "Site Search", 
							EventLabel: "Search Term",
							ResultSection: "GlobalSearch",
							SearchValue: serachValrecipe,
							Mobile: mobileNumber,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});
					}
				 }
			 });
			 
			 e(document)
			 .on('click', '.searchRecipeAutoGlobal,.searchArticleAutoGlobal,.searchCommunityAutoGlobal', function () {
		
				var serchVal = e(this).attr('data-title');
				var serchCat = e(this).attr('data-cat');
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "WebsiteSearch", 
					EventAction: "Site Search", 
					EventLabel: "Search Term",
					ResultSection: serchCat,
					SearchValue: serchVal,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 
			 e(document)
			 .on('click', '.viewallseacrh a', function () {
		
				var serachVal = e('#ask_global_search').val();
				var serchCat = e(this).attr('data-cat');
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "WebsiteSearch", 
					EventAction: "Site Search", 
					EventLabel: "Search Term",
					ResultSection: serchCat,
					SearchValue: serachVal,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 
			    e(".navbar ul.menu li.menu-item a", n).on("click", function () {
		
				var eventlabel = e(this).text();
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "TopNavigation", 
					EventAction: "Top Navigation Click", 
					EventLabel: eventlabel,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 
			  e(".menu-bar-inr .menulink-inr ul.menu li.menu-item a,.menu-profile-btn a,.menu-profile-login a", n).on("click", function () {
		
				var eventlabel = e(this).text();
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "SideNavigation", 
					EventAction: "Side Navigation Click", 
					EventLabel: eventlabel,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 
			 e(".master-banner-row div.banner-box div.banner-btn a", n).on("click", function () {
				var eventlabel = e(this).parents(".banner-intro-inr").children("h1").text();
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "HomePageBannerClick", 
					EventAction: "Banner Click", 
					EventLabel: eventlabel,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 e(".community-video-row div.community-thumcont a", n).on("click", function () {
				var eventlabel = e(this).children("p").text();
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "AskNestleCommunity", 
					EventAction: "Topic Click", 
					EventLabel: eventlabel,
					Topic: eventlabel,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 
			 e(".community-list div.like-msg-btn a.go-convrstn", n).on("click", function () {
				var eventlabel = e(this).parents(".item-comment").children("p").text();
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "AskNestleCommunity", 
					EventAction: "Go to Conversation", 
					EventLabel: "Go to Conversation click",
					Topic: eventlabel,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
			 e(".ask-community-row button.p_com", n).on("click", function () {
				var eventlabel = e(".ask-community-fild .searchbox .post_txt").val();
				if(eventlabel !='' ) {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "AskNestleCommunity", 
						EventAction: "Comment Submit", 
						EventLabel: "Asked Query",
						Question: eventlabel,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
				}
				
				
			 });
			 
			 e(".community-list .load-more-data #btn_more", n).on("click", function () {
			
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "AskNestleCommunity", 
						EventAction: "Load More", 
						EventLabel: "Load More community",
						Topic: "Community load more",
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
			 
			 e(".community-list .item-comment .like-msg i.thumup-icon", n).on("click", function () {
			        var topicval = e(this).parents(".item-comment").children("p").text();
					if(topicval == '') {
						topicval = e(".community-list .item-comment h4 p").text();
					}
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "AskNestleCommunity", 
						EventAction: "Like Topic", 
						EventLabel: "Topic Like",
						Topic: topicval,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
			 
			 e(".community-list .item-comment .like-msg i.msg-icon", n).on("click", function () {
			        var topicval = e(this).parents(".item-comment").children("p").text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "AskNestleCommunity", 
						EventAction: "View Comment", 
						EventLabel: "Topic comment view",
						Topic: topicval,
						Comment: "View Comment",
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
			 
			  e(".comment-form #edit-submit", n).on("click", function () {
			         var topicval = e(".community-list .item-comment h4 p").text();
					 var comment = e.trim(e("#edit-comment").val());
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
						event: "AskNestleCommunity", 
						EventAction: "Comment Submit", 
						EventLabel: "topic comment add",
						Topic: topicval,
						Comment: comment,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
			 
			 /** Expert article page GTM code */
             e(".article-tab items a", n).on("click", function () {
			        var tagval = e(this).text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advice",
						EventAction: "Article Tag Click", 
						EventLabel: tagval,
						Articletag: tagval,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
             e(".expertart-page .hm-row .heading a", n).on("click", function () {
			        var catval = e(this).parent(".heading").children("h2").text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advice",
						EventAction: "Show More", 
						EventLabel: catval,
						ArticleCategory: catval,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
             e(".expertart-page .hlty-rcips-box a", n).on("click", function () {
			        var catval = e(this).parent(".hlty-rcips-box").children("h4").text();
					var buttontxt = e(this).text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advice",
						EventAction: buttontxt, 
						EventLabel: "Go to healthy recipes Banner Click",
						ArticleCategory: catval,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
             
             e(".expertart-page .fullbanner a", n).on("click", function () {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advice",
						EventAction: "Sign up", 
						EventLabel: "Articles banner click",
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
             e(".expertart-page .trending-atcls .articlethumbimg a,.expertart-page .trending-atcls .thumText a,.article-list .articlethumbimg a,.article-list .thumText a", n).on("click", function () {
					var arttitle = e(this).attr("data-title");
					var artcat = e(this).attr("data-cat");
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advice",
						EventAction: "Article Click", 
						EventLabel: arttitle,
						ArticleCategory: artcat,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
			 
             e(".article-srch #src_txt", n).on("keydown", function (evnt) {
				 if (evnt.keyCode === 13) {
					var serachVal = e('.article-srch #src_txt').val();
					if (serachVal) {
						serachVal = serachVal.trim();
					}
					var serachValarticle = serachVal.replace(/\s/g, ''.length);
					if (serachValarticle.length !== 0) {
						
						var loginstatus = u(a.login_status);
						var pageName = u(a.page_title);
						var mobileNumber = u(a.mobile);
						var EmailId = u(a.email);
						var language = u(lang);
						dataLayer.push({ 
							event: "Expert Advice", 
							EventAction: "Search Query", 
							EventLabel: "Article Search Query",
							SearchValue: serachValarticle,
							Mobile: mobileNumber,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});
					}
				 }
			 });
             
             e(document)
			 .on('click', '.art_list .srchDataItm a', function () {
		
				var serchval = e(this).text();
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "Expert Advice", 
					EventAction: "Search Query", 
					EventLabel: "Article Search Query",
					SearchValue: serchval,
					Mobile: mobileNumber,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });

             e(".artCat_filter select.filter_by_age", n).on("change", function () {
				 
				    var valueselect = e(this).find("option:selected").text();
					var artcat = e(".h2_filter_age h2").text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advicee",
						EventAction: "Filter by age", 
						EventLabel: "Filter",
						ArticleCategory: artcat,
						FilterbyAge: valueselect,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
					
			 });
             
             e(".artCat_filter select.article-sort", n).on("change", function () {
				 
				    var valueselect = e(this).find("option:selected").text();
					var artcat = e(".h2_filter_age h2").text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Expert Advice",
						EventAction: "Sort by", 
						EventLabel: "Filter",
						ArticleCategory: artcat,
						SortBy: valueselect,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
					
			 });
             /** Healthy Recipe **/	
             e(".recipecatTab .items a", n).on("change", function () {
				 
				    var tagvalue = e(this).text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Healthy Recipe",
						EventAction: "Tag Click", 
						EventLabel: tagvalue,
						SortBy: valueselect,
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
					
			 });
             e(".article-srch #recipes-search", n).on("keydown", function (evnt) {
				  if (evnt.keyCode === 13) {
				    var serachVal = e('.article-srch #recipes-search').val();
					if (serachVal) {
						serachVal = serachVal.trim();
					}
					var serachValarecipe = serachVal.replace(/\s/g, ''.length);
					if (serachValarecipe.length !== 0) {
						var loginstatus = u(a.login_status);
						var pageName = u(a.page_title);
						var mobileNumber = u(a.mobile);
						var EmailId = u(a.email);
						var language = u(lang);
						dataLayer.push({ 
							event: "Healthy Recipe",
							EventAction: "Search Query", 
							EventLabel: 'Recipe Serach query',
							SearchValue: serachValarecipe,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});
				   }
                  }					
					
			 });
             e(".article-srch #recipesearchid", n).on("click", function () {
				 
				    var serachvalue = e(".article-srch #recipes-search").val();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
							event: "Healthy Recipe",
							EventAction: "Search Query", 
							EventLabel: 'Recipe Serach query',
							SearchValue: serachvalue,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});	
					
			 }); 
             e(document)
			 .on('click', '.article-srch .searchAutofood', function () {
		
				var serchval = e(this).attr("data-title");
				var loginstatus = u(a.login_status);
				var pageName = u(a.page_title);
				var mobileNumber = u(a.mobile);
				var EmailId = u(a.email);
				var language = u(lang);
				dataLayer.push({ 
					event: "Healthy Recipe",
					EventAction: "Search Query", 
					EventLabel: 'Recipe Serach query',
					SearchValue: serchval,
					Email: EmailId,
					LoginStatus: loginstatus,
					pageName: pageName,
					Websitelanguage: language,						
				});
				
			 });
             e(".gallery-recipes .thumGlryImg a,.gallery-recipes .thumGlryText a", n).on("click", function () {
				    var recipeVal = e(this).attr("data-title");
					var recipeSection = e(this).attr("data-cat");
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
							event: "Healthy Recipe",
							EventAction: "Recipe Click", 
							EventLabel: recipeSection,
							RecipeName: recipeVal,
							RecipeSection: recipeSection,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});	
					
			 }); 
             e(".recipes-categ .thumGlryImg a,.recipes-categ .thumGlryText a,.rcips-list .imgWrp a,.rcips-list .txtb a", n).on("click", function () {
				    var recipeVal = e(this).attr("data-title");
					var recipeSection = e(this).attr("data-cat");
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
							event: "Healthy Recipe",
							EventAction: "Recipe Click", 
							EventLabel: recipeSection,
							RecipeCategoryName: recipeVal,
							RecipeSection: recipeSection,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});	
					
			 });
             e(".recipecatwise .heading a", n).on("click", function () {
				    var recipeCat = e(this).attr("data-cat");
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
							event: "Healthy Recipe",
							EventAction: "Show More", 
							EventLabel: recipeCat,
							RecipeCategoryName: recipeCat,
							RecipeSection: recipeCat,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});	
					
			 });
             e(".recipecatwise .imgWrp a,.recipecatwise .txtb a", n).on("click", function () {
				    var recipename = e(this).attr("data-title");
					var recipecat = e(this).attr("data-cat");
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
							event: "Healthy Recipe",
							EventAction: "Recipe Click", 
							EventLabel: recipecat,
							RecipeName: recipename,
							RecipeSection: recipecat,
							Email: EmailId,
							LoginStatus: loginstatus,
							pageName: pageName,
							Websitelanguage: language,						
						});	
					
			 });
             e(".recipecatwise .fullbanner a", n).on("click", function () {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Healthy Recipe",
						EventAction: "Sign up", 
						EventLabel: "Recipe banner click",
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});	
			 });
             e(".choose-prfncs #get_recipe_time_slot", n).on("click", function () {
				   
					var foodpref = $('input[name="recipe_food_pref"]:checked').val();
					let timeSlotRecipeVal = $("#timeslot_recipe").val();
		            let timeSlotrecipeTime = $("#timeslopt_recipe_time").val();
					let catKey = $(".rcips-list").attr("data-key");
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "Healthy Recipe",
						EventAction: "Filter Recipe", 
						EventLabel: catKey,
						RecipeSection: catKey,
                        Filterbytimeslot: timeSlotRecipeVal,
                        FilterybyCookingtime : timeSlotrecipeTime+' mins',
                        VegNonVeg: foodpref,  						
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});
                    				
			 });
             /** Food diary **/
			 
			 /** whats aap **/
			 e(".floaterwhatsapp-icon", n).on("click", function () {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "WhatsAppBot",
						EventAction: "WABotIconClicked", 
						EventLabel: "WA Click", 						
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});
                    				
			 });
			 e(".overlay-wtsp .proceed-cta a", n).on("click", function () {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "WhatsAppBot",
						EventAction: "Proceed", 
						EventLabel: "WA Proceed", 						
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});
                    				
			 });
			 e(".overlay-wtsp .popupwtsp a.wtspclose", n).on("click", function () {
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "WhatsAppBot",
						EventAction: "Closed from Top", 
						EventLabel: "WA Closed from Top", 						
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});
                    				
			 });
			 e(".gettouch-details .gettouch-text em a", n).on("click", function () {
				    var eventval = e(this).parents(".gettouch-text").children("i").text();
					var loginstatus = u(a.login_status);
					var pageName = u(a.page_title);
					var mobileNumber = u(a.mobile);
					var EmailId = u(a.email);
					var language = u(lang);
					dataLayer.push({ 
					    event: "ContactUs",
						EventAction: "ContactUs", 
						EventLabel: eventval, 						
						Mobile: mobileNumber,
						Email: EmailId,
						LoginStatus: loginstatus,
						pageName: pageName,
						Websitelanguage: language,						
					});
					
                    				
			 });
		    
		},
		
		
	};
	
})(jQuery, Drupal, drupalSettings);
	