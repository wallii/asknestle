(function ($, Drupal) {
  'use strict';
  function setMarkUnmark(selector, action, target){
      var $this = selector;
      var recipeId= $this.attr('data-recipeid');
       var recipeHindiName = $this.attr('data-hindiname');
       var recipeEngName = $this.attr('data-engname');
        var lang = drupalSettings.language;
        if (lang == "hi") {
          var short_url ="hindi/";
          var recipeAltSeoName = $this.attr('data-recipeseoname');
          var recipeSeoName= $this.attr('data-recipeseoalternatename');
        } 
        else {
          var recipeSeoName= $this.attr('data-recipeseoname');
          var recipeAltSeoName= $this.attr('data-recipeseoalternatename');
            var short_url = "";
        }
      $.ajax({
        url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
        type: 'post',
        cache: false,
        data: {
          "action": "saveBookmarkRecipe",
          "id": recipeId,
          "recipeAction": action,
          "recipeSeoName": recipeSeoName,
          "recipeAltSeoName": recipeAltSeoName,
          "recipeHindiName": recipeHindiName,
          "recipeEngName": recipeEngName,
          "lang": lang
        },
        success: function (response) {
          
          //console.log(recipeHindiName);
          if(response == 'added'){
            $this.attr('data-mark', 'unmark');
            $this.addClass('active- active-bookmark');
          }else{
            $this.attr('data-mark', 'mark');
            $this.removeClass('active- active-bookmark');

          }
        }
        });
     }

    $(document).on('click', '.recipe-bookmark', function () {
      var target = $(this).attr('data-target');
      if($(this).attr('data-mark') == 'mark'){
        var action = 'add';
       }else{
        var action ='remove';
       }
       var $this = $(this);
       setMarkUnmark($this, action, target);
    });

})(jQuery, Drupal);
