<?php

namespace Drupal\custom_meta\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\Core\Link;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Messenger\Messenger;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Form\FormBuilder;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Provides controllers for Custom Meta Tag.
 */
class CustomMetaTags extends ControllerBase {
  use StringTranslationTrait;

  /**
   * Drupal\Core\Database\Connection definition.
   *
   * @var Drupal\Core\Database\Connection
   */
  protected $connection;

  /**
   * The messenger service.
   *
   * @var \Drupal\Core\Messenger\Messenger
   */
  protected $messenger;

  /**
   * The current path.
   *
   * @var string
   */
  protected $currentPath;

  /**
   * The Form Builder.
   *
   * @var string
   */
  protected $formBuilder;

  /**
   * The entity query.
   *
   * @param \Drupal\Core\Database\Connection $connection
   *   The database connection.
   * @param \Drupal\Core\Messenger\Messenger $messenger
   *   The messenger service.
   * @param \Drupal\Core\Path\CurrentPathStack $currentPath
   *   The current path stack.
   * @param \Drupal\Core\Form\FormBuilder $formBuilder
   *   The Form Builder.
   */
  public function __construct(Connection $connection, Messenger $messenger, CurrentPathStack $currentPath, FormBuilder $formBuilder) {
    $this->connection = $connection;
    $this->messenger = $messenger;
    $this->currentPath = strtolower($currentPath->getPath());
    $this->formBuilder = $formBuilder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database'),
      $container->get('messenger'),
      $container->get('path.current'),
      $container->get('form_builder')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function metaTagList() {

    $header = [
      'label_0' => [
        'data' => $this->t('#'),
      ],
      'label_1' => [
        'data' => $this->t('Meta Url'),
      ],
      'label_2' => [
        'data' => $this->t('Meta Title'),
      ],
      'label_3' => [
        'data' => $this->t('Meta Description'),
      ],
      'label_4' => [
        'data' => $this->t('Hindi Meta Title'),
      ],
      'label_5' => [
        'data' => $this->t('Hindi Meta Description'),
      ],
      'label_6' => [
        'data' => $this->t('Action'),
      ],
      'label_7' => [
        'data' => $this->t(''),
      ],
    ];

    $query = $this->connection->select('custom_meta_tags', 'tags')->fields('tags', [
      'meta_id',
      'meta_url',
      'meta_title',
      'meta_desc',
      'hindi_meta_title',
      'hindi_meta_desc',
    ])->orderby('meta_id', 'DESC');
    if (!empty(\Drupal::request()->get('param'))) {
      $query = $query->condition('meta_url', '%' . db_like(\Drupal::request()->get('param')) . '%', 'LIKE');
    }
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(50);
    $reports = $pager->execute()->fetchAll();

    $rows = [];
    $i    = 1;
    foreach ($reports as $report) {
      $row    = [];
      $row[]  = $i;
      $row[]  = $report->meta_url;
      $row[]  = $report->meta_title;
      $row[]  = CommonFunc::summary($report->meta_desc, 100);
      $row[]  = $report->hindi_meta_title;
      $row[]  = CommonFunc::summary($report->hindi_meta_desc, 100);
      $row[]  = Link::createFromRoute($this->t('Edit'), 'custom_meta.edit', ['id' => $report->meta_id], ['relative' => TRUE]);
      $row[]  = Link::createFromRoute($this->t('Delete'), 'custom_meta.delete', ['id' => $report->meta_id], ['relative' => TRUE]);
      $rows[] = $row;
      $i++;
    }

    $build['form'] = $this->formBuilder->getForm('\Drupal\custom_meta\Form\SearchMetaTags');

    $build['table'] = [
      '#type'   => 'table',
      '#header' => $header,
      '#rows'   => $rows,
      '#empty'  => $this->t('No custom meta tag has been found.'),
    ];

    $build['pager'] = ['#type' => 'pager'];
    return $build;

  }

  /**
   * {@inheritdoc}
   */
  public function deleteMetaTag($id) {
    $this->connection->delete('custom_meta_tags')->condition('meta_id', $id)->execute();
    $this->messenger->addStatus($this->t('Meta data deleted Successfully!'));
    return $this->redirect('custom_meta.settings');
  }

  /**
   * {@inheritdoc}
   */
  public function getTitle() {
    $hindi        = CommonFunc::isHindi();
    $current_path = $this->currentPath;
    $array        = explode('/', $current_path);

    $site_config = $this->config('system.site');

    // Echo $current_path; exit();
    $query     = $this->connection->select('custom_meta_tags', 'tags')->fields('tags', [
      'meta_title',
      'meta_desc',
      'hindi_meta_title',
      'hindi_meta_desc',
    ])->condition('meta_url', $current_path, '=');
    $meta_data = $query->execute()->fetchAll();
    if (!empty($meta_data)) {
      if ($hindi) {
        $title = $meta_data[0]->hindi_meta_title;
      }
      else {
        $title = $meta_data[0]->meta_title;
      }
    }
    else {
      if ($array[1] == 'recipes' || $array[1] == 'recipe-by-time' || $array[1] == 'magic-meal-recipe' || $array[1] == 'meal-recipe') {
        $post_data      = ['recipe_name' => $array[2]];
        $post_data_mlng = CommonFunc::APiHindi($post_data);
        $r_detail       = NestleAPI::recipesDetail($post_data_mlng);
        if ($r_detail['status'] == 'success') {
          $recipe_data = $r_detail['contents']['recipe_details'][0];
          if ($hindi) {
            // $name_eng = $r_detail['contents']['gtm']['recipes'][0]['name'];
            $title = ucwords($recipe_data['name']) . ' रेसिपी, विधि - Ask Nestle';
          }
          else {
            $title = ucwords($recipe_data['name']) . ' Recipe for Kids, Quick & Easy';

            $recipetitallenth = strlen($title);

            if ($recipetitallenth >= 71 && $recipetitallenth <= 80) {
              $title = 'Quick & Easy ' . ucwords($recipe_data['name']) . ' Recipe';
            }
            elseif ($recipetitallenth >= 81) {
              $title = 'Easy ' . ucwords($recipe_data['name']) . ' Recipe';
            }
          }
        }
        else {
          $title = $site_config->get('name');
        }
      }
      else {
        $title = $site_config->get('name');
      }
    }

    return $title;

  }

}

