<?php

namespace Drupal\custom_meta\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\Core\Messenger\Messenger;

/**
 * Provides custom meta tag form.
 *
 * @internal
 */
class AddEditMetaTags extends FormBase {
  use StringTranslationTrait;

  /**
   * Drupal\Core\Database\Connection definition.
   *
   * @var Drupal\Core\Database\Connection
   */
  protected $connection;

  /**
   * Symfony\Component\HttpFoundation\RequestStack definition.
   *
   * @var Drupal\Core\Database\Connection
   */
  protected $requestStack;

  /**
   * The messenger service.
   *
   * @var \Drupal\Core\Messenger\Messenger
   */
  protected $messenger;

  /**
   * The entity query.
   *
   * @param \Drupal\Core\Database\Connection $connection
   *   The database connection.
   * @param \Symfony\Component\HttpFoundation\RequestStack $requestStack
   *   The Request Stack.
   * @param \Drupal\Core\Messenger\Messenger $messenger
   *   The messenger service.
   */
  public function __construct(Connection $connection, RequestStack $requestStack, Messenger $messenger) {
    $this->connection = $connection;
    $this->requestStack = $requestStack;
    $this->messenger = $messenger;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database'),
      $container->get('request_stack'),
      $container->get('messenger')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'add_edit_metatag';

  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $id = NULL) {
    global $base_url;
    if (!empty($id)) {
      $query                   = $this->connection->select('custom_meta_tags', 'tags')->fields('tags', [
        'meta_url',
        'meta_title',
        'meta_keyword',
        'meta_desc',
        'hindi_meta_title',
        'hindi_meta_keyword',
        'hindi_meta_desc',
      ])->condition('meta_id', $id, '=');
      $meta_data               = $query->execute()->fetchObject();
      $this_meta_url           = $meta_data->meta_url;
      $this_meta_title         = $meta_data->meta_title;
      $this_meta_keyword       = $meta_data->meta_keyword;
      $this_meta_desc          = $meta_data->meta_desc;
      $this_hindi_meta_title   = $meta_data->hindi_meta_title;
      $this_hindi_meta_keyword = $meta_data->hindi_meta_keyword;
      $this_hindi_meta_desc    = $meta_data->hindi_meta_desc;
    }
    else {
      $meta_data               = '';
      $this_meta_url           = '';
      $this_meta_title         = '';
      $this_meta_keyword       = '';
      $this_meta_desc          = '';
      $this_hindi_meta_title   = '';
      $this_hindi_meta_keyword = '';
      $this_hindi_meta_desc    = '';
    }

    $form['meta_url'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Meta Url') . ' ' . $base_url,
      '#placeholder'   => $this->t('Enter meta url'),
      '#required'      => TRUE,
      '#description'   => $this->t('Please enter only url without domain name with "/"'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_meta_url !== NULL) ? $this_meta_url : '',
    ];

    $form['meta_title'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Meta Title'),
      '#placeholder'   => $this->t('Enter meta title'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_meta_title !== NULL) ? $this_meta_title : '',
    ];

    $form['meta_desc'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Meta Description'),
      '#placeholder'   => $this->t('Enter meta description'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_meta_desc !== NULL) ? $this_meta_desc : '',
    ];

    $form['meta_keyword'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Meta Keyword'),
      '#placeholder'   => $this->t('Enter meta keyword'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_meta_keyword !== NULL) ? $this_meta_keyword : '',
    ];

    $form['hindi_meta_title'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Hindi Meta Title'),
      '#placeholder'   => $this->t('Enter hindi meta title'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_hindi_meta_title !== NULL) ? $this_hindi_meta_title : '',
    ];

    $form['hindi_meta_desc'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Hindi Meta Description'),
      '#placeholder'   => $this->t('Enter hindi meta description'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_hindi_meta_desc !== NULL) ? $this_hindi_meta_desc : '',
    ];

    $form['hindi_meta_keyword'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Hindi Meta Keyword'),
      '#placeholder'   => $this->t('Enter hindi meta keyword'),
      '#attributes'    => ['autocomplete' => 'off'],
      '#default_value' => ($this_hindi_meta_keyword !== NULL) ? $this_hindi_meta_keyword : '',
    ];

    $form['submit'] = [
      '#type'  => 'submit',
      '#value' => $this->t('Save Metatag'),
    ];

    return $form;

  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $meta_url = $form_state->getValue('meta_url');
    $database = $this->connection;
    $id       = $this->requestStack->getCurrentRequest()->get('id');

    if (!empty($id)) {
      $exists = $database->select('custom_meta_tags', 'c')->condition('c.meta_url', $meta_url, '=')->condition('c.meta_id', $id, '=')->fields('c', ['meta_id'])->execute()->fetchField();
      if (empty($exists)) {
        $count = $database->select('custom_meta_tags', 'c')->condition('c.meta_url', $meta_url, '=')->fields('c', ['meta_id'])->execute()->fetchField();
      }
    }
    else {
      $count = $database->select('custom_meta_tags', 'c')->condition('c.meta_url', $meta_url, '=')->fields('c', ['meta_id'])->execute()->fetchField();
    }

    if (!empty($count)) {
      $form_state->setErrorByName('meta_url', $this->t('This meta url is aleardy set in database.'));
    }

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $meta_url           = $form_state->getValue('meta_url');
    $meta_title         = $form_state->getValue('meta_title');
    $meta_keyword       = $form_state->getValue('meta_keyword');
    $meta_desc          = $form_state->getValue('meta_desc');
    $hindi_meta_title   = $form_state->getValue('hindi_meta_title');
    $hindi_meta_keyword = $form_state->getValue('hindi_meta_keyword');
    $hindi_meta_desc    = $form_state->getValue('hindi_meta_desc');
    $id                 = $this->requestStack->getCurrentRequest()->get('id');

    if (!empty($id)) {
      $this->connection->update('custom_meta_tags')->fields(
            [
              'meta_url'           => $meta_url,
              'meta_title'         => $meta_title,
              'meta_keyword'       => $meta_keyword,
              'meta_desc'          => $meta_desc,
              'hindi_meta_title'   => $hindi_meta_title,
              'hindi_meta_keyword' => $hindi_meta_keyword,
              'hindi_meta_desc'    => $hindi_meta_desc,
            ]
        )->condition('meta_id', $id, '=')->execute();

      $action = 'updated';
    }
    else {
      $this->connection->insert('custom_meta_tags')->fields(
            [
              'meta_url'           => $meta_url,
              'meta_title'         => $meta_title,
              'meta_keyword'       => $meta_keyword,
              'meta_desc'          => $meta_desc,
              'hindi_meta_title'   => $hindi_meta_title,
              'hindi_meta_keyword' => $hindi_meta_keyword,
              'hindi_meta_desc'    => $hindi_meta_desc,
            ]
            )->execute();

      $action = 'added';
    }

    $this->messenger->addStatus($this->t('Meta tag @action successfully!', ['@action' => $action]));

    $form_state->setRedirect('custom_meta.settings');

  }

}
