/**
 * @file
 * Handles ga_graph data.
 */

(function ($, Drupal, drupalSettings) {
    // 'use strict';
    /**
     * Attaches the AJAX behavior to fetch pre records and filters.
     *
     * @type {Drupal~behavior}
     *
     * @prop {Drupal~behaviorAttach} attach
     *   Attaches ajax functionality to relevant elements.
     */
    Drupal.behaviors.ga_graph = {
        attach: function (context, settings) {

            var gaCounterDataVal = JSON.parse(drupalSettings.gaCounterData);
            var area = Morris.Area({
             element: "revenue-chart",
             resize: true,
             data: gaCounterDataVal,
             xkey: "today_date",
             ykeys: ["mc", "rc", "eac"],
             labels: ["Meal Counter", "Recipe Counter", "Expert Advice Counter"],
             lineColors: ["#f56954", "#f39c12", "#3c8dbc"],
             xLabels: "day",
             xLabelAngle: 45,
             yLabelFormat: function (y) {return y = Math.round(y);},
             hideHover: "auto"
             });
        }
    }
})(jQuery, Drupal, drupalSettings);
