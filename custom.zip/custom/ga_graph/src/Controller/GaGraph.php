<?php

namespace Drupal\ga_graph\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Show all Google Analytics Counter Graph.
 *
 * @internal
 */
class GaGraph extends ControllerBase {

  /**
   * {@inheritdoc}
   */
  public function graphData() {
    global $base_url;
    $database = \Drupal::database();
    $this_month = date("m");
    $this_year = date("Y");
    $days_in_this_month = cal_days_in_month(CAL_GREGORIAN, $this_month, $this_year);

    for ($i = 1; $i <= $days_in_this_month; $i++) {
      if ($i < 10) {
        $this_day = "0" . $i;
      }
      else {
        $this_day = $i;
      }
      $this_date = $this_year . '-' . $this_month . '-' . $this_day;
      $start_timestamp = strtotime(date($this_date . " 00:00:01"));
      $end_timestamp = strtotime(date($this_date . " 23:59:59"));

      $select_meal_counter = $database->select('ga_counters', 'g')
        ->condition('g.ga_datetime', $start_timestamp, '>=')
        ->condition('g.ga_datetime', $end_timestamp, '<=')
        ->condition('g.ga_type', 'meal_detail', '=')
        ->fields('g', ['ga_id'])
        ->execute()->fetchAll();

      $select_recipe_counter = $database->select('ga_counters', 'g')
        ->condition('g.ga_datetime', $start_timestamp, '>=')
        ->condition('g.ga_datetime', $end_timestamp, '<=')
        ->condition('g.ga_type', 'recipe_detail', '=')
        ->fields('g', ['ga_id'])
        ->execute()->fetchAll();

      $select_advice_counter = $database->select('ga_counters', 'g')
        ->condition('g.ga_datetime', $start_timestamp, '>=')
        ->condition('g.ga_datetime', $end_timestamp, '<=')
        ->condition('g.ga_type', 'expert_advice', '=')
        ->fields('g', ['ga_id'])
        ->execute()->fetchAll();

      $counter_Arr[] = [
        "today_date" => trim($this_date),
        "mc" => trim(count($select_meal_counter)),
        "rc" => trim(count($select_recipe_counter)),
        "eac" => count($select_advice_counter),
      ];
    }

    $counter_Arr = json_encode($counter_Arr);

    $graph_data = '<div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-body chart-responsive">
              <div class="chart" id="revenue-chart" style="height: 400px;"></div>
            </div>
          </div>
        </div>
      </div>';
    return [
      '#theme' => 'GAGraph',
      '#graph_data' => $graph_data,
      '#attached' => [
        'library' => 'ga_graph/ga_graph_style',
        'drupalSettings' => [
          'gaCounterData' => $counter_Arr,
        ],
      ],
    ];
  }

}
