<?php

namespace Drupal\nestle_common\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\file\Entity\File;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\Response;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\comment\Entity\Comment;
use Drupal\Core\Language\LanguageManager;
use Drupal\Component\Utility\Xss;
use Drupal\taxonomy\Entity\Term;

/**
 * It is used for global Search functionality in Nestle project.
 */
class SearchControl extends ControllerBase {

	/**
	* Global Search Function
	*/
	public function globalSearch(Request $request) {
	global $base_url;
	$recipes = array();
	$article = array();
	$community = array();
	$langCode = CommonFunc::multilingualConvert("lang");
	\Drupal::service('page_cache_kill_switch')->trigger();
	$hindiLang = CommonFunc::isHindi();
	$search['hindiLng'] = $hindiLang;
	if($hindiLang){
		$lang = 'hi';
	}else{
		$lang = 'en';
	}	
	/*
	   Serach data list :recipe, coomunity, article 
	   query get : searchData,recipe,article,community
	   if searchData: serach in , (recipe,community, article)
	   if recipe: serach in , (recipe)
	   if community: search in , (community)
	   if article: search in , (article)
	*/
	if(strip_tags($request->query->get('recipe')) !='') {
		$keyword = strip_tags($request->query->get('recipe'));
		$keyword = Xss::filter($keyword, []);
		$search['query_key'] = 'recipe';
	} else if(strip_tags($request->query->get('article')) !='') {
		$keyword = strip_tags($request->query->get('article'));
		$keyword = Xss::filter($keyword, []);
		$search['query_key'] = 'article';
	} else if(strip_tags($request->query->get('community')) !='') {
		$keyword = strip_tags($request->query->get('community'));
		$keyword = Xss::filter($keyword, []);
		$search['query_key'] = 'community';
	} else if(strip_tags($request->query->get('searchData')) !='') {
		$keyword = strip_tags($request->query->get('searchData'));
		$keyword = Xss::filter($keyword, []);
		$search['query_key'] = 'searchData';
	} else {
		$keyword ='';
		$search['query_key'] = '';
	}
	if(strip_tags($request->query->get('recipe')) !='' || strip_tags($request->query->get('searchData')) !='') {
		
		$pageNo = 1;
		if (trim($langCode) === "hi") {
			$post_data = ['q' => trim($keyword), 'page' => $pageNo, 'lang' => "hi"];
			
		} else {
			$post_data = ['q' => trim($keyword), 'page' => $pageNo];
		}
		$r_data = NestleAPI::recipesData($post_data);
		$recipes = $r_data['contents']['recipe_list'];
		
		foreach ($recipes as $key => $value) {
			
			$recipes[$key]['recipeMetadata'] = CommonFunc::getRecipeMetaDataBySeoName($value['seo_name'])['recipeMetadata'];
			
			$recipes[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value['seo_name'], $lang);
			$recipes[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value['seo_name'], $lang);
			$recipes[$key]['url_redirect'] = CommonFunc::encryptData($value['seo_name'].'|recipes|card|'.$lang.'|fav');
		}
		$search['recipeSearchCount'] = $r_data['contents']['count'];
	}
	
	if(strip_tags($request->query->get('article')) !='' || strip_tags($request->query->get('searchData')) !='') {
		$pageNo = 1;
		$pagerRow = $pageNo*12-12;
		$ea_query = \Drupal::entityQuery('node')
        ->range($pagerRow, 12)
        ->condition('status', 1)
        ->condition('type', 'expert_advice', '=');
		// OR Condition
		$ea_group = $ea_query->orConditionGroup()
		->condition('title', $keyword, 'CONTAINS')
		->condition('body', $keyword, 'CONTAINS');

		$ea_nids = $ea_query->condition($ea_group)->sort('created', 'DESC')->execute();
		
		$ea_nodes = Node::loadMultiple($ea_nids);
		$search['countArticlePage'] = count($ea_nids);
		foreach ($ea_nodes as $node) {
		
			$node = $node->getTranslation($langCode);
			$nid = $node->get('nid')->value;
			if($node->field_thum_image){
			 if($node->field_thum_image->getValue()) {
				$file_image =File::load($node->field_thum_image->getValue()[0]['target_id']);
				$original_image = $file_image->getFileUri();
				$image_path = file_url_transform_relative(file_create_url($original_image));
				$style = \Drupal::entityTypeManager()->getStorage('image_style')->load('webp');
				$article1['thumb'] = file_create_url($style->buildUri($original_image));
				$article1['original'] = $image_path;
			 } else {
				$article1['thumb'] = '';
				$article1['original'] =''; 
			 }
			} else {
				$article1['thumb'] = '';
				$article1['original'] ='';
			}
			$date = $node->get('created')->value;
			$article1['created_date'] = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
			$article1['read_time'] = $node->get('field_read_time')->value;
			$article1['author'] = $node->get('field_author')->value;
			$term = Term::load($node->get('field_category')->target_id);
			$article1['tag'] = $term->getName();
			$article1['title'] = $node->getTitle();
			$alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
			$article1['node_url'] = $alias_url;
			$article[] = $article1;
		}
	}
	
	
	if(strip_tags($request->query->get('community')) !='' || strip_tags($request->query->get('searchData')) !='') {
		$pageNo = 1;
		$pagerRow = $pageNo*12-12;
		$cm_query = \Drupal::entityQuery('node')
        ->range($pagerRow, 12)
        ->condition('status', 1)
        ->condition('type', 'community', '=');
		// OR Condition
		$cm_group = $cm_query->orConditionGroup()
		->condition('body', $keyword, 'CONTAINS');

		$cm_nids = $cm_query->condition($cm_group)->sort('created', 'DESC')->execute();
	
		$cm_nodes = Node::loadMultiple($cm_nids);
		$search['countcommunityPage'] = count($cm_nids);
		foreach ($cm_nodes as $node) {
		
			$nid = $node->get('nid')->value;
			$uid = $node->getOwnerId();
			$comm['uid'] = $uid;
			$date = $node->get('created')->value;
			$comm['created_date'] = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
			$comm['author'] = '';
			$comm['body'] = strip_tags($node->get('body')->value);
			$alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
			$comm['node_url'] = $alias_url;
			$likeDislike = CommonFunc::checklikeDislike($nid);
			if(!empty($likeDislike)) {
				$comm['likeDLike']= $likeDislike[0]->like_num;
			} else {
				$comm['likeDLike']= 0;
			}
            $comm['current_user'] = CommonFunc::userId();			
			$comm['total_comment'] = CommonFunc::countComment($nid);
			$comm['u_name'] = CommonFunc::getUserValue('field_first_name', $uid);
			/* author image
			*/
			$user = User::load($uid);
			if(!empty($user->user_picture->getValue())){
				$fid =  $user->user_picture->getValue()[0]['target_id'];
			}

			if(!empty($fid)){
				$file_image =File::load($user->user_picture->getValue()[0]['target_id']);
				$original_image = $file_image->getFileUri();
				$image_path = file_url_transform_relative(file_create_url($original_image));
			}else{
				$image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
			}
			$comm['image'] = $image_path;
			$like_dislike = CommonFunc::checklikeDislike($nid);
			if ($like_dislike != '') {
			if (array_key_exists(0, $like_dislike) && $like_dislike[0]->like_num == 1) {
			$comm['like'] = $like_dislike[0]->like_num;
			}
			}
			$community[] = $comm;
		}
	}
	
	$search['keyword'] = $keyword;
	return [
            '#theme' => 'GlobalSearchPage',
            '#recipes' => $recipes,
			'#article' => $article,
			'#community' => $community,
			'#search' => $search,
        ];

	}
	
	/**
	* Global Search  Load more Function
	*/
	public function RecipeLoadMore(Request $request) {
		global $base_url;
		$logged_in = \Drupal::currentUser()->isAuthenticated();
		$hindi = CommonFunc::isHindi();
		if($hindi){
			$lang = 'hi';
		}else{
			$lang = 'en';
		}
		$langCode = CommonFunc::multilingualConvert("lang");
		\Drupal::service('page_cache_kill_switch')->trigger();
		$searchData = strip_tags($request->query->get('searchData'));
		$pageNo = strip_tags($request->query->get('pageNo'));
		if (trim($langCode) === "hi") {
			$post_data = ['q' => trim($searchData), 'page' => $pageNo, 'lang' => "hi"];
		     $shorturl ="/hindi";
		} else {
			$post_data = ['q' => trim($searchData), 'page' => $pageNo];
			$shorturl ="";
		}
		$r_data = NestleAPI::recipesData($post_data);

		
		$html= '';
		if($r_data['status'] == 'success') {
			$list = $r_data['contents']['recipe_list'];
			foreach($list as $recipes) {
				$recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($recipes['seo_name']);
				$recipes = $recipeMetaData;
				$recipes['fav'] = CommonFunc::getRecipeFavlikeDislike($recipes['seo_name'], $lang);
				$recipes['gRating'] = CommonFunc::getRecipeRatingBySeo($recipes['seo_name'], $lang);
				$recipes['url_redirect'] = CommonFunc::encryptData($recipes['seo_name'].'|recipes|card|'.$lang.'|fav');
				if($recipes['fav']=='like'){
					$likeClass = '';
					$likeAttr = 'like';
				}else{
					$likeClass = 'active-like';
					$likeAttr = 'dislike';
				}
				if($recipes['gRating'] != 0.0){
					$rate = '<div class="rvw"><em></em>'.$recipes['gRating'].'</div>';
				}else{
					$rate = '<div class="rvw"><em></em>'.t('No rate').'</div>';
				}


				$html .= ' <div class="item">
                    <div class="cardscmn2">
					
                      <div class="imgWrp">
					   <a href="'.$base_url.$shorturl.'/recipes/'.$recipes['seo_name'].'">
					   <img src="'.$recipes['round_images'].'" alt="'.$recipes['name'].'" width="1" height="1">
					   </div>
                      <div class="txtb">
					    <a href="'.$base_url.$shorturl.'/recipes/'.$recipes['seo_name'].'">
                        <h3>'.$recipes['name'].'</h3>
						</a>
                        <p>'.$recipes['trivia'].'</p>
                        <ul class="list1">
                          <li><em><img src="themes/custom/nestle_new/common/images/icon-fire.svg" alt="calories" width="1" height="1"></em> '.$recipes['calories'].' calories</li>
                          <li><em><img src="themes/custom/nestle_new/common/images/icon-time.svg" alt="mins" width="1" height="1"></em> '.$recipes['time_to_cook'].' mins</li>
                        </ul>
						
					  </div>
                      <div class="crdsFtr">
                        <div class="vn-tag-rvw">
                          <div class="veg-nveg-mark"><i class="veg-icon"></i></div>
                          '.$rate.'
                        </div>';
                       if($logged_in){
                        	$html .= '<div class="like '.$likeClass.' favBtn" id="favBtn" data-fav="'.$likeAttr.'" data-recipeid="'.$recipes['id'].'" data-recipeseoname="'.$recipes['seo_name'].'" data-recipeseoalternatename="'.$recipes['seo_name_alternate'].'" data-value="'.$recipes['seo_name'].'" data-hindiname = "'.$recipes['recipeMetadata']['hindi_name'].'" data-engname = "'.$recipes['recipeMetadata']['eng_name'].'" data-target="card"></div>';
                        }
                        else{
                        	$html .= '<a href="'.$base_url.$shorturl.'/user/login?destination='.$recipes['url_redirect'].'"><div class="like"></div></a>';
                        }
                     $html .= '   
                      </div>
                    </div>
                </div>';
			}
		} 
		return new JsonResponse($html);
	}
	
	/**
	* Global Search Function exper load more
	*/
	public function ExpertSearchLoadMore(Request $request) {
		
		global $base_url;
        \Drupal::service('page_cache_kill_switch')->trigger();
		$keyword = $request->query->get('searchData');

		$pageNo = $request->query->get('pageNo');

		$keyword = Xss::filter($keyword, []);
		$langCode = CommonFunc::multilingualConvert("lang");

		$hindiLang = CommonFunc::isHindi();
        
		if($hindiLang){

		$recordExit = "कोई रिकॉर्ड नहीं मिला";
		}else{

		$recordExit = "No Record Found";
		}
		$pagerRow = $pageNo*12-12;
		$html = '';
		if ($keyword != '') {
			
			$ea_query = \Drupal::entityQuery('node')
			->range($pagerRow, 12)
			->condition('status', 1)
			->condition('type', 'expert_advice', '=');

			// OR Condition
			$ea_group = $ea_query->orConditionGroup()
			->condition('title', $keyword, 'CONTAINS')
			->condition('body', $keyword, 'CONTAINS');

			$ea_nids = $ea_query->condition($ea_group)->sort('created', 'DESC')->execute();
			
			$ea_nodes = Node::loadMultiple($ea_nids);
			
			foreach ($ea_nodes as $node) {
				
				$node = $node->getTranslation($langCode);
				$nid = $node->get('nid')->value;
				if($node->field_thum_image){
                if($node->field_thum_image->getValue()) {
				$file_image =File::load($node->field_thum_image->getValue()[0]['target_id']);
				
					$original_image = $file_image->getFileUri();

					$image_path = file_url_transform_relative(file_create_url($original_image));
					$style = \Drupal::entityTypeManager()->getStorage('image_style')->load('webp');
					$thumb = file_create_url($style->buildUri($original_image));
					$original = $image_path;
				} else {
					$thumb = '';
				    $original ='';
				}
				
				} else {
				$thumb = '';
				$original ='';
				}
				$date = $node->get('created')->value;
				$created_date = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
				$read_time = $node->get('field_read_time')->value;
				$title = $node->getTitle();
				
				$author = $node->get('field_author')->value;
				
				$term = Term::load($node->get('field_category')->target_id);
				if($term !='') {
					$tag = $term->getName();
				} else {
					$tag ='';
				}
				
				
				$alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
				
				$html .= '<div class="grid-item">
                    <div class="thumBox">
                      <div class="thumBoxinr">
                        <div class="thumCont"> <a href="#" class="bookmark"><span></span></a>
                          <div class="thumImg"><a href="'.$alias_url.'"><img src="'.$thumb.'" alt="'.$title .'"></a></div>
                          <div class="thumText">
                            <div class="meal-read">
                              <div class="meal-type">'.$tag.'</div>
                              <div class="time-read">'.$read_time.' min read</div>
                            </div>
                            <p><a href="'.$alias_url.'">'.$title.'</a></p>
                            <div class="bytext">By '.$author.'</div>
								
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>';
				
				
			}
			
			
			
		}
	    return new JsonResponse($html);
	}
	
	/**
	* Global Search Function Community load more
	*/
	public function CommunitySearchLoadMore(Request $request) {
		
		global $base_url;
        \Drupal::service('page_cache_kill_switch')->trigger();
		$keyword = $request->query->get('searchData');

		$pageNo = $request->query->get('pageNo');

		$keyword = Xss::filter($keyword, []);
		$langCode = CommonFunc::multilingualConvert("lang");

		$hindiLang = CommonFunc::isHindi();
        
		if($hindiLang){

		$recordExit = "कोई रिकॉर्ड नहीं मिला";
		}else{

		$recordExit = "No Record Found";
		}
		$pagerRow = $pageNo*12-12;
		$html = '';
		if ($keyword != '') {
			$cm_query = \Drupal::entityQuery('node')
			->range($pagerRow, 12)
			->condition('status', 1)
			->condition('type', 'community', '=');
			// OR Condition
			$cm_group = $cm_query->orConditionGroup()
			->condition('body', $keyword, 'CONTAINS');

			$cm_nids = $cm_query->condition($cm_group)->sort('created', 'DESC')->execute();

			$cm_nodes = Node::loadMultiple($cm_nids);
			
			foreach ($cm_nodes as $node) {

				$node = $node->getTranslation($langCode);
				$nid = $node->get('nid')->value;
				$uid = $node->getOwnerId();
				$uid = $uid;
				$date = $node->get('created')->value;
				$created_date = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
				$author = '';
				$body = strip_tags($node->get('body')->value);
				$alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
				$node_url = $alias_url;
				$likeDislike = CommonFunc::checklikeDislike($nid);
				if(!empty($likeDislike)) {
					$comm['likeDLike']= $likeDislike[0]->like_num;
				} else {
					$comm['likeDLike']= 0;
				}
				$current_user = CommonFunc::userId();			
				$total_comment = CommonFunc::countComment($nid);
				$u_name = CommonFunc::getUserValue('field_first_name', $uid);
				/* author image
				*/
				$user = User::load($uid);
				if(!empty($user->user_picture->getValue())){
					$fid =  $user->user_picture->getValue()[0]['target_id'];
				}

				if(!empty($fid)){
					$file_image =File::load($user->user_picture->getValue()[0]['target_id']);
					$original_image = $file_image->getFileUri();
					$image_path = file_url_transform_relative(file_create_url($original_image));
				}else{
					$image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
				}
				$image = $image_path;
				$like_dislike = CommonFunc::checklikeDislike($nid);
				if ($like_dislike != '') {
					if (array_key_exists(0, $like_dislike) && $like_dislike[0]->like_num == 1) {
						$like = $like_dislike[0]->like_num;
					}
				}
				$html .= '<div class="item-comment">
                    <div class="comment-name-date">
                      <div class="comment-name"><span><img src="'.$image.'" alt="'.$u_name.'"></span>'.$u_name.'</div>
                      <div class="comment-date">'.$created_date.'</div>
                    </div>
                    
                    <p> '.$body.'</p>
                    <div class="like-msg-btn"> <a href="'.$node_url.'" class="go-convrstn">Go to conversation</a>
                      <div class="like-msg"> <a href="#"><i class="thumup-icon"></i></a> <a href="#"><i class="msg-icon"></i>'.$total_comment.'+ </a> </div>
                    </div>
                </div>';
				
			}
			
		}
		return new JsonResponse($html);
		
		
		
	}

}
