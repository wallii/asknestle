<?php

namespace Drupal\nestle_common\Controller;



use Drupal\Core\Url;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Controller\ControllerBase;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\file\Entity\File;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\field\Entity\FieldConfig;
use Drupal\Core\Language\LanguageManager;
use Google_Client;
use Google_Service_AnalyticsReporting;
use Google_Service_AnalyticsReporting_DateRange;
use Google_Service_AnalyticsReporting_Metric;
use Google_Service_AnalyticsReporting_Dimension;
use Google_Service_AnalyticsReporting_OrderBy;
use Google_Service_AnalyticsReporting_ReportRequest;
use Google_Service_AnalyticsReporting_DimensionFilter;
use Google_Service_AnalyticsReporting_DimensionFilterClause;
use Google_Service_AnalyticsReporting_GetReportsRequest;
use Drupal\config_pages\Entity\ConfigPages;
use Drupal\media\Entity\Media;
use Drupal\nestle_api\Controller\NestleAPI;


/**
 * This class have all common functions which are using in the CMS.
 */
class CommonFunc extends ControllerBase {

  /**
   * GA Calculations.
   */
  public static function countGaHomepage($type) {
    $database = \Drupal::database();
    $moduleHandler = \Drupal::service('module_handler');
    if ($moduleHandler->moduleExists('ga_graph')) {
      $today_start_date = strtotime(date("2020-04-22 00:00:01"));
      $old_counter = 0;
      // Get Real Data form Table
      if (\Drupal::database()->schema()->tableExists('rtga_counters')){
        $select_rtga = $database->select('rtga_counters', 'r')
          ->fields('r')
          ->condition('r.rtga_id', '1', '=')
          ->execute()->fetchObject();
      }
      else {
        $select_rtga = [
          'rtga_pv' => 7088712,
          'rtga_mpg' => 334835,
          'rtga_ear' => 257257,
        ];
        $select_rtga = (object)$select_rtga;

      }
      // Date is fixed according to client@Tanmay requirement
      if ($type == "hf") {
        // Parent Visited
        $old_counter = $select_rtga->rtga_pv;
        $select = $database->select('ga_counters', 'g')
          ->fields('g', ['ga_id'])
          ->condition('g.ga_datetime', $today_start_date, '>=')
          ->execute()->fetchAll();
      }
      elseif ($type == "cmp") {
        // Meal Plans Generated
        $old_counter = $select_rtga->rtga_mpg;
        $select = $database->select('ga_counters', 'g')
          ->condition('g.ga_type', 'meal_detail', '=')
          ->condition('g.ga_datetime', $today_start_date, '>=')
          ->fields('g', ['ga_id'])
          ->execute()->fetchAll();
      }
      elseif ($type == "hr") {
        $old_counter = 0;
        $select = $database->select('ga_counters', 'g')
          ->condition('g.ga_type', 'recipe_detail', '=')
          ->condition('g.ga_datetime', $today_start_date, '>=')
          ->fields('g', ['ga_id'])
          ->execute()->fetchAll();
      }
      elseif ($type == "expAd") {
        // Expert Articles Read
        $old_counter = $select_rtga->rtga_ear;
        $select = $database->select('ga_counters', 'g')
          ->condition('g.ga_type', 'expert_advice', '=')
          ->condition('g.ga_datetime', $today_start_date, '>=')
          ->fields('g', ['ga_id'])
          ->execute()->fetchAll();
      }
      else {
        $select = [];
      }
    }
    else {
      $select = [];
    }
    $total_counter = $old_counter + count($select);
    $counter = self::thousandsCurrencyFormat($old_counter);
    return $counter;
  }
  /**
   * GA Count round thousand to a K style count.
   */
  public static function thousandsCurrencyFormat($num) {
    $hindi = self::isHindi();
    if ($num > 1000) {
      $x = round($num);
      $x_number_format = number_format($x);
      $x_array = explode(',', $x_number_format);
      if ($hindi) {
        $x_parts = [' हजार', ' मिलियन', ' बिलियन', ' खरब'];
      }
      else {
        $x_parts = ['K', 'M', 'B', 'T'];
      }
      $x_count_parts = count($x_array) - 1;
      $x_display = $x_array[0] . ((int) $x_array[1][0] !== 0 ? '.' . $x_array[1][0] : '');
      $x_display .= $x_parts[$x_count_parts - 1];
      return $x_display;
    }
    return $num;
  }
  /** Language identifier */
  public static function isHindi() {
    /** Hindi Version Condition */
    $lang_code = self::multilingualConvert("lang");
    if ($lang_code == 'hi') {
      $hindi = TRUE;
    }
    else {
      $hindi = FALSE;
    }
    return $hindi;
  }
  
  /** User identifier */
  public static function isRegisterUser() {
	if (\Drupal::currentUser()->isAuthenticated()) {
	$register = TRUE;
	} else {
	$register = FALSE;
	}
    return $register;
  }
  /**
   * Multilingual conversion functions(node,entity)
   */
  public static function multilingualConvert($langcode=null, $entity=null){
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    if($langcode == "lang"){
      return $lang_code;
    }elseif ($langcode == "entity") {
      if(!empty($entity)){
        $term = \Drupal::service('entity.repository')->getTranslationFromContext($entity, $lang_code);
        return $term;
      }
    }
  }
  
   /** Language API Coversion */
   public static function APiHindi($postArr) {
    /** Hindi Version Condition */
   $lang_code = self::multilingualConvert("lang");

    if ($lang_code == 'hi') {
      $hindiArr = array("lang"=>"hi");
      $hindiArr  = array_merge($postArr, $hindiArr);
    }
    else {
      $hindiArr = $postArr;
    }

    return $hindiArr;
  }
  
   /**
   * Redirect current page to the provided url.
   */
   public static function redirectPage($path) {
    $response = new RedirectResponse($path);
    $response->send();
    exit;
  }
  
  /**
   * GA Counter Insertion.
   */
  public static function insertGa($ga_node, $ga_type) {
    $user_id = self::userId();
    $ga_userid = $user_id ? $user_id : 0;
    $ga_ip = \Drupal::request()->getClientIp();

    if ($ga_node != '') {
      $database = \Drupal::database();
      $moduleHandler = \Drupal::service('module_handler');
      if ($moduleHandler->moduleExists('ga_graph')) {
        $select = $database->select('ga_counters', 'g')
          ->condition('g.ga_node', $ga_node, '=')
          ->condition('g.ga_ip', $ga_ip, '=')
          ->fields('g', ['ga_id'])
          ->range(0, 1)
          ->execute()->fetchObject();

        if (isset($select->ga_id) && $select->ga_id == '') {
          $result = $database->insert('ga_counters')
            ->fields([
              'ga_node' => $ga_node,
              'ga_ip' => $ga_ip,
              'ga_type' => $ga_type,
              'ga_userid' => $ga_userid,
              'ga_datetime' => \Drupal::time()->getRequestTime(),
            ])
            ->execute();
        }
      }
    }

    return TRUE;
  }

  

  /**
   * GA Calculate Counts.
   */
  public static function countGa($ga_node, $ga_type) {
    $database = \Drupal::database();
    $moduleHandler = \Drupal::service('module_handler');
    if ($moduleHandler->moduleExists('ga_graph')) {
      if ($ga_type == "expert_advice") {
        $select = $database->select('ga_counters', 'g')
          ->condition('g.ga_node', $ga_node, '=')
          ->condition('g.ga_type', 'expert_advice', '=')
          ->fields('g', ['ga_id'])
          ->execute()->fetchAll();
      }
      else {
        $select = $database->select('ga_counters', 'g')
          ->condition('g.ga_node', $ga_node, '=')
          ->condition('g.ga_type', 'expert_advice', '!=')
          ->fields('g', ['ga_id'])
          ->execute()->fetchAll();
      }
    }
    else {
      $select = [];
    }

    $counter = self::thousandsCurrencyFormat(count($select));
    return $counter;
  }
  
  /**
   * Get user Id.
   */
  public static function userId() {
    return \Drupal::currentUser()->id();
  }
  /**
   * Use to show count of like or dislike.
  */
  public static function likeDislikeCount($cid) {
    // TODO: Drupal Rector Notice: Please delete the following comment after you've made any necessary changes.
    // You will need to use `\Drupal\core\Database\Database::getConnection()` if you do not yet have access to the container here.
    $query = \Drupal::database()->select('community_like_dislike');
    $query->addExpression('sum(like_num)', 'likes');
    $query->addExpression('sum(dislike_num)', 'dislikes');
    $query->condition('community_id', $cid, '=');
    $result = $query->execute()->fetchAssoc();
    return $result;
  }
  /**
   * Use to check of like or dislike.
   */
  public static function checklikeDislike($cid) {
    $user_id = self::userId();

    $database = \Drupal::database();
    $select = $database->select('community_like_dislike', 'c')
      ->condition('c.user_id', $user_id, '=')
      ->condition('c.community_id', $cid, '=')
      ->fields('c', ['like_num', 'dislike_num'])
      ->execute()->fetchAll();
    return $select;
  }
   /**
   * Use to make short description.
   */
  public static function summary($str, $limit, $strip = FALSE) {
    $str = ($strip == TRUE) ? strip_tags($str) : $str;
    if (strlen($str) > $limit) {
      $str = substr($str, 0, $limit - 3);
      return (substr($str, 0, strrpos($str, ' ')) . '...');
    }
    return trim($str);
  }
  /**
   * Count comment .
   */
  public static function countComment($id) {
    $database = \Drupal::database();
    $count = $database->select('comment_entity_statistics', 'c')
      ->condition('c.entity_id', $id, '=')
      ->fields('c', ['comment_count'])
      ->execute()->fetchField();
    return $count;
  }
  /**
   * Getting user logged value.
   */
  public static function getUserValue($field, $uid) {
    $user = User::load($uid);

    if ($field == 'field_first_name') {
      $result = $user->$field->value;
      if ($result == '') {
        $result = $user->get('name')->value;
      }
      else {
        $result = $user->$field->value;
      }
    }
    else {
      $result = isset($user->$field->value)?$user->$field->value:'';
    }
    return $result;
  }
  /**
   * Time calculation.
   */
  public static function calculateTimeAgo($time) {
    return \Drupal::service('date.formatter')->formatTimeDiffSince($time);
  }
  
  /**
   * Get nutrition tags with it's ids.
   */
  public static function nutritionTags() {
    $nutritions = [
      29 => 'Protein',
      30 => 'Total Fat',
      33 => 'Carbohydrate',
      35 => 'Calcium',
      37 => 'Iron (Fe)',
      45 => 'Vitamin C',
      62 => 'Vitamin B12',
      114 => 'Vitamin A',
    ];

    return $nutritions;
  }
  /**
   * use to get the config page field value
   */
  public static function getConfigPageFieldValue($config_page, $field_id) {
    $loadConfigPage = ConfigPages::config($config_page);
    $fieldValue = $loadConfigPage->get($field_id)->value;
    return $fieldValue;
  }
   /**
   * use to get the config page link field value
   */
  public static function getConfigPageLinkFieldValue($config_page, $field_id) {
    $linkfieldValue = array();
    $loadConfigPage = ConfigPages::config($config_page);
    $fieldValuRaw = $loadConfigPage->get($field_id);
    $linkfieldValue['title'] = $fieldValuRaw->getValue()[0]['title'];
    $linkfieldValue['uri'] = Url::fromUri($fieldValuRaw->getValue()[0]['uri'])->toString();
    return $linkfieldValue;
  }
  /**
   * use to get the config page image field value
   */
  public static function getConfigPageImageFieldValue($config_page, $field_id) {
    $loadConfigPage = ConfigPages::config($config_page);
    $fieldValuRaw = $loadConfigPage->get($field_id);
    $mid = $fieldValuRaw->getValue()[0]['target_id'];
    $imageMedia = Media::load($mid);
    $imageMediaTargetID = $imageMedia->get('field_media_image')->target_id;
    $file = File::load($imageMediaTargetID);
    $original_image = $file->getFileUri();
    $image_path = file_url_transform_relative(file_create_url($original_image));
    $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('webp');
    $image_url = file_create_url($style->buildUri($original_image));
    return $image_url;
  }
   /*
   * Calculate meal nutrient values.
   */
  public static function mealNutrient($meal_rda, $meal_nutrients, $consumed_nutrients){

    $hindi = self::isHindi();
    $consumedset = [];
    $i = 0;
    $mealNutrient = '';
    foreach ($meal_nutrients as $key => $meal_nutrient) {
      if (array_key_exists($meal_nutrient['id'], $consumed_nutrients)) {
        $nutrient['id'] = $meal_nutrient['id'];
        $nutrient['rda'] = $meal_rda[$meal_nutrient['id']];
        $nutrient['name'] = $meal_nutrient['name'];
        $nutrient['unit'] = $meal_nutrient['unit'];

        /** Load Term by Name */
        $term = \Drupal::entityTypeManager()
                ->getStorage('taxonomy_term')
	            ->loadByProperties(['name' => $meal_nutrient['key'],'vid' => 'nutrients']);
        $term = reset($term);
        $term = CommonFunc::multilingualConvert("entity",$term);
        if(!empty($term)){
          $term_description = strip_tags($term->description->value);
        }
        /** We can also use ->getDescription() in place of ->get('description')->value */

        $consumed = $consumed_nutrients[$meal_nutrient['id']];
        $consumedset = $consumed_nutrients[$meal_nutrient['id']];
        $consumedPct = round(((($consumed * 7) / $nutrient['rda']) * 100));

        if (($consumedPct > $meal_nutrient['shortfall_deviation1']) && ($consumedPct < $meal_nutrient['excess_deviation1'])) {
            $class = 'green';
        } elseif (($consumedPct > $meal_nutrient['shortfall_deviation2']) && ($consumedPct < $meal_nutrient['shortfall_deviation1']) && ($consumedPct > $meal_nutrient['excess_deviation1']) && ($consumedPct < $meal_nutrient['excess_deviation2'])) {
            $class = 'orange';
        } elseif (($consumedPct < $meal_nutrient['shortfall_deviation2']) && ($consumedPct > $meal_nutrient['excess_deviation2'])) {
            $class = 'red';
        } else {
            $class = 'red';
        }

        $of_rda_of = ' of RDA of ';
        if ($hindi) {
          $of_rda_of = ' के आरडीए की ';
        }
		if($i ==0) {
			$classac = "rda-active";
		} else {
			$classac = "";
		}
		if($meal_nutrient['name'] == 'Energy') {
			$negClass = 'energy-clr';
		} else if($meal_nutrient['name'] == 'Carbohydrate') {
			$negClass = 'carbohydrates-clr';
		} else if($meal_nutrient['name'] == 'Protein') {
			$negClass = 'protien-clr';
		} else if($meal_nutrient['name'] == 'Total Fat') {
			$negClass  = 'fat-clr';
		} else if($meal_nutrient['name'] == 'Calcium'){
			$negClass  = 'calcium-clr';
		} else if($meal_nutrient['name'] == 'Iron') {
			$negClass  = 'iron-clr';
		} else if($meal_nutrient['name'] == 'Vitamin B12') {
			$negClass  = 'vitaminB12-clr';
		} else if($meal_nutrient['name'] == 'Total Fiber') {
			$negClass  = 'fiber-clr';
		} else if($meal_nutrient['name'] == 'Vitamin C') {
			$negClass  = 'vitaminc-clr';
		} else if($meal_nutrient['name'] == 'Vitamin A') {
			$negClass  = 'vitamina-clr';
		}
         
		
		 
        if ($meal_rda[$meal_nutrient['id']] != '') {
            $mealNutrient .= '<items><div class="rda-thum"><a class="'.$classac.'" data-cont="'.htmlspecialchars_decode($term_description).'" href="javascript:void(0);">
			                <span class="rda-box">
		                   <span class="rda-val"><i class="'.$negClass.'"></i>'.number_format((($consumedset / $meal_rda[$meal_nutrient['id']]) * 100)) .'%</span>
						   <span class="rda-hd">'.$meal_nutrient['name'].'</span>
						   <span class="rda-text">( ' . (number_format($consumedset) . ' ' . $meal_nutrient['unit']) . $of_rda_of . (number_format($meal_rda[$meal_nutrient['id']]) . ' ' . $meal_nutrient['unit'])  . ' )</span>
		                  <span class="rda-btm"><i class="eva-info"></i>RDA</span>
						  </span></a></div></items>'; 
        }

        $i++;
      }
    }

    return $mealNutrient;
  }
  /**
   * Get field value by child Id.
   */
  public static function childField($field = NULL) {
    
	$childId = self::childId();
    if ($childId) {
      $child = Node::load($childId);
      return $child->$field->value;
    }
    else {
      return false;
    }
	/*
	if($field =='field_child_key') {
		return 'hrOrkTj2bh7YqI2u';
	} else if($field =='field_participation_key') {
		return '2dl92xj0k0';
	} else {
		return false;
	}
	*/
	
  }
  /**
   * Get child Id.
   */
  public static function childId() {
    $session = \Drupal::request()->getSession();
    $cid = $session->get('child_id');
    if ($cid != '') {
      $child_id = $cid;
    }
    else {
      $id = self::userId();
      $nid = \Drupal::entityQuery('node')
        ->condition('type', 'child_registration', '=')
        ->condition('field_parent_id', $id, '=')
        ->sort('nid', 'asc')
        ->execute();
      $child_id = reset($nid);
      $session->set('child_id', reset($nid));
    }
    return $child_id;
  }
  /**
   * Get current date and time in drupal way.
   */
  public static function currentTime($format) {
    $date = new DrupalDateTime();
    return $date->format($format);
  }
    /**
   * Get child height with weight .
   */
  public static function childHeightWgt($hgtWeightArr) {

    $height = $hgtWeightArr['height'];
    $weight = $hgtWeightArr['weight'];
    $ideal_height_from = $hgtWeightArr['ideal_height_from'];
    $ideal_height_to = $hgtWeightArr['ideal_height_to'];
    $ideal_weight_from = $hgtWeightArr['ideal_weight_from'];
    $ideal_weight_to = $hgtWeightArr['ideal_weight_to'];

    $bmiValue = '';
    $bmi_from = '';
    $bmi_to = '';

    if (isset($hgtWeightArr['bmiValue'])) {
      $bmiValue = $hgtWeightArr['bmiValue'];
    }

    if (isset($hgtWeightArr['bmi_from'])) {
      $bmi_from = $hgtWeightArr['bmi_from'];
    }
    if (isset($hgtWeightArr['bmi_to'])) {
      $bmi_to = $hgtWeightArr['bmi_to'];
    }

    if ($weight < $ideal_weight_from) {

      $weightClass = "less-weight";
    }
    if ($weight > $ideal_weight_to) {

      $weightClass = "more-weight";
    }
    if ($weight >= $ideal_weight_from && $weight <= $ideal_weight_to) {

      $weightClass = "ideal-weight";
    }

    if ($height < $ideal_height_from) {

      $heightClass = "less-height";
    }
    if ($height > $ideal_height_to) {

      $heightClass = "more-height";
    }
    if ($height >= $ideal_height_from && $height <= $ideal_height_to) {

      $heightClass = "ideal-height";
    }

    if (isset($bmiValue) && isset($bmi_from) && isset($bmi_to)) {

      if ($bmiValue < $bmi_from) {

        $bmiClass = "bmi_less";
      }
      if ($bmiValue > $bmi_to) {

        $bmiClass = "bmi_more";
      }
      if ($bmiValue >= $bmi_from && $bmiValue <= $bmi_to) {

        $bmiClass = "bmi_ideal";
      }
    }

    $responseHgtWgtArr = [
      'weightClass' => $weightClass,
      'heightClass' => $heightClass,
      'bmiClass' => $bmiClass,
    ];

    return $responseHgtWgtArr;
  }
   /**
   * Get years and months based on current date.
   */
  public static function calculateYearMonth($child_age) {
    $today = self::currentTime('Y-m-d');
    $datediff = strtotime($today) - strtotime($child_age);
    $years = floor($datediff / (365 * 60 * 60 * 24));
    $months = floor(($datediff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
    $date['year'] = $years;
    $date['month'] = $months;
    return $date;
  }
  /**
   * Check date is weekend.
   */
  public static function isWeekend($date) {
    return (date('N', strtotime($date)) >= 6);
  }
  /*
   * Unset meal slots as per requirements
   */
  public static function unsetTime($times, $options){
    foreach ($times as $time) {
      if (($key = array_search($time, $options)) !== FALSE) {
        unset($options[$key]);
      }
    }
    return $options;
  }

  
   /**
   * Get food time according to the child's age.
   */
  public static function getFoodTime($options, $age) {
    $hindi = self::isHindi();
    if ($age <= 2) {
      $times = ['Tiffin 1', 'Tiffin', 'Tiffin 2'];
      if ($hindi) {
        $hindi_array = [];
        foreach ($times as $time) {
          $properties['name'] = $time;
          $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
          $term = reset($terms);
          $term = CommonFunc::multilingualConvert("entity",$term);
          $hindi_name = $term->getName();
          array_push($hindi_array, $hindi_name);
        }
        $timeslots = self::unsetTime($hindi_array, $options);
      }
      else {
        $timeslots = self::unsetTime($times, $options);
      }
    }
    elseif ($age > 2 && $age <= 3) {
      if (self::isWeekend(date('d-m-Y')) == 1) {
        $times = ['Tiffin 1', 'Tiffin', 'Tiffin 2'];
        if ($hindi) {
          $hindi_array = [];
          foreach ($times as $time) {
            $properties['name'] = $time;
            $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
            $term = reset($terms);
            $term = CommonFunc::multilingualConvert("entity",$term);
            $hindi_name = $term->getName();
            array_push($hindi_array, $hindi_name);
          }
          $timeslots = self::unsetTime($hindi_array, $options);
        }
        else {
          $timeslots = self::unsetTime($times, $options);
        }
      }
      else {
        $times = ['Mid Morning Snack', 'Tiffin 1', 'Tiffin 2'];
        if ($hindi) {
          $hindi_array = [];
          foreach ($times as $time) {
            $properties['name'] = $time;
            $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
            $term = reset($terms);
            $term = CommonFunc::multilingualConvert("entity",$term);
            $hindi_name = $term->getName();
            array_push($hindi_array, $hindi_name);
          }
          $timeslots = self::unsetTime($hindi_array, $options);
        }
        else {
          $timeslots = self::unsetTime($times, $options);
        }
      }
    }
    else {
      if (self::isWeekend(date('d-m-Y')) == 1) {
        $times = ['Tiffin 1', 'Tiffin', 'Tiffin 2'];
        if ($hindi) {
          $hindi_array = [];
          foreach ($times as $time) {
            $properties['name'] = $time;
            $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
            $term = reset($terms);
            $term = CommonFunc::multilingualConvert("entity",$term);
            $hindi_name = $term->getName();
            array_push($hindi_array, $hindi_name);
          }
          $timeslots = self::unsetTime($hindi_array, $options);
        }
        else {
          $timeslots = self::unsetTime($times, $options);
        }
      }
      else {
        $times = ['Breakfast', 'Mid Morning Snack', 'Tiffin'];
        if ($hindi) {
          $hindi_array = [];
          foreach ($times as $time) {
            $properties['name'] = $time;
            $terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
            $term = reset($terms);
            $term = CommonFunc::multilingualConvert("entity",$term);
            $hindi_name = $term->getName();
            array_push($hindi_array, $hindi_name);
          }
          $timeslots = self::unsetTime($hindi_array, $options);
        }
        else {
          $timeslots = self::unsetTime($times, $options);
        }
      }
    }
    return $timeslots;
  }
  
  /**
   * Get date intervals as per date format, no of days and past or future dates.
   */
  public static function getDayIntervals($format, $days, $status = '') {
    $today = date('d-m-Y');
    $date = new DrupalDateTime($today);
    $today_display = $date->format($format);
    $this_date[$today] = $today_display;
   
    for ($i = 1; $i <= $days - 1; $i++) {
      if ($status == 1) {
        $ndate = strtotime('+' . $i . ' day', strtotime($today));
        $date = new DrupalDateTime(date($format, $ndate));
        $today_display = $date->format($format);
        $this_date[date('d-m-Y', $ndate)] = $today_display;
		
      }
      else {
        $ndate = strtotime('-' . $i . ' day', strtotime($today));
        $date = new DrupalDateTime(date($format, $ndate));
        $today_display = $date->format($format);
        $this_date[date('d-m-Y', $ndate)] = $today_display;
      }
    }

    return $this_date;
  }


  /**
   * Get recipe meta data by Recipe seo name.
   */
  public static function getRecipeMetaDataBySeoName($seo_name) {
    $recipeMetaData = array();
    $post_recipe_seo_name = CommonFunc::APiHindi(['recipe_name' => $seo_name]);
    if(isset($post_recipe_seo_name['lang']) && $post_recipe_seo_name['lang']=='hi' ){
      $hindi_recipe_details = NestleAPI::recipesDetail($post_recipe_seo_name);
      if($hindi_recipe_details['status'] == 'success'){
         $hindi_recipe_details_calories = $hindi_recipe_details['contents']['recipe_rda_delivery'][0]['total'];
        $hindi_recipe_details = $hindi_recipe_details['contents']['recipe_details'][0];
        $recipeMetaData = $hindi_recipe_details;
        $recipeMetaData['recipeMetadata']['id'] = $hindi_recipe_details['id'];
        $recipeMetaData['recipeMetadata']['seo_name'] = $hindi_recipe_details['seo_name'];
        $recipeMetaData['recipeMetadata']['seo_alt_name'] = $hindi_recipe_details['seo_name_alternate'];
        $recipeMetaData['recipeMetadata']['calories'] = $hindi_recipe_details_calories;
        $recipeMetaData['recipeMetadata']['hindi_name'] = $hindi_recipe_details['name'];
         $post_seo_alt_data = array('recipe_name' => $recipeMetaData['recipeMetadata']['seo_alt_name'], 'lang' =>"en");
         $recipeMetaData['recipeMetadata']['eng_name'] = self::getRecipeNameByLang($post_seo_alt_data);
      }
    }
    else{
      $eng_recipe_details = NestleAPI::recipesDetail($post_recipe_seo_name);
      if($eng_recipe_details['status'] == 'success'){
        $eng_recipe_details_calories = $eng_recipe_details['contents']['recipe_rda_delivery'][0]['total'];
        $eng_recipe_details = $eng_recipe_details['contents']['recipe_details'][0];
        $recipeMetaData = $eng_recipe_details;
        $recipeMetaData['recipeMetadata']['id'] = $eng_recipe_details['id'];
        $recipeMetaData['recipeMetadata']['calories'] = $eng_recipe_details_calories;
        $recipeMetaData['recipeMetadata']['seo_name'] = $eng_recipe_details['seo_name'];
        $recipeMetaData['recipeMetadata']['seo_alt_name'] = $eng_recipe_details['seo_name_alternate'];
        $recipeMetaData['recipeMetadata']['eng_name'] = $eng_recipe_details['name'];
        $post_seo_alt_data = array('recipe_name' => $recipeMetaData['recipeMetadata']['seo_alt_name'], 'lang' =>"hi");
        $recipeMetaData['recipeMetadata']['hindi_name']= self::getRecipeNameByLang($post_seo_alt_data);
      }

    }
    return $recipeMetaData;
  }

  /**
   * Get recipe meta data by Redirect Recipe seo name.
   */
  public static function getRedirectRecipeMetaDataBySeoName($seo_name, $lang) {
    $recipeMetaData = array();
    $post_recipe_seo_name = CommonFunc::APiHindi(['recipe_name' => $seo_name]);
    $post_recipe_seo_name['recipe_name'] = $seo_name;
    $post_recipe_seo_name['lang'] = $lang;
    if(isset($post_recipe_seo_name['lang']) && $post_recipe_seo_name['lang']=='hi' ){
      $hindi_recipe_details = NestleAPI::recipesDetail($post_recipe_seo_name);
      if($hindi_recipe_details['status'] == 'success'){
        $hindi_recipe_details = $hindi_recipe_details['contents']['recipe_details'][0];
        $recipeMetaData = $hindi_recipe_details;
        $recipeMetaData['recipeMetadata']['id'] = $hindi_recipe_details['id'];
        $recipeMetaData['recipeMetadata']['seo_name'] = $hindi_recipe_details['seo_name'];
        $recipeMetaData['recipeMetadata']['seo_alt_name'] = $hindi_recipe_details['seo_name_alternate'];
        $recipeMetaData['recipeMetadata']['hindi_name'] = $hindi_recipe_details['name'];
         $post_seo_alt_data = array('recipe_name' => $recipeMetaData['recipeMetadata']['seo_alt_name'], 'lang' =>"en");
         $recipeMetaData['recipeMetadata']['eng_name'] = self::getRecipeNameByLang($post_seo_alt_data);
      }
    }
    else{
      $eng_recipe_details = NestleAPI::recipesDetail($post_recipe_seo_name);
      if($eng_recipe_details['status'] == 'success'){
        $eng_recipe_details = $eng_recipe_details['contents']['recipe_details'][0];
        $recipeMetaData = $eng_recipe_details;
        $recipeMetaData['recipeMetadata']['id'] = $eng_recipe_details['id'];
        $recipeMetaData['recipeMetadata']['seo_name'] = $eng_recipe_details['seo_name'];
        $recipeMetaData['recipeMetadata']['seo_alt_name'] = $eng_recipe_details['seo_name_alternate'];
        $recipeMetaData['recipeMetadata']['eng_name'] = $eng_recipe_details['name'];
        $post_seo_alt_data = array('recipe_name' => $recipeMetaData['recipeMetadata']['seo_alt_name'], 'lang' =>"hi");
        $recipeMetaData['recipeMetadata']['hindi_name']= self::getRecipeNameByLang($post_seo_alt_data);
      }

    }
    return $recipeMetaData;
  }




    /**
   * Get recipe name by Recipe alternate seo name.
   */
  public static function getRecipeNameByLang($post_seo_alt_data) {
    $recipe_alt_details = NestleAPI::recipesDetail($post_seo_alt_data);
    if($recipe_alt_details['status'] == 'success'){
      $recipe_alt_details = $recipe_alt_details['contents']['recipe_details'][0];
      $recipeAltName = $recipe_alt_details['name'];
    }
    return($recipeAltName);
  }
  /**
   * Get recipe Like dislike data by recipe seo name.
   */
  public static function getRecipeFavlikeDislike($rid, $lang) {
    $hindi = self::isHindi();
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    if ($lang == 'hi') {
      $target_field = 'recipe_alter_seo_name';
    }else{
      $target_field = 'recipe_seo_name';
    }
    $favCount = $connection->select('nestle_fav_recipe_data', 't')
    ->condition($target_field, $rid, '=')
    ->condition('t.uid', $uid, '=')->fields('t', ['id'])
    ->execute()->fetchAll();
    if (!empty($favCount)) {
      return('dislike');
    }else{
      return('like');
    }
  }
  /**
   * Get recipe mark or unmark data by recipe seo name.
   */
  public static function getBookmarkRecipeMarkUnmark($rid, $uid, $lang) {
    $hindi = self::isHindi();
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    if ($lang == 'hi') {
      $target_field = 'recipe_alter_seo_name';
    }else{
      $target_field = 'recipe_seo_name';
    }
    $bookmarkCount = $connection->select('nestle_bookmark_recipe_data', 't')
    ->condition($target_field, $rid, '=')
    ->condition('t.uid', $uid, '=')->fields('t', ['id'])
    ->execute()->fetchAll();
    if (!empty($bookmarkCount)) {
      return('unmark');
    }else{
      return('mark');
    }
  }
   /**
   * Get global recipe Rating by Recipe seo name.
   */
  public static function getRecipeRatingBySeo($post_seo, $lang) {
    if ($lang == 'hi') {
      $target_field = 'recipe_alter_seo_name';
    }else{
      $target_field = 'recipe_seo_name';
    }

    $query = \Drupal::database()->select('nestle_rate_recipe_data');
    $query->condition($target_field, $post_seo, '=');
    $query->addExpression('avg(rate)', 'total');
    $result = $query->execute()->fetchAll();
    $starValue = number_format((float)$result[0]->total, 1, '.', '');
    return($starValue);
  }
   /**
   * Get User recipe Rating by Recipe seo name.
   */
  public static function getUserRecipeRatingBySeo($post_seo, $uid, $lang) {
    if ($lang == 'hi') {
      $target_field = 'recipe_alter_seo_name';
    }else{
      $target_field = 'recipe_seo_name';
    }

    $query = \Drupal::database()->select('nestle_rate_recipe_data');
    $query->condition($target_field, $post_seo, '=');
    $query->condition("uid", $uid, '=');
    $query->addExpression('avg(rate)', 'total');
    $result = $query->execute()->fetchAll();
    $starValue = number_format((float)$result[0]->total, 0, '.', '');
    return($starValue);
  }
  /**
	* Get Current Week Date.
	*/
	public static function currentWeekDate($date) {
	
    $today = $date;
    $dt = new DrupalDateTime($today);
	
	$dates = [];
	for ($d = 1; $d <= 7; $d++) {
	$dt->setISODate($dt->format('o'), $dt->format('W'), $d);
	$dates[$dt->format('D')] = $dt->format('d-m-Y');
	}
	return $dates;
	
	}
	
	/**
	* Get name by taxonomy details.
	*/
	public static function getTermByName($name) {
		// Set name properties.
		$properties['name'] = $name;

		// Load taxonomy term by properties.
		$terms = \Drupal::service('entity_type.manager')->getStorage('taxonomy_term')->loadByProperties($properties);
		$term = reset($terms);

		return !empty($term) ? $term->id() : 0;
	}
	
	/**
    * decrypt redirect data.
    */
    public static function decryptRediret($data) {
        if(!empty($data)){
            $output = CommonFunc::decryptData($data);
            $arr = explode("|",$output);
           return $arr;
        }else{
            return FALSE;
        }
    }
	
	/**
    * encrypt data.
    */
    public static function encryptData($data){
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'unique_secret_key';
        $secret_iv = 'unique_secret_iv';
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16);
        $output = openssl_encrypt($data, $encrypt_method, $key, 0, $iv);



       return base64_encode($output);
    }
	
	/**
    * decrypt data.
    */
    public static function decryptData($data){
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'unique_secret_key';
        $secret_iv = 'unique_secret_iv';
        $string = $data;
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16);
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        
        return $output;
    }
	
	/**
   * Get first array key.
   */
   public static function arrayKeyFirst(array $arr) {
    foreach ($arr as $key => $unused) {
      return $key;
    }
    return NULL;
  }
  
   /**
   * Use for getting user details(session track)
   */
  public function childStatusTrack(Request $request) {

    $session = \Drupal::request()->getSession();
    $selectChildVal = $request->query->get('SelectChildVal');
    $session->set('child_id', $selectChildVal);

    echo $selectChildVal;
    exit;
  }
}
