<?php

namespace Drupal\nestle_common\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\file\Entity\File;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\Response;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\comment\Entity\Comment;
use Drupal\Core\Language\LanguageManager;
use Drupal\Component\Utility\Xss;

/**
 * It is used for global ajax functionality in Nestle project.
 */
class AjaxControl extends ControllerBase {

  /**
   * Ajax response return with data array.
   */
  public function setAjax() {
    global $base_url;

    $hindi = CommonFunc::isHindi();

    $lang_code = CommonFunc::multilingualConvert("lang");

    $action = \Drupal::request()->request->get('action');

    if (empty($action) && $action == '') {
      throw new NotFoundHttpException();
    }
	/**
	  Recipe Search By Ajax
	**/
	if (!empty($action) && $action == 'searchBykeyword') {
			
      $keyword = \Drupal::request()->request->get('keyword');
      $html = '';

      $post_data = [
        "name" => $keyword
      ];

      $items = NestleAPI::searchItem($post_data);
      if($items != 0) {
        foreach($items as $item) {
          $html .= '<div data-eng="'.$item['name'].'" data-key="'.$item['id'].'" data-title="'.$item['name'].'" class="searchAutofood srchDataItm">'.$item['name'].'</div>';
        }

        
      }
	  
	  return new JsonResponse($html);
    }
	

  /****** Start save tried recipe section ajax *************/ 
  if (!empty($action) && $action == 'saveTriedRecipe') {
    $result = '';
    $rid = \Drupal::request()->request->get('id');
    $recipeaction = \Drupal::request()->request->get('recipeAction');
    $recipeSeoName = \Drupal::request()->request->get('recipeSeoName');
    $recipeAltSeoName = \Drupal::request()->request->get('recipeAltSeoName');
    $recipeHindiName = \Drupal::request()->request->get('recipeHindiName');
    $recipeEngName = \Drupal::request()->request->get('recipeEngName');
    $lang = \Drupal::request()->request->get('lang');
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    $hindiLang = CommonFunc::isHindi();
    $current_time = \Drupal::time()->getCurrentTime();
    $timenow = \Drupal::service('date.formatter')->format($current_time, 'Y-m-d H:i:s');
    if (!empty($rid)) {
        $count = $connection->select('nestle_tried_recipe_data', 't')
          ->condition('t.uid', $uid, '=')
          ->condition('t.recipe_id', $rid, '=')
          ->fields('t', ['id'])
          ->execute()->fetchAll();
      $recipeCount = sizeof($count);
    }
    if($recipeCount == 0 && $recipeaction == 'add'){
      $insert = [
        'uid' => $uid,
        'recipe_id' => $rid,
        'created_on' => $current_time,
        'recipe_seo_name' =>$recipeSeoName,
        'recipe_alter_seo_name' => $recipeAltSeoName,
        'recipe_eng_name' => $recipeEngName,
        'recipe_hindi_name' => $recipeHindiName,
        'lang' => $lang,
        'rate' => 5
      ];
       $result = $connection->insert('nestle_tried_recipe_data')
        ->fields($insert)
        ->execute();
        $result = 'added';
    }
    if($recipeCount > 0 && $recipeaction == 'remove'){
      $result = \Drupal::database()->delete('nestle_tried_recipe_data');   
      $result->condition('uid', $uid); 
      $result->condition('recipe_id', $rid);
      $result->execute();
      $result ='removed';
    }
    return new JsonResponse($result);
  }

  /**
    Tried Recipe Search By Ajax
  **/
  if (!empty($action) && $action == 'searchTriedRecipe') { 
    $keyword = \Drupal::request()->request->get('keyword');
    $language = \Drupal::request()->request->get('language');
    $html = '';
    /*
    tried recipe suggession
    */
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    if($language == 'hi') {
      $targetField = 't.recipe_hindi_name';
      $getField = 'recipe_hindi_name';
    } else {
      $targetField = 't.recipe_eng_name';
      $getField = 'recipe_eng_name';
    }

    $triedRecipes = $connection->select('nestle_tried_recipe_data', 't')
      ->condition('t.uid', $uid, '=')
      ->condition($targetField, '%'.$keyword.'%', 'LIKE')
      ->orderBy('t.id', "DESC")
      ->fields('t', [$getField])
      ->execute()->fetchAll();
      if(!empty($triedRecipes)) {
      $html .='<div class="triedRecipeAutocomplete srchData">'; 
      foreach ($triedRecipes as $recipe) {
        if($language == 'hi') {
          $recipe_title = $recipe->recipe_hindi_name;
        } else {
          $recipe_title = $recipe->recipe_eng_name;
        }
        
        $html .= '<div data-eng="'.$recipe_title.'" data-key="" data-title="'.$recipe_title.'" class="searchTriedRecipeAuto srchDataItm">'.$recipe_title.'</div>';
      }
    }
    return new JsonResponse($html);
    }
  /****** End save tried section ajax *************/

  /****** Start save fav recipe section ajax *************/ 
  if (!empty($action) && $action == 'saveFavRecipe') {
    $result = '';
    $rid = \Drupal::request()->request->get('id');
    $recipeaction = \Drupal::request()->request->get('recipeAction');
    $recipeSeoName = \Drupal::request()->request->get('recipeSeoName');
    $recipeAltSeoName = \Drupal::request()->request->get('recipeAltSeoName');
    $recipeHindiName = \Drupal::request()->request->get('recipeHindiName');
    $recipeEngName = \Drupal::request()->request->get('recipeEngName');
    $lang = \Drupal::request()->request->get('lang');
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    $hindiLang = CommonFunc::isHindi();
    $current_time = \Drupal::time()->getCurrentTime();
    $timenow = \Drupal::service('date.formatter')->format($current_time, 'Y-m-d H:i:s');
    if (!empty($rid)) {
        $count = $connection->select('nestle_fav_recipe_data', 't')
          ->condition('t.uid', $uid, '=')
          ->condition('t.recipe_id', $rid, '=')
          ->fields('t', ['id'])
          ->execute()->fetchAll();
      $recipeCount = sizeof($count);
    }
    if($recipeCount == 0 && $recipeaction == 'add'){
      if($lang == 'hi'){
      $insert = [
        'uid' => $uid,
        'recipe_id' => $rid,
        'created_on' => $current_time,
        'recipe_seo_name' =>$recipeAltSeoName,
        'recipe_alter_seo_name' => $recipeSeoName,
        'recipe_eng_name' => $recipeEngName,
        'recipe_hindi_name' => $recipeHindiName,
        'lang' => $lang,
        'rate' => 5,
      ];
      }else{
         $insert = [
        'uid' => $uid,
        'recipe_id' => $rid,
        'created_on' => $current_time,
        'recipe_seo_name' =>$recipeSeoName,
        'recipe_alter_seo_name' => $recipeAltSeoName,
        'recipe_eng_name' => $recipeEngName,
        'recipe_hindi_name' => $recipeHindiName,
        'lang' => $lang,
        'rate' => 5,
      ];
      }
      
       $result = $connection->insert('nestle_fav_recipe_data')
        ->fields($insert)
        ->execute();
        $result = 'added';
    }
    if($recipeCount > 0 && $recipeaction == 'remove'){
      $result = \Drupal::database()->delete('nestle_fav_recipe_data');   
      $result->condition('uid', $uid); 
      $result->condition('recipe_id', $rid);
      $result->execute();
      $result ='removed';
    }
    return new JsonResponse($result);
  }
  /**
    Fav Recipe Search By Ajax
  **/
  if (!empty($action) && $action == 'searchFavRecipe') { 
    $keyword = \Drupal::request()->request->get('keyword');
    $language = \Drupal::request()->request->get('language');
    $html = '';
    /*
    fav recipe suggession
    */
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    if($language == 'hi') {
      $targetField = 't.recipe_hindi_name';
      $getField = 'recipe_hindi_name';
    } else {
      $targetField = 't.recipe_eng_name';
      $getField = 'recipe_eng_name';
    }

    $triedRecipes = $connection->select('nestle_fav_recipe_data', 't')
      ->condition('t.uid', $uid, '=')
      ->condition($targetField, '%'.$keyword.'%', 'LIKE')
      ->orderBy('t.id', "DESC")
      ->fields('t', [$getField])
      ->execute()->fetchAll();
      if(!empty($triedRecipes)) {
      $html .='<div class="favRecipeAutocomplete srchData">'; 
      foreach ($triedRecipes as $recipe) {
        if($language == 'hi') {
          $recipe_title = $recipe->recipe_hindi_name;
        } else {
          $recipe_title = $recipe->recipe_eng_name;
        }
        
        $html .= '<div data-eng="'.$recipe_title.'" data-key="" data-title="'.$recipe_title.'" class="searchFavRecipeAuto srchDataItm">'.$recipe_title.'</div>';
      }
    }
    return new JsonResponse($html);
    }
  /****** End save fav section ajax *************/


  /****** Start save Rate recipe section ajax *************/ 
    if (!empty($action) && $action == 'saveRateRecipe') {
      $output = array();
      $rid = \Drupal::request()->request->get('id');
      $starValue = \Drupal::request()->request->get('starValue');
      $recipeaction = \Drupal::request()->request->get('recipeAction');
      $recipeSeoName = \Drupal::request()->request->get('recipeSeoName');
      $recipeAltSeoName = \Drupal::request()->request->get('recipeAltSeoName');
      $recipeHindiName = \Drupal::request()->request->get('recipeHindiName');
      $recipeEngName = \Drupal::request()->request->get('recipeEngName');
      $lang = \Drupal::request()->request->get('lang');
      $uid = CommonFunc::userId();
      $connection = \Drupal::database();
      $hindiLang = CommonFunc::isHindi();
      $current_time = \Drupal::time()->getCurrentTime();
      $timenow = \Drupal::service('date.formatter')->format($current_time, 'Y-m-d H:i:s');

      if (!empty($rid)) {
        if($lang == 'hi'){
          $count = $connection->select('nestle_rate_recipe_data', 't')
            ->condition('t.uid', $uid, '=')
            ->condition('t.recipe_alter_seo_name', $rid, '=')
            ->fields('t', ['id'])
            ->execute()->fetchAll();

        }else{
          $count = $connection->select('nestle_rate_recipe_data', 't')
            ->condition('t.uid', $uid, '=')
            ->condition('t.recipe_seo_name', $rid, '=')
            ->fields('t', ['id'])
            ->execute()->fetchAll();
        }
        $recipeCount = sizeof($count);
      }
      if($recipeCount == 0 && $recipeaction == 'add'){
        $insert = [
          'uid' => $uid,
          'recipe_id' => $rid,
          'created_on' => $current_time,
          'recipe_seo_name' =>$recipeSeoName,
          'recipe_alter_seo_name' => $recipeAltSeoName,
          'recipe_eng_name' => $recipeEngName,
          'recipe_hindi_name' => $recipeHindiName,
          'lang' => $lang,
          'rate' => $starValue,
        ];
         $result = $connection->insert('nestle_rate_recipe_data')
          ->fields($insert)
          ->execute();
          $output['action'] = 'added';
        $query = \Drupal::database()->select('nestle_rate_recipe_data');
        $query->condition("recipe_seo_name", $rid, '=');
        $query->addExpression('avg(rate)', 'total');
        $result = $query->execute()->fetchAll();
        $starValue = number_format((float)$result[0]->total, 1, '.', '');
        $output['star'] = $starValue;
      }
      if($recipeCount > 0 && $recipeaction == 'update'){

        $result = \Drupal::database()->update('nestle_rate_recipe_data')->fields(array('rate' => $starValue));   
        $result->condition('uid', $uid); 
        if($lang == 'hi'){
          $result->condition('recipe_alter_seo_name', $rid);
          $targetField = 'recipe_alter_seo_name';
        }else{
          $result->condition('recipe_seo_name', $rid); 
          $targetField = 'recipe_seo_name';  
        }
        $result->execute();

        $output['action'] = 'update';
        $query = \Drupal::database()->select('nestle_rate_recipe_data');
        $query->condition($targetField, $rid, '=');
        $query->addExpression('avg(rate)', 'total');
        $result = $query->execute()->fetchAll();
        $starValue = number_format((float)$result[0]->total, 1, '.', '');
        $output['star'] = $starValue;
      }
      $reponseArr = ['action' => $output['action'], 'star' => $output['star']];
      return new JsonResponse($output);
    }
  /****** End save Rate recipe section ajax *************/ 
  /****** Start save bookmark recipe section ajax *************/ 
    if (!empty($action) && $action == 'saveBookmarkRecipe') {
      $result = '';
      $rid = \Drupal::request()->request->get('id');
      $recipeaction = \Drupal::request()->request->get('recipeAction');
      $recipeSeoName = \Drupal::request()->request->get('recipeSeoName');
      $recipeAltSeoName = \Drupal::request()->request->get('recipeAltSeoName');
      $recipeHindiName = \Drupal::request()->request->get('recipeHindiName');
      $recipeEngName = \Drupal::request()->request->get('recipeEngName');
      $lang = \Drupal::request()->request->get('lang');
      $uid = CommonFunc::userId();
      $connection = \Drupal::database();
      $hindiLang = CommonFunc::isHindi();
      $current_time = \Drupal::time()->getCurrentTime();
      $timenow = \Drupal::service('date.formatter')->format($current_time, 'Y-m-d H:i:s');
      if (!empty($rid)) {
          $count = $connection->select('nestle_bookmark_recipe_data', 't')
            ->condition('t.uid', $uid, '=')
            ->condition('t.recipe_id', $rid, '=')
            ->fields('t', ['id'])
            ->execute()->fetchAll();
        $recipeCount = sizeof($count);
      }
      if($recipeCount == 0 && $recipeaction == 'add'){
        $insert = [
          'uid' => $uid,
          'recipe_id' => $rid,
          'created_on' => $current_time,
          'recipe_seo_name' =>$recipeSeoName,
          'recipe_alter_seo_name' => $recipeAltSeoName,
          'recipe_eng_name' => $recipeEngName,
          'recipe_hindi_name' => $recipeHindiName,
          'lang' => $lang,
          'rate' => 5,
        ];
         $result = $connection->insert('nestle_bookmark_recipe_data')
          ->fields($insert)
          ->execute();
          $result = 'added';
      }
      if($recipeCount > 0 && $recipeaction == 'remove'){
        $result = \Drupal::database()->delete('nestle_bookmark_recipe_data');   
        $result->condition('uid', $uid); 
        $result->condition('recipe_id', $rid);
        $result->execute();
        $result ='removed';
      }
      return new JsonResponse($result);
    }
    /**
      bookmark Recipe Search By Ajax
    **/
    if (!empty($action) && $action == 'searchBookmarkRecipe') {
      $keyword = \Drupal::request()->request->get('keyword');
      $language = \Drupal::request()->request->get('language');
      $html = '';
      /*
      bookmark recipe suggession
      */
      $uid = CommonFunc::userId();
      $connection = \Drupal::database();
      if($language == 'hi') {
        $targetField = 't.recipe_hindi_name';
        $getField = 'recipe_hindi_name';
      } else {
        $targetField = 't.recipe_eng_name';
        $getField = 'recipe_eng_name';
      }

      $triedRecipes = $connection->select('nestle_bookmark_recipe_data', 't')
        ->condition('t.uid', $uid, '=')
        ->condition($targetField, '%'.$keyword.'%', 'LIKE')
        ->orderBy('t.id', "DESC")
        ->fields('t', [$getField])
        ->execute()->fetchAll();
        if(!empty($triedRecipes)) {
        $html .='<div class="bookmarkRecipeAutocomplete srchData">'; 
        foreach ($triedRecipes as $recipe) {
          if($language == 'hi') {
            $recipe_title = $recipe->recipe_hindi_name;
          } else {
            $recipe_title = $recipe->recipe_eng_name;
          }
          
          $html .= '<div data-eng="'.$recipe_title.'" data-key="" data-title="'.$recipe_title.'" class="searchBookmarkRecipeAuto srchDataItm">'.$recipe_title.'</div>';
        }
      }
      return new JsonResponse($html);
    }
  /****** End save bookmark section ajax *************/




	/**
	  Ingredient Search By Ajax
	**/
	if (!empty($action) && $action == 'searchIngredientRecipe') {
			
      $keyword = \Drupal::request()->request->get('keyword');
      $html = '';

      $post_data = [
        "ingredient_name" => $keyword
      ];

      $items = NestleAPI::getIngredientsList($post_data);
	  if($items['status'] == 'success') {
		  if(!empty($items['contents'])) {
            foreach($items['contents'] as $key => $val) {
              $html .= '<div data-eng="'.$val['ingredient_name'].'" data-key="'.$val['ingredient_id'].'" data-title="'.$val['ingredient_name'].'" class="searchAutoIng srchDataItm">'.$val['ingredient_name'].'</div>';
            }
          } else {
			$html .= '<div data-eng="Not found" data-key="Not found" data-title="Not found" class="searchAutoIng srchDataItm">No Ingredient found</div>';  
		  }
		  
	  } else {
		$html .= '<div data-eng="Not found" data-key="Not found" data-title="Vot found" class="searchAutoIng srchDataItm">No Ingredient found</div>';  
	  }
	  return new JsonResponse($html);
      
    }
	
	
		/**
	  Global Search By Ajax
	**/
	if (!empty($action) && $action == 'searchGlobalBykeyword') {
	 
		$keyword = \Drupal::request()->request->get('keyword');
		$language = \Drupal::request()->request->get('language');
		$html = '';
		if($language == 'hi') {
			$post_data = [
				"name" => $keyword,
				"lang" => 'hi'
			];
		} else {
			$post_data = [
				"name" => $keyword
			]; 
		}

		$items = NestleAPI::searchItem($post_data);
		// recipe data

		if($items != 0) {
			$html .='<div class="recipesearchoutput"><h3>Recipe</h3>'; 
			$i=0;
			foreach($items as $item) {
				$html .= '<div data-eng="'.$item['name'].'" data-key="'.$item['id'].'" data-title="'.$item['name'].'" class="searchRecipeAutoGlobal srchDataItm" data-cat="Recipe">'.$item['name'].'</div>';

				$i++;
				if($i==5) break;
			}
			if($language == 'hi') {
				$html .='<div class="viewallseacrh"><a href="'.$base_url.'/hindi/search?recipe='.$keyword.'" data-cat="Recipe">सभी को देखें</a></div></div>'; 
			} else {
				$html .='<div class="viewallseacrh"><a href="'.$base_url.'/search?recipe='.$keyword.'" data-cat="Recipe">View All</a></div></div>'; 
			}

		}
		/*
		Article suggession
		*/
		$ea_query = \Drupal::entityQuery('node')
		->range(0, 5)
		->condition('status', 1)
		->condition('type', 'expert_advice', '=');
		// OR Condition
		$ea_group = $ea_query->orConditionGroup()
		->condition('title', $keyword, 'CONTAINS')
		->condition('body', $keyword, 'CONTAINS'); 	
		$ea_nids = $ea_query->condition($ea_group)->sort('created', 'DESC')->execute();
		$ea_nodes = Node::loadMultiple($ea_nids);
		if(!empty($ea_nodes)) {
			$html .='<div class="recipesearchoutput articlesearchoutput"><h3>Article</h3>'; 
			foreach ($ea_nodes as $node) {
				$node = $node->getTranslation($lang_code);
				$expTitle = $node->getTitle();
				$html .= '<div data-eng="'.$expTitle.'" data-key="" data-title="'.$expTitle.'" class="searchArticleAutoGlobal srchDataItm" data-cat="Article">'.$expTitle.'</div>';
			}
			if($language == 'hi') {
				$html .='<div class="viewallseacrh"><a href="'.$base_url.'/hindi/search?article='.$keyword.'" data-cat="Article">सभी को देखें</a></div></div>'; 
			} else {
				$html .='<div class="viewallseacrh"><a href="'.$base_url.'/search?article='.$keyword.'" data-cat="Article">View All</a></div></div>'; 
			}

		}
		/*
		community suggession
		*/
		$cm_query = \Drupal::entityQuery('node')
		->range(0, 5)
		->condition('status', 1)
		->condition('type', 'community', '=');
		// OR Condition
		$cm_group = $cm_query->orConditionGroup()
		->condition('body', $keyword, 'CONTAINS'); 	
		$cm_nids = $cm_query->condition($cm_group)->sort('created', 'DESC')->execute();
		$cm_nodes = Node::loadMultiple($cm_nids);
		if(!empty($cm_nodes)) {
			$html .='<div class="recipesearchoutput articlesearchoutput"><h3>Community</h3>'; 
			foreach ($cm_nodes as $node1) {
				$node2 = $node1->getTranslation($lang_code);
				$bodyVak = strip_tags($node2->get('body')->value);
				$html .= '<div data-eng="'.$bodyVak.'" data-key="" data-title="'.$bodyVak.'" class="searchCommunityAutoGlobal srchDataItm" data-cat="Community">'.$bodyVak.'</div>';
			}
			if($language == 'hi') {
				$html .='<div class="viewallseacrh"><a href="'.$base_url.'/hindi/search?community='.$keyword.'" data-cat="Community">सभी को देखें</a></div></div>'; 
			} else {
				$html .='<div class="viewallseacrh"><a href="'.$base_url.'/search?community='.$keyword.'" data-cat="Community">View All</a></div></div>'; 
			}

		}
		return new JsonResponse($html);
    }

  


    /****** start Load more community section ajax *************/ 
  if (!empty($action) && $action == 'load_community') {
      $row = \Drupal::request()->request->get('row');
      $limit = \Drupal::request()->request->get('limit');
      $user_id = CommonFunc::userId();
      $article = '';

      $nid = \Drupal::entityQuery('node');
      $nid->condition('type', 'community', '=');

      if(\Drupal::currentUser()->isAnonymous() == TRUE) {
        $nid->condition('status', 1);
      } else {
        $group = $nid->orConditionGroup()
                ->condition('uid', $user_id, '=')
                ->condition('status', 1);
        $nid->condition($group);
      }

      $nid->sort('created', 'DESC');
      $nid->range($row, $limit);
      $nids = $nid->execute();
      $communities = Node::loadMultiple($nids);

      $contents = [];
      foreach ($communities as $community) {
        $owner_id = $community->getOwnerId();
        if ($community->isPublished() == FALSE) {
          if ($owner_id === $user_id) {
            $contents['ownpublish'][] = $community;
          } else {
            $contents['unpublish'][] = $community;
          }
        } else {
          $contents['publish'][] = $community;
        }
      }

      $asked = ' asked';
      $pending_approval = t('Pending approval');
      $read_more = t('read more');
      $all = t('all');
      $view = t('View ');
      $comments_display = t(' Comments ');
      $reply = t(' reply');
      $comment_do = t('Comment');
      $share = t('Share');
      $short_url = '';
      $go_to_conv = t('Go to conversation');
      if ($hindi) {
        $asked = ' ने पूछा';
        $pending_approval = 'लंबित अनुमोदन';
        $read_more = ' अधिक पढ़ें';
        $all = ' सभी ';
        $view = 'राय ';
        $comments_display = ' टिप्पणियाँ ';
        $reply = ' जवाब दे';
        $comment_do = 'टिप्पणी';
        $share = 'शेयर करे';
        $short_url = 'hindi/';
        $go_to_conv = 'बातचीत पर जाएं';
      }

      //$view_item ='View '. (($countComments > 1)?' '..' '.$countComments.' Comments':$countComments.' reply');
      if (isset($contents['ownpublish'])) {
        foreach ($contents['ownpublish'] as $content) {
          //$date_ago = date('jS M, y h:i A', $content->get('created')->value);
          $date_ago = \Drupal::service('date.formatter')->format($content->get('created')->value, 'dtf') . " " . date("A", $content->get('created')->value);;
          $community_url = Url::fromRoute('entity.node.canonical', ['node' => $content->id()])->toString();
          $uid =$content->getOwnerId();
          $user = User::load($uid);
          $file_image =File::load($user->user_picture->getValue()[0]['target_id']);
          $original_image = $file_image->getFileUri();
          $image_path = file_url_transform_relative(file_create_url($original_image));

          $article .= '

          <div class="item-comment">  
            <div class="comment-name-date">
              <div class="comment-name">
                <span><img src="'.$image_path.'" alt=""></span>
                <div class="cmtby">
                  <em>'. CommonFunc::getUserValue('field_first_name', $content->getOwnerId()) .'</em><span>('.$pending_approval.')</span>
                </div>
              </div>
              <div class="comment-date">'. $date_ago .'</div>
            </div>
            <p>'. strip_tags(CommonFunc::summary($content->get('body')->value, 125)) .' <span>'.((strlen($content->get('body')->value) > 125)?'<a href="'. $community_url .'">'.$read_more.'</a>':'').'</span>
            </p>
            <div class="like-msg-btn"> <a href="'.$community_url.'" class="go-convrstn">'.$go_to_conv.'</a>
            </div>';
        }
      }


      foreach ($contents['publish'] as $content) {
        $count = CommonFunc::likeDislikeCount($content->id());
        $data = addtoany_create_entity_data($content);

        $share_html = '';
        $like_dislike = CommonFunc::checklikeDislike($content->id());

        if ($like_dislike != '') {
            if (isset($like_dislike[0]->like_num) && $like_dislike[0]->like_num == 1) {
                $like = $like_dislike[0]->like_num;
            }
            else {
              $like = 0;
            }
        }

        $share_html = [
            '#addtoany_html' => \Drupal::token()->replace($data['addtoany_html'], ['node' => $content]),
            '#link_url' => $data['link_url'],
            '#link_title' => strip_tags(CommonFunc::summary($content->get('body')->value, 125)),
            '#button_setting' => $data['button_setting'],
            '#button_image' => $data['button_image'],
            '#universal_button_placement' => $data['universal_button_placement'],
            '#buttons_size' => $data['buttons_size'],
            '#theme' => 'addtoany_standard',
            '#cache' => [
                'contexts' => ['url'],
            ],
        ];

        //$date_ago = date('jS M, y h:i A', $content->get('created')->value);
        $date_ago = \Drupal::service('date.formatter')->format($content->get('created')->value, 'dtf') . " " . date("A", $content->get('created')->value);

        $renderer = \Drupal::service('renderer');
        $formHtml = $renderer->render($share_html);

        $countComments = CommonFunc::countComment($content->id());
        $community_url = Url::fromRoute('entity.node.canonical', ['node' => $content->id()])->toString();
        $uid =$content->getOwnerId();
        $user = User::load($uid);
         if(!empty($user->user_picture->getValue())){
          $fid =  $user->user_picture->getValue()[0]['target_id'];
        }

        if(!empty($fid)){
          $file_image =File::load($user->user_picture->getValue()[0]['target_id']);
          $original_image = $file_image->getFileUri();
          $image_path = file_url_transform_relative(file_create_url($original_image));
        }else{
          $image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
        }




        $article .= '<div class="item-comment">  <div class="comment-name-date">
                <div class="comment-name"><span><img src="'.$image_path.'" alt=""></span>  <div class="cmtby"><em>'. CommonFunc::getUserValue('field_first_name', $content->getOwnerId()) .'</em> </div></div> <div class="comment-date">'. $date_ago .'</div> </div> <p eng="'.strip_tags($content->get('body')->value).'">'. strip_tags(CommonFunc::summary($content->get('body')->value, 125)) .' <span>'.((strlen($content->get('body')->value) > 125)?'<a href="'. $community_url .'">'.$read_more.'</a>':'').'</span></p> <div class="like-msg-btn"> <a href="'.$community_url.'" class="go-convrstn">'.$go_to_conv.'</a><div class="like-msg">';

        if(\Drupal::currentUser()->isAuthenticated() == TRUE) {
            $article .= '<a href="javascript:void(0);"><i class="thumup-icon like_dislike thumup '. (($like != 0)?'activethumup':'').'" aria-hidden="true" data-id="'.$content->id().'" data-ld="'.((($like_dislike) != '')?'dislike':'like').'"></i> <span class="like-count-data">'. (($count['likes'] != '') ? $count['likes'] : 0) .'</span></a><a href="'.$community_url.'"><i class="msg-icon"></i>'.$countComments.'+ </a>';
        } else {
            $article .= '<a href="'. $base_url . $short_url .'/login">
                      <i class="thumup-icon thumup '. (($like != 0)?'activethumup':'').'"></i>'. (($count['likes'] != '') ? $count['likes'] : 0) .'</a><a href="'. $base_url . $short_url .'/login"><i class="msg-icon"></i>'.$countComments.'+ </a> ';
        }

        $article .= '</div>
                </div>
            </div>';
     }
      $reponseArr = ['articlesData' => $article];

      return new JsonResponse($reponseArr);
    }
    /****** End Load more community section ajax *************/ 
    /****** Start Post community section ajax *************/ 
     if (!empty($action) && $action == 'creat_post') {
      $txt = \Drupal::request()->request->get('txt');
      $user_id = CommonFunc::userId();
      //$title = CommonFunc::getCmsContent('field_community_default_title');
      $title = 'Community Post (Q/A)';
      $txt = Xss::filter($txt, []);

      $node = Node::create([
        'type' => 'community',
        'title' => $title,
        'body' => [
          'summary' => '',
          'value' => $txt,
          'format' => 'basic_html',
        ],
        'uid' => $user_id,
      ]);
      $node->save();

      return new JsonResponse('posted');
    }
    /****** End Post community section ajax *************/ 




    /****** Start like community section ajax *************/ 
    if (!empty($action) && $action == 'setLikeDislike') {
      $cid = \Drupal::request()->request->get('id');
      $type = \Drupal::request()->request->get('type');
      $uid = CommonFunc::userId();

      $connection = \Drupal::database();

      $count = $connection->select('community_like_dislike', 'c')
        ->condition('c.user_id', $uid, '=')
        ->condition('c.community_id', $cid, '=')
        ->fields('c', ['id'])
        ->execute()->fetchField();

      if ($type == 'like') {
        $insert = [
          'user_id' => $uid,
          'community_id' => $cid,
          'like_num' => 0,
          'dislike_num' => 1,
        ];

        $update = [
          'like_num' => 0,
          'dislike_num' => 1,
        ];
      }
      elseif ($type == 'dislike') {
        $insert = [
          'user_id' => $uid,
          'community_id' => $cid,
          'like_num' => 1,
          'dislike_num' => 0,
        ];

        $update = [
          'like_num' => 1,
          'dislike_num' => 0,
        ];
      }

      if ($count > 0) {
        $result = $connection->update('community_like_dislike')
          ->fields($update)
          ->condition('community_id', $cid, '=')
          ->condition('user_id', $uid, '=')
          ->execute();

        $ldCount = CommonFunc::likeDislikeCount($cid);
      }
      else {

        $result = $connection->insert('community_like_dislike')
          ->fields($insert)
          ->execute();

        $ldCount = CommonFunc::likeDislikeCount($cid);
      }

      return new JsonResponse($ldCount);
    }
    /****** End like community section ajax *************/

    /************ Start Abused marking ****************/
     if (!empty($action) && $action == 'report_abuse') {
      $id = \Drupal::request()->request->get('id');
      $reported_user_id = CommonFunc::userId();
      $comment_data = Comment::load($id);
      $commenter_user_id = $comment_data->getOwnerId();
      $community_question_id = $comment_data->get('entity_id')->target_id;

      $database = \Drupal::database();
      $result = $database->insert('abuse_reports')
        ->fields([
          'ar_community_id' => $community_question_id,
          'ar_comment_id' => $id,
          'ar_commented_user_id' => $commenter_user_id,
          'ar_reporter_id' => $reported_user_id,
          'ar_created' => \Drupal::time()->getRequestTime(),
        ])
      ->execute();

      /** Check Counter */
      $arc_array = $database->select('abuse_reports_counter', 'arc')
        ->fields('arc', ['arc_counter'])
        ->condition('arc_comment_id', $id, '=')
        ->execute()->fetchObject();
      $abuse_count = $arc_array->arc_counter;
      if ($abuse_count) {
        /** Update Counter */
        $new_counter = $abuse_count + 1;
        $update = [
          'arc_counter' => $new_counter,
          'arc_updated' => \Drupal::time()->getRequestTime(),
        ];
        $result = $database->update('abuse_reports_counter')
          ->fields($update)
          ->condition('arc_comment_id', $id, '=')
        ->execute();
      }
      else {
        /** Insert new Counter */
        $result = $database->insert('abuse_reports_counter')
          ->fields([
            'arc_community_id' => $community_question_id,
            'arc_comment_id' => $id,
            'arc_commented_user_id' => $commenter_user_id,
            'arc_counter' => 1  ,
            'arc_updated' => \Drupal::time()->getRequestTime(),
            'arc_created' => \Drupal::time()->getRequestTime(),
          ])
        ->execute();
      }

      return new JsonResponse('reported');
    }
    /************ End Abused marking ****************/
	if (!empty($action) && $action == 'customMealData') {
		$mealTime = \Drupal::request()->request->get('mealTime');
		$date = \Drupal::request()->request->get('date');
		if (\Drupal::currentUser()->isAnonymous()) {
			$session = \Drupal::request()->getSession();
			$post_data = $session->get('meal_form_data');
			$post_data = CommonFunc::APiHindi($post_data);
			if($mealTime != '') {
            $timeslot = array("meal_name" => $mealTime);
            $post_data = array_merge($post_data, $timeslot);
            }
			$plan = NestleAPI::mealPlanNotLogin($post_data);
			
		} else {
			$client_key = CommonFunc::childField('field_child_key');
			$participation_key = CommonFunc::childField('field_participation_key');
			$today = CommonFunc::currentTime('d-m-Y');
			

			$post_data = [
			"client_key" => $client_key,
			"participation_key" => $participation_key,
			"from_date" => $today,
			"to_date" => $today,
			"meal_name" => $mealTime
			];
			$post_data = CommonFunc::APiHindi($post_data);
		
			$plan = NestleAPI::mealPlanLogin($post_data);
			
		}
		if ($plan['status'] == 'success') {
			$current_index = $plan['contents']['current_meal_index'];
			$gtm_array = $plan['contents']['gtm'];
			$current_meal = $plan['contents']['day_plans'][0]['meal_plans'][$current_index];
			$meal_nutrients = $plan['contents']['nutrients'];
			$consumed_nutrients = $plan['contents']['nutritional_values'];
			if (\Drupal::currentUser()->isAnonymous()) {
			 $meal_rda = $plan['contents']['entries'];
			} else {
			 $meal_rda = $plan['contents']['rda_entries'];
			}
			if ($hindi) {
			$not_found_content = 'इस समय के लिए नुस्खा नहीं मिला';
			}
			else {
			$not_found_content = 'Recipe not found for this timeslot';
			}
			if(!empty($current_meal['recipe_entries'])) {
			$selectedDateMeal['nutrients'] = CommonFunc::mealNutrient($meal_rda, $meal_nutrients, $consumed_nutrients);
			} else {
			
			$selectedDateMeal['nutrients'] = '';
			}
			
		}
		
		return new JsonResponse($selectedDateMeal);
	}
	// replace recipe code
	if (!empty($action) && $action == 'getAlternateFood') {
		$r_id = \Drupal::request()->request->get('r_id');
		$innerNutriId = \Drupal::request()->request->get('innerNutriId');
		$sngcount = \Drupal::request()->request->get('sngcount');
		$replaId = \Drupal::request()->request->get('replaId');
		$client_key = CommonFunc::childField('field_child_key');
		$post_data = [
			"client_key" => $client_key,
			"recipe_entry_id" => $r_id,
			"limit" => 5,
		];
		$post_data = CommonFunc::APiHindi($post_data);
		$plan = NestleAPI::getAlternateFood($post_data);
		$recipes1 = '';
		$hindi = CommonFunc::isHindi();
		if($hindi) {
			$notavailable = 'कोई वैकल्पिक भोजन उपलब्ध नहीं है';
		} else {
			$notavailable = 'No Alternative food available';
		}
		if ($plan['status'] == 'success' && $plan['contents'] != '') {
			if(!empty($plan['contents'])) {
			$nl = 0;
			foreach ($plan['contents'] as $recipe) {
             $recipes1 .= '<li data-repid="'.$innerNutriId.'" data-eng="'.$recipe['gtm']['recipe']['name'].'" data-e_id="' . $recipe['recipe_entry_id'] . '" data-r_id="' . $recipe['recipe_id'] . '"  data-setnutrID="' . $innerNutriId . '" data-sngcountnew="' . $sngcount . '" data-mkey="'.$replaId.'"><input type="radio" name ="as[]">' . $recipe['name'] . '</li>';
             $nl++;
            }
			
		   } else {
			 $recipes1 .= '<div data-repid="" data-eng="No alternative food available" data-e_id="no" data-r_id="no"  data-setnutrID="no" data-sngcountnew="no">'.$notavailable.'</div>';  
		   }
		} else {
			$recipes1 .= '<div data-repid="" data-eng="No alternative food available" data-e_id="no" data-r_id="no"  data-setnutrID="no" data-sngcountnew="no">'.$notavailable.'</div>';
		}
		
		return new JsonResponse($recipes1);
	}
	if (!empty($action) && $action == 'setAlternateFood') {
		$client_key = CommonFunc::childField('field_child_key');
		$e_id = \Drupal::request()->request->get('e_id');
        $r_id = \Drupal::request()->request->get('r_id');
		$replaId = \Drupal::request()->request->get('replaId');
		if ($hindi) {
			$short_url = "/hindi";
		}
		else {
			$short_url = "";
		}
		$post_data = [
			"client_key" => $client_key,
			"recipe_entry_id" => $e_id,
			"recipe_id" => $r_id,
        ];
		$post_data = CommonFunc::APiHindi($post_data);
		$replace_meal_label = 'Replace Meal';
        $see_recipe_label = 'See Recipe';
		if ($hindi) {
			$replace_meal_label = 'इस भोजन को बदलें';
			$see_recipe_label = 'नुस्खा देखें';
			$mins = ' मिनट';
      $cur_lang = 'hi';
        } else {
			$mins = ' mins';
      $cur_lang = 'en';
		}
		$plan = NestleAPI::replaceFoodItem($post_data);
		if ($plan['status'] == 'success') {
      $plan['recipeMetadata'] = CommonFunc::getRecipeMetaDataBySeoName($plan['contents']['seo_name'])['recipeMetadata'];
    $plan['fav'] = CommonFunc::getRecipeFavlikeDislike($plan['contents']['seo_name'], $cur_lang);
    $plan['gRating'] = CommonFunc::getRecipeRatingBySeo($plan['contents']['seo_name'], $cur_lang);
      if($plan['fav']=='like'){
        $likeClass = '';
        $likeAttr = 'like';
      }else{
        $likeClass = 'active-like';
        $likeAttr = 'dislike';
      }
      if($plan['gRating'] != 0.0){
        $rate = '<div class="rvw"><em></em>'.$plan['gRating'].'</div>';
      }else{
        $rate = '<div class="rvw"><em></em>'.t('No rate').'</div>';
      }

      $like_html= '<div class="like '.$likeClass.' favBtn" id="favBtn" data-fav="'.$likeAttr.'" data-recipeid="'.$plan['recipeMetadata']['id'].'" data-recipeseoname="'.$plan['contents']['seo_name'].'" data-recipeseoalternatename="'.$plan['recipeMetadata']['seo_alt_name'].'" data-value="'.$plan['contents']['seo_name'].'" data-hindiname = "'.$plan['recipeMetadata']['hindi_name'].'" data-engname = "'.$plan['recipeMetadata']['eng_name'].'" data-target="card"></div>';
			$mealRecipe = '<div class="item '.$plan['contents']['veg_nonveg'].'" id="'.$plan['contents']['id'].'">
			               <div class="cardscmn2">
			                <div class="imgWrp">
					        <a href="' . $base_url . $short_url . '/recipes/' . $plan['contents']['seo_name'] . '">
					         <img src="'.$plan['contents']['round_images'].'" alt="'.$plan['contents']['name'].'" width="1" height="1">
					        </a>
					        </div>
							<div class="txtb">
                        <a href="' . $base_url . $short_url . '/recipes/' . $plan['contents']['seo_name'] . '">
						 <h3>'.$plan['contents']['name'].'</h3>
						</a> 
                        <p>'.$plan['contents']['trivia'].'</p>
                        <ul class="list1">
                          <li><em><img src="/themes/custom/nestle_new/common/images/icon-fire.svg" alt="fire" width="1" height="1"></em> '.$plan['contents']['aggregated_nutrients'][34].' calories</li>
                          <li><em><img src="/themes/custom/nestle_new/images/icon-time.svg" alt="time" width="1" height="1"></em> '.$plan['contents']['time_to_cook'].' '.$mins.'</li>
                        </ul>
                        <div class="tagbox">
						</div>
                      </div>
					    <div class="crdsFtr">
                      <div class="vn-tag-rvw">
                      <div class="veg-nveg-mark"><i class="veg-icon"></i></div>
                      '.$rate.'
                      </div>
                      '.$like_html.'
                    </div> 
                      <ul class="seereplace"> 
            <li> 
              <div class="mlsee">
              <a href="' . $base_url . $short_url . '/recipes/' . $plan['contents']['seo_name'] . '" class="nLink"> See Recipe </a>
              </div> 
            </li>
            <li> 
              <div class="meal-refresh nLink" data-mkey="'.$replaId.'" data-rid="'.$plan['contents']['id'].'" data-id="'.$plan['contents']['recipe_entry_id'].'" data-sngcount="">Replace Meal</div> 
            </li>
          </ul>
			               </div>
						  </div> 
						   ';
		} else {
			$mealRecipe ='';
		}
		return new JsonResponse($mealRecipe);
	}
  }

}
