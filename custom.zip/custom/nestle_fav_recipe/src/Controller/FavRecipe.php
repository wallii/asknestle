<?php

namespace Drupal\nestle_fav_recipe\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\file\Entity\File;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\Response;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\comment\Entity\Comment;
use Drupal\Core\Language\LanguageManager;
use Drupal\Component\Utility\Xss;
use Symfony\Component\HttpFoundation\Request;
use Drupal\nestle_recipe\Controller\Recipes;

/**
 * Returns responses for Fav recipes routes.
 */
class FavRecipe extends ControllerBase {

  public function listing() {
    $recipedetailsd = new Recipes;

    if(isset($_GET['created_on']) && $_GET['created_on'] == 'latest'){
      $sortingParam = 'id';
    }else{
      $sortingParam = 'recipe_seo_name';
    }
    if(isset($_GET['rid']) && !empty($_GET['rid'])){
      $searchKey = $_GET['rid'];
    }else{
      $searchKey ='';
    }
    \Drupal::service('page_cache_kill_switch')->trigger();
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    $hindiLang = CommonFunc::isHindi();
    $dataValue = array();
    $pageNo = 1;
    $pagerRow = $pageNo*6-6;
    if($hindiLang == 'hi'){
    $favRecipesTotalCount = $connection->select('nestle_fav_recipe_data', 't')
      ->condition('t.uid', $uid, '=')
      ->condition('t.recipe_hindi_name', '%'.$searchKey.'%', 'LIKE')
      ->fields('t', ['id'])
      ->execute()->fetchAll();
    }else{
       $favRecipesTotalCount = $connection->select('nestle_fav_recipe_data', 't')
      ->condition('t.uid', $uid, '=')
      ->condition('t.recipe_eng_name', '%'.$searchKey.'%', 'LIKE')
      ->fields('t', ['id'])
      ->execute()->fetchAll();
    }
    $favRecipesTotalCount = sizeof($favRecipesTotalCount);
    if($hindiLang == 'hi'){
      $favRecipes = $connection->select('nestle_fav_recipe_data', 't')
      ->condition('t.uid', $uid, '=')
      ->condition('t.recipe_hindi_name', '%'.$searchKey.'%', 'LIKE')
      ->range($pagerRow, 6)
      ->orderBy($sortingParam, 'DESC')
      ->fields('t', ['recipe_alter_seo_name','created_on'])
      ->execute()->fetchAll();

      foreach ($favRecipes as $key => $value) {
         $recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_alter_seo_name);
         $dataValue[$key] = $recipeMetaData;
         $dataValue[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_alter_seo_name, 'hi');
         $dataValue[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value->recipe_alter_seo_name, 'hi');
		 $dataValue[$key]['created_on'] = date('d M Y', $value->created_on);
      }
    }else{
      $favRecipes = $connection->select('nestle_fav_recipe_data', 't')
        ->condition('t.uid', $uid, '=')
        ->condition('t.recipe_eng_name', '%'.$searchKey.'%', 'LIKE')
        ->orderBy($sortingParam, 'DESC')
        ->range($pagerRow, 6)
        ->fields('t', ['recipe_seo_name','created_on'])
        ->execute()->fetchAll();
      foreach ($favRecipes as $key => $value) {
         $recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_seo_name);
         $dataValue[$key] = $recipeMetaData;
         $dataValue[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_seo_name, 'en');
         $dataValue[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value->recipe_seo_name, 'en');
		 $dataValue[$key]['created_on'] = date('d M Y', $value->created_on);

      }
    }
    return [
      '#theme' => 'favRecipesListing',
      '#recipes' => $dataValue,
      '#rCount' => $favRecipesTotalCount
    ];
  }

  /**
  * Fav Search Loadmore Function
  */
  public function FavRecipeLoadMore(Request $request) {    
    global $base_url;
    $recipedetailsd = new Recipes;
    $uid = CommonFunc::userId();
    $connection = \Drupal::database();
    $urlParam = strip_tags($request->query->get('param'));
    $urlParamRid = strip_tags($request->query->get('urlparamStringRid'));
    if(!empty($urlParam) && $urlParam == 'latest'){
      $sortingParam = 'id';
    }else{
      $sortingParam = 'recipe_seo_name';
    }
    if(!empty($urlParamRid)){
      $urlParamRid = $urlParamRid;
    }else{
      $urlParamRid = '';
    }
    $langCode = strip_tags($request->query->get('lang'));
    \Drupal::service('page_cache_kill_switch')->trigger();
    //$searchData = strip_tags($request->query->get('searchData'));
    $pageNo = strip_tags($request->query->get('pageNo'));
    $pagerRow = $pageNo*6-6;
    if($langCode == 'hi'){
       $shorturl ="/hindi";
      $favRecipes = $connection->select('nestle_fav_recipe_data', 't')
      ->condition('t.uid', $uid, '=')
      ->condition('t.recipe_hindi_name', '%'.$urlParamRid.'%', 'LIKE')
      ->range($pagerRow, 6)
      ->orderBy($sortingParam, 'DESC')
      ->fields('t', ['recipe_alter_seo_name','created_on'])
      ->execute()->fetchAll();
      foreach ($favRecipes as $key => $value) {
        $recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_alter_seo_name);
        $dataValue[$key] = $recipeMetaData;
        $dataValue[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_alter_seo_name, 'hi');
        $dataValue[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value->recipe_alter_seo_name, 'hi');
		$dataValue[$key]['created_on'] = date('d M Y', $value->created_on);

        }
    }else{
      $shorturl ="";
      $favRecipes = $connection->select('nestle_fav_recipe_data', 't')
        ->condition('t.uid', $uid, '=')
        ->condition('t.recipe_eng_name', '%'.$urlParamRid.'%', 'LIKE')
        ->orderBy($sortingParam, 'DESC')
        ->range($pagerRow, 6)
        ->fields('t', ['recipe_seo_name','created_on'])
        ->execute()->fetchAll();
      foreach ($favRecipes as $key => $value) {
        $recipeMetaData = CommonFunc::getRecipeMetaDataBySeoName($value->recipe_seo_name);
        $dataValue[$key] = $recipeMetaData;
        $dataValue[$key]['fav'] = CommonFunc::getRecipeFavlikeDislike($value->recipe_seo_name, 'en');
        $dataValue[$key]['gRating'] = CommonFunc::getRecipeRatingBySeo($value->recipe_seo_name, 'en');
		$dataValue[$key]['created_on'] = date('d M Y', $value->created_on);
      }
    }
    $html= '';
      $list = $dataValue;
      foreach($list as $recipes) {
        if($recipes['fav']=='like'){
          $likeClass = '';
          $likeAttr = 'like';
        }else{
          $likeClass = 'active-like';
          $likeAttr = 'dislike';
        }
		
		if($recipes['tags'][0]['global_tags'] != "NA") {
					$globalTagarr = explode("@",$globalTag);
					$globalTagarrff = '';
					foreach($globalTagarr as $tagfVal) {
						if($tagfVal !='') {
						 $globalTagarrff .='<span>'.$tagfVal.'</span>';
						}
						
					}
		} else {
					$globalTagarrff = '';
		}
		
		if($langCode == 'hi'){
			$mins = ' मिनट';
            $cals ='कैलोरी';
			$serving ='सर्विंग्स';
		} else {
			$mins = ' mins';
            $cals ='calories';
			$serving ='Servings';
		}
		
		
        if($recipes['gRating'] != 0.0){
          $rate = '<div class="rvw"><em></em>'.$recipes['gRating'].'</div>';
        }else{
          $rate = '<div class="rvw"><em></em>'.t('No rate').'</div>';
        }

        $html .= ' <div class="item">
                    <div class="cardscmn2">
          
                      <div class="imgWrp">
             <a href="'.$base_url.$shorturl.'/recipes/'.$recipes['seo_name'].'">
             <img src="'.$recipes['round_images'].'" alt="'.$recipes['name'].'" width="1" height="1">
             </div>
                      <div class="txtb">
              <a href="'.$base_url.$shorturl.'/recipes/'.$recipes['seo_name'].'">
                        <h3>'.$recipes['name'].'</h3>
            </a>
                        <p>'.$recipes['trivia'].'</p>
                        <ul class="list1">
                          <li><em><img src="/themes/custom/nestle_new/common/images/icon-fire.svg" alt="calories" width="1" height="1"></em> '.$recipes['recipeMetadata']['calories'].' '.$cals.'</li>
                          <li><em><img src="/themes/custom/nestle_new/common/images/icon-time.svg" alt="mins" width="1" height="1"></em> '.$recipes['time_to_cook'].' '.$mins.'</li>
						  <li><em><img src="/themes/custom/nestle_new/common/images/icon-profile.svg" alt="serving" width="1" height="1"></em> '.$recipes['no_of_servings'].' '.$serving.'</li>
                        </ul>
                        <div class="tagbox">'.$globalTagarrff.'</div>
            
            </div>
                      <div class="crdsFtr">
                        <div class="vn-tag-rvw">
                          <div class="veg-nveg-mark"><i class="veg-icon"></i></div>
                          '.$rate.'
                        </div>
						<div>
					  Saved on '.$recipes['created_on'].'
					  </div>
                        <div class="like '.$likeClass.' favBtn" id="favBtn" data-fav="'.$likeAttr.'" data-recipeid="'.$recipes['id'].'" data-recipeseoname="'.$recipes['seo_name'].'" data-recipeseoalternatename="'.$recipes['seo_name_alternate'].'" data-value="'.$recipes['seo_name'].'" data-hindiname = "'.$recipes['recipeMetadata']['hindi_name'].'" data-engname = "'.$recipes['recipeMetadata']['eng_name'].'" data-target="card"></div>
                    </div>
                      </div>
                    </div>
                </div>';
      }
    return new JsonResponse($html);
  }
  
}
