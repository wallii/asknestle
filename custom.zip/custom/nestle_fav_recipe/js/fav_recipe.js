(function ($, Drupal) {
  'use strict';
  function setLikeDislike(selector, action, target){
      var $this = selector;
      var recipeId= $this.attr('data-recipeid');
       var recipeHindiName = $this.attr('data-hindiname');
       var recipeEngName = $this.attr('data-engname');
        var lang = drupalSettings.language;
        if (lang == "hi") {
          var short_url ="hindi/";
          var recipeAltSeoName = $this.attr('data-recipeseoalternatename');
          var recipeSeoName= $this.attr('data-recipeseoname');
        } 
        else {
          var recipeSeoName= $this.attr('data-recipeseoname');
          var recipeAltSeoName= $this.attr('data-recipeseoalternatename');
            var short_url = "";
        }
      $.ajax({
        url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
        type: 'post',
        cache: false,
        data: {
          "action": "saveFavRecipe",
          "id": recipeId,
          "recipeAction": action,
          "recipeSeoName": recipeSeoName,
          "recipeAltSeoName": recipeAltSeoName,
          "recipeHindiName": recipeHindiName,
          "recipeEngName": recipeEngName,
          "lang": lang
        },
        success: function (response) {
          console.log(response);
          //console.log(recipeHindiName);
          if(response == 'added' && target == 'detail'){
            $('#favBtn').attr('data-fav', 'dislike');
            $('#favBtn').addClass('active-like-btn');
          }else if (response == 'removed' && target == 'detail'){
            $('#favBtn').attr('data-fav', 'like');
            $('#favBtn').removeClass('active-like-btn');
          }else if (response == 'added' && target == 'card'){
             $this.attr('data-fav', 'dislike');
             $this.addClass('active-like');
          }
          else if (response == 'removed' && target == 'card'){
             $this.attr('data-fav', 'like');
             $this.removeClass('active-like');
          }
        }
        });
     }

    $(document).on('click', '.favBtn', function () {
      var target = $(this).attr('data-target');
      if($(this).attr('data-fav') == 'like'){
        var action = 'add';
       }else{
        var action ='remove';
       }
       var $this = $(this);
       setLikeDislike($this, action, target);
    });

})(jQuery, Drupal);
