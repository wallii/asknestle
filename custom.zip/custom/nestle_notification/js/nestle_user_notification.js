(function ($, Drupal) {
	Drupal.behaviors.recipeSearchlanguageswitch = {
		attach: function (context) {
			
		$('div.contextual').filter(function(){
		return $(this).attr('data-contextual-id') == 'block:block=nestle_new_mainnavigation_2:langcode=en|menu:menu=main:langcode=en';
		}).hide();
		$('div.contextual').filter(function(){
		return $(this).attr('data-contextual-id') == 'block:block=notificationblock:langcode=hi';
		}).hide();
		$('div.contextual').filter(function(){
		return $(this).attr('data-contextual-id') == 'block:block=notificationblock:langcode=hi';
		}).hide();


		}
	};




})(jQuery, Drupal);
