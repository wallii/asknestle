<?php

namespace Drupal\nestle_notification\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\nestle_notification\Controller\NestleNotification;

/**
 * @Block(
 *   id = "login_user_notification_block",
 *   admin_label = @Translation("Notification Block"),
 *   category = @Translation("Login user Custom Notification Block")
 * )
 */
 
class NotificationBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
	  
	# registerd user notification
	# Notification type
	# 1.	New Article addition 
	# 2.	Update your vitals – every 30 days
	# 3.	Food diary – if no entry in 5 days 
	# start date : 13-12-2022
	# data come from Custom Module: nestle_notification
	# controller Name : NestleNotification
    $notification = new NestleNotification;
	$loginUserNotification = $notification->getNotification();
	return $loginUserNotification;


  }
}