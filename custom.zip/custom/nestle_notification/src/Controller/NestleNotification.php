<?php

namespace Drupal\nestle_notification\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;

/**
 * This class is used to retrive data login user notification.
 */
class NestleNotification extends ControllerBase {
	
	public function getNotification() {
		
		global $base_url;
		$connection = \Drupal::database();
		$data = array();	
	    $data['hindi'] = CommonFunc::isHindi();
		$data['counter'] = 0;
		$uid = CommonFunc::userId();
		$user = User::load($uid);
		$user_name = $user->get('name')->value;
		$current_time = \Drupal::time()->getCurrentTime();
		$date_output = date('d-m-Y H:i:s', $current_time); 
		$html = '';
		$child_id = CommonFunc::childField('field_child_key');
		$field_participation_key = CommonFunc::childField('field_participation_key');
		$selectedDate = date("d-m-Y");
		# - minus five day from current date
		$fromdate = date('d-m-Y', strtotime('-5 days'));
		$post_data = [
		'client_key' => $child_id,
		'participation_key' => $field_participation_key,
		'from_date' => $fromdate,
		'to_date' => $selectedDate,
		];
		
		$post_data = CommonFunc::APiHindi($post_data);
		$retrieveFoodMeal = NestleAPI::retrieveFoodEntry($post_data);
		if($data['hindi']) {
			$baseurl = $base_url . '/hindi/';
		} else {
			$baseurl = $base_url . '/';
		}
		# enity iD : 1 for article , 2 for food diary , 3 for Votal
		
		# Budle : FoodDiary , Votal , Article
		if($retrieveFoodMeal['status'] == 'success') {
			if(empty($retrieveFoodMeal['contents']['meal_entries'])) {
				
				$chetFoodNoti = $connection->select('nestle_notifications', 'nt')
			                ->condition('nt.entity_uid', $uid, '=')
							->condition('nt.bundle', 'FoodDiary', '=')
							->orderBy('nt.id', "DESC")
							->fields('nt', ['created_on','action','id'])
							->range(0,1)
							->execute()->fetchAll();
				if(!empty($chetFoodNoti)) {
					
					if($chetFoodNoti[0]->action =='Create') {
						$data['counter']++;
                        $data['fooddiary'] = ' <div class="item">
					<p class="title"><a href="'.$baseurl.'food-diary/get-food-nutrients?notification='.$chetFoodNoti[0]->id.'">Please update you meals in food diary</a></p>
					<p class="subtitle">Not updated your food diary From '.$fromdate.' to '.$selectedDate.'</p>

					</div>';						
					} else {
						$data['fooddiary'] = ' <div class="item">
					<p class="title"><a href="'.$baseurl.'food-diary/get-food-nutrients?notification=" style="color:#d8dad9;">Please update you meals in food diary</a></p>
					<p class="subtitle" style="color:#d8dad9;">Not updated your food diary From '.$fromdate.' to '.$selectedDate.'</p>

					</div>';			
					}
					
					
					
				}  else {
					$data['fooddiary'] = '';
				}			
					  
			} else {
				$data['fooddiary'] = '';
			}
			
		}
		# Get Vital Notification
		$vitals = NestleAPI::showVitals();
		$data['Vital'] = '';
		if ($vitals != 0) {
			$keys = array_keys($vitals);
			$lastUpdateDate = date('Y-d-m',strtotime($keys[0]));
			if($lastUpdateDate < strtotime('-30 days')) {
				$getVitalNoti = $connection->select('nestle_notifications', 'nt')
			                    ->condition('nt.entity_uid', $uid, '=')
							    ->condition('nt.bundle', 'Vital', '=')
							    ->orderBy('nt.id', "DESC")
							    ->fields('nt', ['created_on','action','id'])
							    ->range(0,1)
							    ->execute()->fetchAll();
				if(!empty($getVitalNoti)) {
				  if($getVitalNoti[0]->action =='Create') {
					  
					  $data['counter']++;
                      $data['Vital'] = ' <div class="item">
					<p class="title"><a href="'.$baseurl.'growth-track/update-vital?notification='.$getVitalNoti[0]->id.'">Please update your vitals</a></p>
					<p class="subtitle">Last updated date '.$keys[0].'</p>

					</div>';
					  
				  } else {
					 
                    $data['Vital'] = ' <div class="item">
					<p class="title"><a href="'.$baseurl.'growth-track/update-vital?notification=" style="color:#d8dad9;">Please update your vitals</a></p>
					<p class="subtitle" style="color:#d8dad9;">Last updated date '.$keys[0].'</p>

					</div>';					 
					  
				  }
					
				} 				
				
			}
		}
		# Get Article Notification
		
		$GetArticleNotif = $connection->select('nestle_notifications', 'na')
			                ->condition('na.entity_uid', $uid, '=')
							->condition('na.bundle', 'Article', '=')
							->orderBy('na.id', "DESC")
							->fields('na', ['created_on','action','id','entity_id'])
							->range(0,2)
							->execute()->fetchAll();
		$data['Article'] = '';					
		if(!empty($GetArticleNotif)) {
			
			foreach($GetArticleNotif as $artNoti) {
				
			$Pathalias = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$artNoti->entity_id);
			if($artNoti->action =='Create') {
				$data['counter']++;
				$data['Article'] .= ' <div class="item">
					<p class="title"><a href="'.$baseurl.ltrim($Pathalias, '/').'?notification='.$artNoti->id.'">There is a new article added, please click to check</a></p>
					<p class="subtitle">Notification Date '.$selectedDate.'</p>

					</div>';		
				
			} else {
				
				$data['Article'] .= ' <div class="item">
					<p class="title"><a href="'.$baseurl.ltrim($Pathalias, '/').'?notification=" style="color:#d8dad9;">There is a new article added, please click to check</a></p>
					<p class="subtitle" style="color:#d8dad9;">Notification Date '.$selectedDate.'</p>

					</div>';	
				
			}
			
			
		    }
		} else {
			$data['Article'] = '';
		}

        //echo "<pre>";
        //print_r($data['Article']); die;		
		
		
		return [
			'#theme' => 'LoginCustomNotification',
			'#params' => $data,
			'#attached' => [
				'library' => 'nestle_notification/user_notification_javascript',
			]
		];
	}
	
	public function NotificationList() {
	global $base_url;
	
	$uid = CommonFunc::userId();
	$connection = \Drupal::database();
	$field_participation_key = CommonFunc::childField('field_participation_key');
	$uid = CommonFunc::userId();
	$user = User::load($uid);
	$user_name = $user->get('name')->value;
	$current_time = \Drupal::time()->getCurrentTime();
	$data = array();	
	/*
	$chetFoodNoti = $connection->select('nestle_notifications', 'nt')
			                ->condition('nt.entity_uid', $uid, '=')
							->condition('nt.bundle', 'FoodDiary', '=')
							->orderBy('nt.id', "DESC")
							->fields('nt', ['created','action','id'])
							->range(0,1)
							->execute()->fetchAll();
			echo "<pre>";
			print_r($chetFoodNoti);
			
            die;
         		
	      $data = array();	
		*/
		/*
		$current_path = \Drupal::service('path.current')->getPath();
		$current_uri = \Drupal::request()->getRequestUri();
		$uid = \Drupal::request()->query->get('notification');
		echo "hello";
		echo "</br>";
		echo $uid;
		die;
		*/
		// get today all created node
		
		/*
		$asd['first'] = mktime(0, 0, 0,date('m'),date('d'),date('Y'));
        $asd['last'] = mktime(23, 59, 59, date('m'),date('d'),date('Y'));
		$query = \Drupal::entityQuery('node')
                 ->condition('type', 'expert_advice')
                 ->condition('status', 1)
                 ->sort('created', 'DESC')
                 ->condition('created.value', $asd['first'], '>=')
                 ->condition('created.value', $asd['last'], '<=');
        $result_nids = $query->execute();
		if(!empty($result_nids)) {
			$queryArt = $connection->insert('nestle_notifications');
			
			foreach($result_nids as $redd) {
			  # check if NID already added
               $chetFoodNotiw = $connection->select('nestle_notifications', 'nt1')
								->condition('nt1.entity_uid', $uid, '=')
								->condition('nt1.bundle', 'Article', '=')
								->condition('nt1.entity_id', $redd, '=')
								->fields('nt1', ['entity_id'])
								->range(0,1)
								->execute()->fetchAll();
				
              if($redd != $chetFoodNotiw[0]->entity_id) {

                  $insertart = [
					'entity_id' => $redd,
					'entity_uid' =>$uid,
					'action' => 'Create',
					'bundle' => 'FoodDiary',
					'uid' => $field_participation_key,
					'user_name' => $user_name,
					'message' => 'Please update you meals in food diary',
					'status' => 0,
					'created_on' => $current_time,
					'updated_on' => $current_time,
					];
					
					$result = $connection->insert('nestle_notifications')
							  ->fields($insertart)
							  ->execute();				  
			  
			  }
					
			}
			
			
		}
		*/
		
		
		 		
		return [
			'#theme' => 'notificationlist',
			'#params' => $data,
			'#attached' => [
				'library' => 'nestle_notification/user_notification_javascript',
			]
		];
	}

  
}
