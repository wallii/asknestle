(function ($, Drupal) {
  'use strict';
 Drupal.behaviors.triedrecipe = {
    attach: function (context, settings) {
      //CLick on tried recipe check box
     $('#triedBoxCheckbox', context).on('click', '.checkmark', function () {
       if($('#tried_recipe').prop('checked') == false){
        var action = 'add';
       }else{
        var action ='remove';
       }
       var recipeId= $("#tried_recipe").attr('data-recipeid');
       var recipeHindiName = $("#tried_recipe").attr('data-hindiname');
       var recipeEngName = $("#tried_recipe").attr('data-engname');
        var lang = drupalSettings.language;
        if (lang == "hi") {
          var short_url ="hindi/";
          var recipeAltSeoName = $("#tried_recipe").attr('data-recipeseoname');
          var recipeSeoName= $("#tried_recipe").attr('data-recipeseoalternatename');
        } 
        else {
          var recipeSeoName= $("#tried_recipe").attr('data-recipeseoname');
          var recipeAltSeoName= $("#tried_recipe").attr('data-recipeseoalternatename');
            var short_url = "";
        }
        $.ajax({
        url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
        type: 'post',
        cache: false,
        data: {
        "action": "saveTriedRecipe",
        "id": recipeId,
        "recipeAction": action,
        "recipeSeoName": recipeSeoName,
        "recipeAltSeoName": recipeAltSeoName,
        "recipeHindiName": recipeHindiName,
        "recipeEngName": recipeEngName,
        "lang": lang
        },
        success: function (response) {
          console.log('response'+response);
        }
        });

      });
    }
  };
})(jQuery, Drupal);
