<?php

namespace Drupal\nestle_immunity\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\nestle_api\Controller\NestleAPI;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\Core\Language\LanguageManager;
/**
 * Configure Immunity settings for this site.
 */
class ImmunityDataBoardForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'immunity_data';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    /**** Start get immunity config page data *****/
  $page_config = array();
  $page_config ['disclaimer'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_disclaimer');
  $page_config ['gender_text'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_choose_form_gender_text');
  $page_config ['btn_text'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_button_text');
  /**** End get immunity config page data *****/
  global $base_url;
  $hindi = CommonFunc::isHindi();
  if($hindi){
  $contentcta = "मैं अपने बच्चे की इम्यूनिटी के बारे में जानने के लिए तैयार हूं";
  }else{
  $contentcta ="I’m ready to see my child’s immunity";
  //$content = CommonFunc::getCmsContent('field_immunity_button_text');
  $content = "I’m ready to see my child Immunity static";
  //$content = "Click Here to see your child immunity scale";
  }
  /*$immunity_label = CommonFunc::getCmsContent('field_immunity_label');
  $immunity_description = CommonFunc::getCmsContent('field_immunity_description');
  $immunity_button_text = CommonFunc::getCmsContent('field_immunity_button_text');*/
  $immunity_label = 'Label';
  $immunity_description = 'Description';
  $immunity_button_text = 'button_text';
  $theme = \Drupal::theme()->getActiveTheme();
  $form['dobYr'] = [
  '#type' => 'number',
  '#attributes' => array('class' => array('input-filed'), 'id' => array('vital_dobYr') ,'autocomplete' => array('off')),
  '#placeholder' => 'Eg. 2',
  '#min' => 2,
  '#max' => 12,
  '#required' =>TRUE
  ];

  $form['dobMth'] = [
  '#type' => 'number',
  '#attributes' => array('class' => array('input-filed'), 'id' => array('vital_dobMth') ,'autocomplete' => array('off')),
  '#default_value' => 0,
  '#placeholder' => 'Eg. 1',
  '#min' => 0,
  '#max' => 11,
  '#required' =>TRUE
  ];


  $options = [
  '1' => t('Male'),
  '2' => t('Female'),
  '3' => t('Nonbinary'),
  ];
  $form['gender'] = [
  '#type' => 'radios',
  '#options' => $options,
  '#default_value' => 1,
  ];

  $form['submit'] = [
  '#type' => 'html_tag',
  '#tag' => 'input',
  '#attributes' => array('type' => array('button'), 'class' => array('primary-button'), 'id' => array('get_immunity_datan'), 'value' => $page_config ['btn_text']),
  ];
  //kint($page_config);
  //die();
  $form['#hindi'] = $hindi;
  $form['#immunity_data'] = $page_config;
  //$form['#immunity_description'] = $immunity_description;
  $form['#theme'] = 'immunityFormBoard';
  $form['#attached']['library'][] = 'nestle_immunity/immunity_score';
  return $form;
  }

 
   
  /**
   * {@inheritdoc}
   */
    public function submitForm (array &$form, FormStateInterface $form_state) {
		

        $dobYr = $form_state->getValue('dobYr');
        $dobMth = $form_state->getValue('dobMth');
        $gender = $form_state->getValue('gender');
        $childAge = $dobYr.".". $dobMth;

      $post_data = [
      'age' => $childAge,
      'gender_id' => $gender,
      ];
      
      $getImmunityClient = NestleAPI::CreateImmunityEntry($post_data);

      $clientImmunityKey = $getImmunityClient['contents']['client_data']['client_key'];

      $participationKey = $getImmunityClient['contents']['client_data']['participation_id'];

      $growth_data = [
      'immunityAge' => $childAge,
      'immunityClientk' => $clientImmunityKey,
      'immunityparticipationK' => $participationKey,
      'immunityGender' => $gender,
      ];

        $session = \Drupal::request()->getSession();
        $session->set('immunityData', $growth_data);

      $form_state->setRedirect('immunity.get_food_nutrients');
  }
}
