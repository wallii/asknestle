<?php

namespace Drupal\nestle_immunity\Controller;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\taxonomy\Entity\Term;
use Drupal\image\Entity\ImageStyle;
use Drupal\nestle_common\Controller\CommonFunc;

/**
 * This class have all common functions which are using in the CMS.
 */
class CommonDiary extends ControllerBase {

  /**
   * Get Post food Meal DOM Data.
   */
  public static function immunityScoreDom($SavedDataArr) {
		
		$hindi = CommonFunc::isHindi();

      if ($hindi) {
      $update = 'मील अपडेट करें';
      $add= 'मील आइटम जोड़ें';
      $search_food='भोजन खोजो';
      $serving_unit='सर्विंग यूनिट';
    } 
    else {
       $update = 'Update Meal Item';
      $add= 'Add Meal Item';
      $search_food='Search Food Items';
      $serving_unit='Serving Unit';
    }
    
    
  $meal_term = '';
    $countslotRecipe = 0;
    if(count($SavedDataArr) > 0){
		
		

      foreach ($SavedDataArr['contents']['analysis'] as $key => $value) {
		 
        $mealname= $value['name'];
         
         $quantity= $value['quantity'];

         $selected_unit= $value['selected_unit']['name'];


        $selected_unit = $value['selected_unit'];
        $food_entry_id = $value['food_entry_id'];

        $optionUnit = '';

        foreach ($value['serving_units'] as $keyunit => $valueunit) {


          if ($selected_unit['id'] == $valueunit['id']) {

            $optionUnit .= '<option data-eng="'.$valueunit['key'].'" value="' . $valueunit['id'] . '" selected>' . $valueunit['name'] . '</option>';
          }
          else {

            $optionUnit .= '<option data-eng="'.$valueunit['key'].'" value="' . $valueunit['id'] . '">' . $valueunit['name'] . '</option>';
          }
        }

         $meal_term .= '<div class="food-dairy-form" id="immunityRepID_' . $key . '"><div class="grp search"><input type="text" placeholder="'. $search_food .'" name= "search_meal_frm_' . $key . '" value="'.$mealname.'" id="search_meal_frm_' . $key . '" data-key="' . $key . '" class ="search_meal_cls" readonly>
                    <input type="hidden" placeholder="'. $search_food .'" name= "search_meal_frm_alt_' . $key . '" value="' . $food_entry_id . '" id="search_meal_frm_alt_' . $key . '" class ="" >
                    <input type="hidden" placeholder="'. $search_food .'" name= "fd_time_val_' . $key . '" value="' . $key . '" id="fd_time_val_' . $key . '" class ="" >
                    </div>
                   <div class="fd_btn_pst_del" id="fd_btn_pst_del_' . $key . '"><i class="fa fa-trash" aria-hidden="true"></i></div>
                    <div class="grp qty"> 
										<div class="qt minus">-</div>
                        <input type="text" value="'.$quantity.'" class="food-qty"  id="food_qty_' . $key . '" readonly>
												<div class="qt plus">+</div>
                    </div>
                    <div class="grp select">
                        <select class="unit_' . $key . '" name="unit_' . $key . '" id="unit_' . $key . '"> ' . $optionUnit . '</select></div>
													<div class="fd-btn">
                        <input type="button" value="'.$update.'" id="fd_btn_pst_' . $key . '" class="fd_btn_clk_pst">
                    </div>
												</div>';

                    $countslotRecipe++;
					
          }
		 

    }

    
    $meal_term .= '<div class="food-dairy-form" id="immunityRepID_' . $countslotRecipe . '"><div class="grp search"><input type="text" placeholder="'. $search_food .'" name= "search_meal_frm_' . $countslotRecipe . '" value="" id="search_meal_frm_' . $countslotRecipe . '" data-key="' . $countslotRecipe . '" class ="search_meal_cls"  >
                    <input type="hidden" placeholder="'. $search_food .'" name= "search_meal_frm_alt_' . $countslotRecipe . '" value="' . $countslotRecipe . '" id="search_meal_frm_alt_' . $countslotRecipe . '" class ="" >
                    <input type="hidden" placeholder="'. $search_food .'" name= "fd_time_val_' . $countslotRecipe . '" value="' . $countslotRecipe . '" id="fd_time_val_' . $countslotRecipe . '" class ="" >
                    </div>
										
                     <div class="replacesearchData_' . $countslotRecipe . ' replaceslist"></div>
                    <div class="grp qty">
                        <div class="qt minus">-</div>
                        <input type="text" value="0" class="food-qty"  id="food_qty_' . $countslotRecipe . '" readonly>
                        <div class="qt plus">+</div>
                    </div>
                    <div class="grp select">
                        <select class="unit_' . $countslotRecipe . '" name="unit_' . $countslotRecipe . '" id="unit_' . $countslotRecipe . '"> <option value="0">' . $serving_unit . '</option></select>                       
                    </div> <div id="replacesearchDatanew_' . $countslotRecipe . ' replaceslist"></div>
                    <div class="fd-btn">
                        <input type="button" value="'. $add .'" id="fd_btn_' . $countslotRecipe . '" class="fd_btn_clk">
                    </div></div>';

    return $meal_term;
  }



public static function immunityUpdateDom($SavedDataArr, $fd_timeslt_val) {

/*
 echo "<pre>";

 print_r($SavedDataArr);

 exit;*/
    
    $hindi = CommonFunc::isHindi();

      if ($hindi) {
      $update = 'मील अपडेट करें';
      $add= 'मील आइटम जोड़ें';
      $search_food='भोजन खोजो';
      $serving_unit='सर्विंग यूनिट';
    } 
    else {
       $update = 'Update Meal Item';
      $add= 'Add Meal Item';
      $search_food='Search Food';
      $serving_unit='Serving Unit';
    }
    
    
  $meal_term = '';
    $countslotRecipe = 0;

    if(count($SavedDataArr) > 0){

     // foreach ($SavedDataArr as  $SavedDataArr) {

        $mealname= $SavedDataArr['name'];

         $quantity= $SavedDataArr['quantity'];

         $selected_unit= $SavedDataArr['selected_unit']['name'];


        $selected_unit = $SavedDataArr['selected_unit'];
        $food_entry_id = $SavedDataArr['food_entry_id'];

        $optionUnit = '';

        foreach ($SavedDataArr['serving_units'] as $keyunit => $valueunit) {


          if ($selected_unit['id'] == $valueunit['id']) {

            $optionUnit .= '<option data-eng="'.$valueunit['key'].'" value="' . $valueunit['id'] . '" selected>' . $valueunit['name'] . '</option>';
          }
          else {

            $optionUnit .= '<option data-eng="'.$valueunit['key'].'" value="' . $valueunit['id'] . '">' . $valueunit['name'] . '</option>';
          }
        }

         $meal_term .= '<div class="grp search"><input type="text" placeholder="'. $search_food .'" name= "search_meal_frm_' . $fd_timeslt_val . '" value="'.$mealname.'" id="search_meal_frm_' . $fd_timeslt_val . '" data-fd_timeslt_val="' . $fd_timeslt_val . '" class ="search_meal_cls" readonly>
                    <input type="hidden" placeholder="'. $search_food .'" name= "search_meal_frm_alt_' . $fd_timeslt_val . '" value="' . $food_entry_id . '" id="search_meal_frm_alt_' . $fd_timeslt_val . '" class ="" >
                    <input type="hidden" placeholder="'. $search_food .'" name= "fd_time_val_' . $fd_timeslt_val . '" value="' . $fd_timeslt_val . '" id="fd_time_val_' . $fd_timeslt_val . '" class ="" >
                    </div>
                    <div class="fd_btn_pst_del" id="fd_btn_pst_del_' . $fd_timeslt_val . '"><i class="fa fa-trash" aria-hidden="true"></i></div>
                    <div class="grp qty"> 
                    <div class="qt minus">-</div>
                        <input type="text" value="'.$quantity.'" class="food-qty"  id="food_qty_' . $fd_timeslt_val . '" readonly>
                        <div class="qt plus">+</div>
                    </div>
                    <div class="grp select">
                        <select class="unit_' . $fd_timeslt_val . '" name="unit_' . $fd_timeslt_val . '" id="unit_' . $fd_timeslt_val . '"> ' . $optionUnit . '</select></div>
                          <div class="fd-btn">
                        <input type="button" value="'.$update.'" id="fd_btn_pst_' . $fd_timeslt_val . '" class="fd_btn_clk_pst">
                    </div>
                       ';

                    $countslotRecipe++;
         // }

    }

    
    return $meal_term;
  }

  /**
   * Defines a controller to load log meal datewise data.
   */
  public function loadPostDateNutrition(Request $request) {

    $hindi = CommonFunc::isHindi();

    $meal_term = '';
    $selectedDateval = $request->query->get('selectedDateval');

    $selectedDate = date("d-m-Y", strtotime($selectedDateval));
    $child_id = CommonFunc::childField('field_child_key');

    // $selectedDate = date("d-m-Y");
    $field_participation_key = CommonFunc::childField('field_participation_key');

    $field_child_dob = CommonFunc::childField('field_child_dob');

    $post_data = [
      'client_key' => $child_id,
      'participation_key' => $field_participation_key,
      'from_date' => $selectedDate,
      'to_date' => $selectedDate,
    ];
    //print_r($post_data); exit();
    $post_data = CommonFunc::APiHindi($post_data);
    $addFoodMeal = NestleAPI::retrieveFoodEntry($post_data);
    $getFoodexist_gtm = $addFoodMeal['contents']['gtm']['recipes'];

    if (isset($addFoodMeal['contents']['meal_entries'][$selectedDate])) {

      foreach ($addFoodMeal['contents']['meal_entries'][$selectedDate] as $keytime => $valuetime) {

        $timeslotRecipes[$keytime] = $valuetime;
      }
    }

    ksort($timeslotRecipes);

    if (!empty($child_id)) {
      $date = $field_child_dob;

      $ageGet = CommonFunc::calculateYearMonth($date);
      $years = $ageGet['year'];
      $months = $ageGet['month'];

      $age = $years . '.' . $months;
      $tid = \Drupal::entityQuery('taxonomy_term')
        ->condition('vid', 'diary_timing')
        ->sort('weight', 'ASC')
        ->execute();
      $tids = Term::loadMultiple($tid);

      $options = [];

      foreach ($tids as $term) {
        $term = CommonFunc::multilingualConvert("entity",$term);
        $options[$term->id()] = $term->getName();
      }

      $foodTime = CommonFunc::getFoodTime($options, $age);
      $meal_term .= '<ul>';
      foreach ($foodTime as $key => $value) {
        $time_term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($key);
        $eng_name = strip_tags($time_term->description->value);
        $path = $time_term->get('field_diary_icon')->entity->uri->value;
        $fd_time = $time_term->get('field_diary_value')->value;
        $image = ImageStyle::load('log_meal')->buildUrl($path);

        $meal_term .= '<li>
                <div class="food-time">
                    <div class="left"><img src="' . $image . '" /></div>
                    <div class="right" eng="'.$eng_name.'">' . $value . '</div>
                </div>
                <div class="dn-fm" id="display_data_' . $fd_time . '">';

        $meal_term .= self::foodDiaryDom($timeslotRecipes[$fd_time], $key, $fd_time, $getFoodexist_gtm);

        $meal_term .= '
                </div> 
            </li>';
      }

      $meal_term .= '</ul>';
    }

    return new JsonResponse($meal_term);

  }

}
