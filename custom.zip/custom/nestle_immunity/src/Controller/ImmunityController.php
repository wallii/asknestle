<?php

namespace Drupal\nestle_immunity\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\nestle_api\Controller\NestleAPI;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\Core\Language\LanguageManager;

/**
 * Returns responses for Immunity routes.
 */
class ImmunityController extends ControllerBase {

  /**
   * Builds the response.
   */

  public function content() {
    $hindi = CommonFunc::isHindi();
    $immunityText = 'test';
    /**** Start get immunity config page data *****/
    $page_config = array();
    $page_config['heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_immunity_page_heading');
    $page_config ['subhead'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_immunity_page_subheading');
     $page_config ['child_select'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_select_child_details');
    $page_config ['wht_is_immu'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_what_is_immunity');
    $page_config ['immu_ans'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_immunity_answer');
    $page_config['footer_disclaimer'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_footer_disclaimer');
    $page_config['footer_faq_txt'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_faq_text');
    $page_config['footer_faq_ans'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_faq_answer');
    $page_config['banner_heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_full_width_banner_heading');
    $page_config['banner_subheading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_full_width_banner_sub_head');
    $page_config['banner_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_full_width_banner_image');
    $page_config['mob_banner_image'] = CommonFunc::getConfigPageImageFieldValue('common_page_headings', 'field_full_width_mob_banner_imag');
    $page_config['banner_link'] = CommonFunc::getConfigPageLinkFieldValue('common_page_headings', 'field_button_link');
    /**** End get immunity config page data *****/
    $immunityForm = \Drupal::formBuilder()->getForm('Drupal\nestle_immunity\Form\ImmunityDataBoardForm');
    $renderer = \Drupal::service('renderer');
    $formHtml = $renderer->render($immunityForm);

    return [
      '#theme' => 'immunityFirstPage',
      '#hindi' => $hindi,
      '#immunityText' => $page_config,
      '#immunityForm' => $formHtml,
    ];
  }
  //use to get all food suggestions search box as per the search
  public function searchMeal(Request $request) {
    $results = [];
    $input = $request->query->get('q');
    $post_data = [
      "name" => $input,
    ];
    $post_data = CommonFunc::APiHindi($post_data);
    $search = NestleAPI::searchItem($post_data);
	
    if ($search != 0) {
      foreach ($search as $data) {
        $item['value'] = $data['id'];
        $item['label'] = $data['name'];
        $item['eng'] = $data['key'];
        $results[] = $item;
      }
    }
    return new JsonResponse($results);
  }

  // display the chart as per the year and month of a child
  public function showImmunity(Request $request) {
    global $base_url;
    $hindi = CommonFunc::isHindi();
    $childAge = $request->query->get('ym');
    $gender = $request->query->get('gender');
    $theme_path = \Drupal::theme()->getActiveTheme()->getPath();
    $post_data = [
      'age' => $childAge,
      'gender_id' => $gender,
    ];
    $getImmunityClient = NestleAPI::CreateImmunityEntry($post_data);
    $clientImmunityKey = $getImmunityClient['contents']['client_data']['client_key'];
    $participationKey = $getImmunityClient['contents']['client_data']['participation_id'];
    $growth_data = [
      'immunityAge' => $childAge,
      'immunityClientk' => $clientImmunityKey,
      'immunityparticipationK' => $participationKey,
      'immunityGender' => $gender,
    ];
    $session = \Drupal::request()->getSession();
    $session->set('immunityData', $growth_data);

    $meal_term['childAge'] =  $childAge;
    $meal_term['gender'] = $gender;

    $post_data = [
      'client_key' => $clientImmunityKey,
      'participation_key' => $participationKey,
    ];
    $meal_term['post_data'] = $post_data;

    $post_data = CommonFunc::APiHindi($post_data);
    $getImmunityClient = NestleAPI::retriveImmunityEntry($post_data);
    //$today = date('d-m-Y');
    //$SavedDataArr= array_reverse($getImmunityClient['contents']['meal_entries'][$today]);
    $meal_term['immunityData']  = CommonDiary::immunityScoreDom($getImmunityClient);

    $immunityScore = strtolower(reset(explode(' ',$getImmunityClient['contents']['immunity_score_zone'])));
    $meal_term['immunityHtml'] = '
      <div class="immuno-col40">
        <div class="col40-inr">
          <div class="box-fg">
            <div class="box-fginr">
            <div class="add-foodlist">
            <h3>'.(($hindi)?'खाना आइटम':'Add Food list').'</h3>
            <div class="grp search foodlist-search">
            <div class="srch-fltrs"> 
            <span class="srchfltr-btn"></span>
            <input type="text" placeholder="Search Food" class="search_meal_cls srchfld" name="search_meal_frm_0" id="search_meal_frm_0" data-key="0" data-id="" data-title="">

            <input type="hidden" placeholder="Search Food" name="search_meal_frm_alt_0" value="0" id="search_meal_frm_alt_0" class="">
            <input type="hidden" placeholder="Search Food" name="fd_time_val_0" value="123" id="fd_time_val_0" class="">
            <div class="food_ere form-error"></div>
            <div class="srchData-outr" style="display:none">
             <div class="replacesearchData_0 replaceslist srchData"></div></div>
            </div>
            
            </div>

            <div class="foodlist-items-row">
          
            </div>
            <div class="btn-add">
            <button class="primary-button" id="addFoodDiaryData">ADD</button>
            </div>
            <div class="btn-add btn-update" >
            <button class="primary-button" id="updateFoodDiaryData" style="display:none;">Update</button>
            </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      <div class="immuno-col60">
      <div class="col60-inr">
        <div class="box-fg">
          <div class="box-fginr">
            <div class="immunity-graph">
              <h3>Immuno scale value</h3>
              <div class="nutrient-tips">
                <div class="nutrient-tips-hd">
                  <ul class="score-'.$immunityScore.'">
                  '.(($hindi)?'<li> <span>आपको इम्युनिटी बढ़ाने के लिए इनका ज़्यादा सेवन करने की ज़रुरत है। कृपया नीचे दिए गए टिप्स देखें। </span> <em>लाल</em> <i></i> </li>
                    <li> <span>आपको इम्युनिटी बढ़ाने के लिए इनका ज़्यादा सेवन करने की ज़रुरत है। कृपया नीचे दिए गए टिप्स देखें। </span> <em>पीला</em> <i></i> </li>
                    <li> <span>आपको इम्युनिटी बढ़ाने के लिए इनका ज़्यादा सेवन करने की ज़रुरत है। कृपया नीचे दिए गए टिप्स देखें।! </span> <em>हरा</em> <i></i> </li>
                    <li> <span>आपको इन माइक्रो न्यूट्रिएंट की मात्रा बढ़ाने की जरूरत है। कृपया नीचे दिए गए टिप्स देखें </span> <em>लाल</em> <i></i> </li>':' <li> <span>You need to consume more </span> <em>ORANGE</em> <i><img src="/themes/custom/nestle_new/common/images/tipshd-icon.svg"></i> </li>
                    <li> <span>You need to increase intake </span> <em>YELLOW</em> <i><img src="/themes/custom/nestle_new/common/images/tipshd-icon.svg"></i> </li>
                    <li> <span>You have the right immunity! </span> <em>GREEN</em> <i><img src="/themes/custom/nestle_new/common/images/tipshd-icon.svg"></i> </li>
                    <li> <span>You need to consume less </span> <em>RED</em> <i><img src="/themes/custom/nestle_new/common/images/tipshd-icon.svg"></i> </li>').'
                  </ul>
                </div> <div class="nutrient-tips-list">';
      foreach($getImmunityClient['contents']['analysis'] as $key => $nutrient) {
        $meal_term['immunityHtml'] .= '
        <div class="item-tips" data-tab="tab-'.($key+1).'" class="modal-tab">
          <div class="tips-title">'.$nutrient['name'].'</div>
          <div class="tips-graph">
            <div class="tips-graph-box">
              <div class="col25 '.$nutrient['class_color'].'-color"></div>
            </div>
          </div>
          <div class="tips-popup" data-nutriname="'.$nutrient['name'].'" data-nutricolor="'.$nutrient['class_color'].'"><a href="javascript:void(0)">Tips</a></div>
        </div>';
      }
      $meal_term['immunityHtml'] .='</div>
      <div class="immunity-range">
        <ul>
          <li class="redrange"> <15%  '.(($hindi)?'RDA ज़ोन का':'of RDA Zone').'</li>
          <li class="orangerange"> >15% '.(($hindi)?' के RDA से':' of RDA to').' <30% '.(($hindi)?' RDA का':' of RDA').' </li>
          <li> >30% '.(($hindi)?'के RDA से  < TUL':' of RDA to < TUL').' </li>
          <li class="tul"> > '.(($hindi)?' TUL':'TUL').'</li>
        </ul>
      </div>
      <p><sub>*</sub>'.(($hindi)?'रेकमेंडेड डाइटरी अलाउएंस (RDA)':'Recommended Dietary Allowance (RDA)').'</p>
      <p><sub>**</sub>'.(($hindi)?'टॉलरेबल अपर लिमिट (TUL)':'Tolerable Upper Limit (TUL)').'</p>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>';
    return new JsonResponse($meal_term);
  }

  /**
   * Get meal unit as per @request.
   */
  public function mealUnit(Request $request) {
    $id = $request->query->get('key');
    $title = $request->query->get('title');
    $post_data = [
      "name" => $title,
    ];
    $post_data = CommonFunc::APiHindi($post_data);
    $search = NestleAPI::searchItem($post_data);

    if ($search != 0) {
      foreach ($search as $key => $data) {
        if ($data['id'] == $id) {
          foreach ($data['serving_units'] as $unit) {
            $option['id'] = $unit['id'];
            $option['title'] = $unit['name'];
            $option['eng'] = $unit['key'];
            $options[] = $option;
          }
        }
      }
    }
    return new JsonResponse($options);
  }

  // get the nutients data on tips click
  public function getNutrientsData(Request $request) {
    $nutrient = strtolower($request->query->get('nutrient'));
    $rda_color = strtolower($request->query->get('rda_color'));
    $nutrient_name = str_replace(' ', '_', str_replace(array( '(', ')' ), '', $nutrient));
    $session = \Drupal::request()->getSession();
    $immunityData = $session->get('immunityData');

    $childAge =  $immunityData['immunityAge'];
    $gender = $immunityData['immunityGender'];
    $modalPopUp = '';
    $hindi = CommonFunc::isHindi();
    $data = array();

    if($nutrient_name == 'zinc') {
      $nutrients['desc'] = '<h3>Importance of Zinc and how it helps in building immunity.</h3> <p class="nutrient-desc">Zinc is a mineral that\'s important to the body in many ways. Zinc keeps the immune system strong, helps heal wounds, and supports normal growth.</p>';
      $nutrients['foods'] = array("Chicken", "Ravas", "Egg", "Goat Meat", "Chickpeas", "Black beans", "Pumpkin", "Sesame, White", "Black Beans, Rajma", "Poppy seed");
      $nutrients["recipes"] = array(
        array("name" => "Chicken Masala Curry Recipe", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/chicken-masala"),

        array("name" => "Ravas Fish Fry Recipe", "img" => "/themes/custom/nestle_new/common/images/2-ravas.png", "seo_name" => "recipes/ravas-indian-salmon-fish-fry"),

        array("name" => "Egg Bhurji With Vegetables", "img" => "/themes/custom/nestle_new/common/images/3-egg-buji.png", "seo_name" => "recipes/egg-bhurji-with-vegetable"),

        array("name" => "Mutton Curry", "img" => "/themes/custom/nestle_new/common/images/4-mutton-curry.png", "seo_name" => "recipes/mutton-curry"),

        array("name" => "Spinach Chickpeas Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/5-palak-chole.png", "seo_name" => "recipes/palak-chole-sabji"),

        array("name" => "Black Chickpeas Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/8-black-chana.png", "seo_name" => "recipes/black-chana"),

        array("name" => "Jeera Pumpkin Kulcha With Ghee", "img" => "/themes/custom/nestle_new/common/images/6-jeera-pumpkin.png", "seo_name" => "recipes/jeera-pumpkin-kulcha"),

        array("name" => "White Sesame Seeds Roti With Ghee", "img" => "/themes/custom/nestle_new/common/images/7-til-roti.png", "seo_name" => "recipes/til-roti-with-ghee"),

        array("name" => "Rajma Curry", "img" => "/themes/custom/nestle_new/common/images/9-rajma-curry.png", "seo_name" => "recipes/rajma-curry"),

        array("name" => "Khas Khas Halwa", "img" => "/themes/custom/nestle_new/common/images/10-khas-khas.png", "seo_name" => "recipes/khas-khas-halwa")
      );
      $nutrients["articles"] = array(
        array("title" => "Why these 5 zinc-rich foods should be added to your child’s diet", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/why-these-5-zinc-rich-foods-should-be-added-your-childs-diet"),

        array("title" => "7 Nutrients that should be part of Kids’s Diet for Healthy Growth", "img" => "/themes/custom/nestle_new/common/images/2-nutri.png", "url" => "expert-advice/7-nutrients-should-be-part-toddlers-diet-healthy-growth")
      );
    } else if($nutrient_name == 'iron') {
      $nutrients['desc'] = "<h4>Importance of Iron and how it helps in building immunity.</h4><p>Iron is a mineral that the body needs for growth and development.</br>Iron plays an important role in the immune system, a healthy iron intake helps your immune system to work properly.</p>";
      $nutrients['foods'] = array("Chicken", "Chicken, Liver", "Black beans, Rajma", "Red amaranth", "Dill Leaves", "Soybean", "Ragi", "Millet");
      $nutrients["recipes"] = array(
        array("name" => "Chicken Masala Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/chicken-masala"),

        array("name" => "Liver Masala Dry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/kaleji"),

        array("name" => "Kidney Beans Pulao", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/rajma-pulao-kidney-beans-pulao"),

        array("name" => "Red Amaranth Leaves Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/amaranth-sabji"),

        array("name" => "Dill Rajma Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/rajma-shepu-bhaji"),

        array("name" => "Soy Bean Potato Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/soy-bean-potato-vegetable"),

        array("name" => "Ragi Porridge With Vegetables", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/ragi-porridge-with-vegetables"),

        array("name" => "Fenugreek Bajra Paratha With Ghee", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/methi-bajri-paratha")
      );
      $nutrients["articles"] = array(
        array("title" => "Enjoy the power of soups with these 5 delicious recipes", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/enjoy-power-soups-these-5-delicious-recipes"),

        array("title" => "How bad is worm infestation in children and remedies", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/how-bad-worm-infestation-children-and-remedies"),

        array("title" => "These food pairings can help maximize nutrient absorption", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/these-food-pairings-can-help-maximize-nutrient-absorption"),

        array("title" => "Know all about the role of iron in your child’s body", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/know-all-about-role-iron-your-childs-body"),

        array("title" => "How to incorporate millets in your child’s diet", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/how-incorporate-millets-your-childs-diet"),

        array("title" => "All you need to know about nutrition for an adolescent girl", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/all-you-need-know-about-nutrition-adolescent-girl"),

        array("title" => "5 essential questions on the importance of protein", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/5-essential-questions-importance-protein"),

        array("title" => "How parents can be role models for good nutrition", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/how-parents-can-be-role-models-good-nutrition"),

        array("title" => "Food Pyramid to Plate", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/food-pyramid-plate"),

        array("title" => "A list of nutrients that help your kid’s brain develop", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/list-nutrients-help-your-kids-brain-develop")
      );
    } else if($nutrient_name == 'selenium') {
      $nutrients['desc'] = "<h4>Importance of Selenium and how it helps in building immunity.</h4><p>Selenium is an essential trace mineral that is important for many bodily processes, including cognitive function, a healthy immune system.</br>This antioxidant helps lower oxidative stress in your body, which reduces inflammation and enhances immunity.</p>";
      $nutrients['foods'] = array("Bangda", "Garden Cress Seeds", "Egg", "Moong Dal");
      $nutrients["recipes"] = array(
        array("name" => "Mackerel Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/mackerel-curry"),

        array("name" => "Garden Cress Jaggery Ladoo", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/halim-ladoo"),

        array("name" => "Egg Bhurji With Vegetables", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/egg-bhurji-with-vegetable"),

        array("name" => "Green Gram Dal Kheer With Jaggery", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/moong-dal-payasam-green-gram-dal-kheer")
      );
      $nutrients["articles"] = array(
        array("title" => "Amazing ideas to pack your child’s food for day care", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/amazing-ideas-pack-your-childs-food-day-care"),

        array("title" => "Why Is Nutrient Dense Food So Important for Your Child", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/why-nutrient-dense-food-so-important-your-child")
      );
    } else if($nutrient_name == 'vitamin_a') {
      $nutrients['desc'] = "<h4>Importance of Vitamin A and how it helps in building immunity.</h4><p>Vitamin A is a fat-soluble vitamin that is naturally present in many foods.</br>Vitamin A is also important for the immune system. A deficiency in vitamin A can increase your vulnerability to infections and delay your recovery when you get sick.Vitamin A - An increase in consumption must be cautioned by controling the portion sizes of foods contributing to the intake of the nutrient.</p>";
      $nutrients['foods'] = array("Spinach", "Fenugreek leaves", "Black colocasia leaves", "Red amaranth", "Dill Leaves", "Carrot");
      $nutrients["recipes"] = array(
        array("name" => "Chicken Spinach Curry With Oil", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/palak-chicken-curry-spinach"),

        array("name" => "Fenugreek Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/methi-bhaji"),

        array("name" => "Alu Wadi", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/alu-wadi"),

        array("name" => "Red Amaranth Leaves Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/amaranth-sabji"),

        array("name" => "Dill Leaves Green Gram Dal Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/shepu-bhaji-dill-leaves-vegetable")
      );
      $nutrients["articles"] = array(
        array("title" => "Should you eat mangoes when you are pregnant?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/should-you-eat-mangoes-when-you-are-pregnant"),

        array("title" => "5 healthy dip recipes", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/5-healthy-dip-recipes"),

        array("title" => "All-time top 5 summer drinks for the outdoorsy child", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/all-time-top-5-summer-drinks-outdoorsy-child"),

        array("title" => "5 pumpkin recipes that your toddler will love", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/5-pumpkin-recipes-your-toddler-will-love"),

        array("title" => "Vitamins that your child absolutely needs for growth", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/vitamins-your-child-absolutely-needs-growth"),

        array("title" => "All you need to know about the benefits of organic foods", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/all-you-need-know-about-benefits-organic-foods"),

        array("title" => "Try these quick and easy evening snack recipes for kids", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/try-these-quick-and-easy-evening-snack-recipes-kids"),

        array("title" => "4 Healthy & Easy Carrot Recipes for Kids", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/4-healthy-easy-carrot-recipes-kids")
      );
    } else if($nutrient_name == 'vitamin_e') {
      $nutrients['desc'] = "<h4>Importance of Vitamin E and how it helps in building immunity.</h4><p>Vitamin E is an important vitamin required for the proper function of many organs in the body. It is also an antioxidant.</br> The body also needs vitamin E to boost its immune system so that it can fight off invading bacteria.</p>";
      $nutrients['foods'] = array("Almond", "Avocado", "Spinach", "Pumpkin", "Broccoli", "Kiwi");
      $nutrients["recipes"] = array(
        array("name" => "Almond Paratha With Ghee", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/almond-paratha"),

        array("name" => "Avocado Moong Sprouts Paratha With Ghee", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/avocado-sprouts-paratha"),

        array("name" => "Banana Spinach Milkshake With Sugar", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/banana-spinach-milkshake"),

        array("name" => "Pumpkin Dal With Oil", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/dal-with-pumpkin"),

        array("name" => "Jowar Broccoli Pancake", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/jowar-brocolli-pancake"),

        array("name" => "Kiwi Cucumber Salad", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/kiwi-cucumber-delight")
      );
      $nutrients["articles"] = array(
        array("title" => "Top foods for your kid’s healthy vision", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/top-foods-your-kids-healthy-vision"),

        array("title" => "Why should you make dried fruits a part of your kid’s diet?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/why-should-you-make-dried-fruits-part-your-kids-diet"),

        array("title" => "Nut allergy in children: Causes and treatment", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/nut-allergy-children-causes-and-treatment"),

        array("title" => "20 excellent immunity-boosting foods that should be part of your child’s diet", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/20-excellent-immunity-boosting-foods-that-should-be-part-of-your-childs-diet"),

        array("title" => "Nutrients that help beat the winter blues", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/nutrients-help-beat-winter-blues"),

        array("title" => "Know How to Provide Sustained Energy for Your Child", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/know-how-provide-sustained-energy-your-child")
      );
    } else if($nutrient_name == 'vitamin_c') {
      $nutrients['desc'] = "<h4>Importance of Vitamin C and how it helps in building immunity.</h4><p>Vitamin C, also known as ascorbic acid, has several important functions. It helps to protect cells, keeping them healthy, maintaining healthy skin, bones etc.</br> Vitamin C is involved in many parts of the immune system. It encourages the production of white blood cells which help protect the body against infections.</p>";
      $nutrients['foods'] = array("Gooseberries", "Guava", "Orange", "Papaya", "Lemon", "Capsicum");
      $nutrients["recipes"] = array(
        array("name" => "Amla Chutney", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/amla-chutney"),

        array("name" => "Guava Milkshake With Sugar", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/guava-milkshake"),

        array("name" => "Beetroot Orange Raita With Cow Milk Curd", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/beetroot-orange-raita"),

        array("name" => "Papaya Milkshake With Sugar", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/papaya-milkshake"),

        array("name" => "Lemon Coriander Soup", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/lemon-coriander-soup"),

        array("name" => "Paneer Capsicum Dry Vegetable", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/paneeer-shimla-mirch-sabji")
      );
      $nutrients["articles"] = array(
        array("title" => "Why is Vitamin C important for your child?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/why-vitamin-c-important-your-child")
      );
    } else if($nutrient_name == 'pyridoxin_vitamin_b6') {
      $nutrients['desc'] = "<h4>Importance of Pyridoxine (Vitamin B6) and how it helps in building immunity.</h4><p>Vitamin B6, also known as Pyridoxine, is a water-soluble vitamin. It is important for proper cell function, they help with metabolism, creating blood cells, and keeping cells healthy.</br>Vitamin B6 is responsible for producing white blood cells and T cells, which regulate immune responses.</p>";
      $nutrients['foods'] = array("Rohu", "Saffron", "Prawns", "Walnut", "Ravas", "White pomfret");
      $nutrients["recipes"] = array(
        array("name" => "Rohu Fish Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/rohu-fish-curry"),

        array("name" => "Turmeric Saffron Milk With Sugar", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/haldi-kesar-milk"),

        array("name" => "Prawns Malai Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/prawns-malai-curry"),

        array("name" => "Walnut Cake", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/walnut-cake"),

        array("name" => "Ravas Fish Curry","img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png",  "seo_name" => "recipes/ravas-fish-curry"),

        array("name" => "Pomfret Whole Fry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/fish-fry")
      );
      $nutrients["articles"] = array(
        array("title" => "Nutrients to support immunity in active children", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/nutrients-support-immunity-active-children")
      );
    } else if($nutrient_name == 'total_folates_vitamin_b9') {
      $nutrients['desc'] = "<h4>Importance of Total Folates (Vitamin B9) and how it helps in building immunity.</h4><p>Total Folate (vitamin B-9) is important in red blood cell formation and for healthy cell growth and function.</br>Adequate intake of Total Folates is extremely important during periods of rapid growth.</p>";
      $nutrients['foods'] = array("Fresh bombil", "Pomfret", "Prawns", "Rohu", "Bangda", "Rajma", "Black chickpeas", "Spinach");
      $nutrients["recipes"] = array(
        array("name" => "Bombay Duck Fish Fry", "seo_name" => "recipes/bombil-bombay-duck-fish-fry"),
        array("name" => "Grilled Pomfret", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/grilled-pomfret"),

        array("name" => "Prawn Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/prawn-curry"),

        array("name" => "Rohu Fish Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/rohu-fish-curry"),

        array("name" => "Mackerel Curry", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/mackerel-curry"),

        array("name" => "Rajma Chawal", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/rajma-chawal"),

        array("name" => "Black Chickpeas Soya Cutlet", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/chana-and-soya-cutlet"),
        array("name" => "Banana Spinach Milkshake With Sugar", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/banana-spinach-milkshake")
      );
      $nutrients["articles"] = array(
        array("title" => "How to plan a nutrient-satisfying vegetarian menu for your toddler", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/how-plan-nutrient-satisfying-vegetarian-menu-your-toddler"),

        array("title" => "Highly nutritious recipes that kids can enjoy at every meal", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/highly-nutritious-recipes-kids-can-enjoy-every-meal"),

        array("title" => "The complete protein guide for your children this summer", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/complete-protein-guide-your-children-summer"),

        array("title" => "A few food rules to make winter warm and healthy for kids", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/few-food-rules-make-winter-warm-and-healthy-kids")
      );
    } else if($nutrient_name == 'ज़िंक') {
      $nutrients['desc'] = '<h4>ज़िंक का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4> <p class="nutrient-desc">ज़िंक एक मिनरल है जो कई तरह से शरीर के लिए ज़रूरी है। ज़िंक इम्यून सिस्टम को मजबूत बनाता है, घावों को भरने में मदद करता है और बच्चे के बढ़ने में मदद करता है।</p>';
      $nutrients['foods'] = array("चिकन", "रवास", "अंडे", "बकरे का मीट", "छोले", "ब्लैक बीन्स (काली सेम)", "कद्दू", "तिल, सफ़ेद", "ब्लैक बीन्स, राजमा", "खसखस");
      $nutrients["recipes"] = array(
        array("name" => "चिकन मसाला करी रेसिपी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/चिकन-मसाला-रेसिपी-विधि"),
        array("name" => "रवास फिश फ्राई रेसिपी", "img" => "/themes/custom/nestle_new/common/images/2-ravas.png", "seo_name" => "recipes/रावस-फिश-फ्राई-रेसिपी-विधि"),
        array("name" => "सब्जियों के साथ अंडा भुर्जी", "img" => "/themes/custom/nestle_new/common/images/3-egg-buji.png", "seo_name" => "recipes/अंडा-भुर्जी-सब्जी-सहित-रेसिपी-विधि"),
        array("name" => "मटन करी", "img" => "/themes/custom/nestle_new/common/images/4-mutton-curry.png", "seo_name" => "recipes/मटन-करी-रेसिपी-विधि"),
        array("name" => "पालक चने की सूखी सब्ज़ी", "img" => "/themes/custom/nestle_new/common/images/5-palak-chole.png", "seo_name" => "recipes/पालक-छोले-सब्जी-रेसिपी-विधि"),
        array("name" => "काले चने की सूखी सब्ज़ी", "img" => "/themes/custom/nestle_new/common/images/8-black-chana.png", "seo_name" => "recipes/काला-चना-सूखी-सब्जी-रेसिपी-विधि"),
        array("name" => "जीरा कद्दू कुलचा, घी के साथ", "img" => "/themes/custom/nestle_new/common/images/6-jeera-pumpkin.png", "seo_name" => "recipes/जीरा-कद्दु-कुलचा-घी-सहित-रेसिपी-विधि"),
        array("name" => "सफेद तिल की रोटी, घी के साथ", "img" => "/themes/custom/nestle_new/common/images/7-til-roti.png",  "seo_name" => "recipes/तिल-रोटी-घी-सहित-रेसिपी-विधि"),
        array("name" => "राजमा करी", "img" => "/themes/custom/nestle_new/common/images/9-rajma-curry.png", "seo_name" => "recipes/राजमा-करी-रेसिपी-विधि"),
        array("name" => "खसखस हलवा", "img" => "/themes/custom/nestle_new/common/images/10-khas-khas.png", "seo_name" => "recipes/खस-खस-हलवा-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "बच्चों की डाइट में ज़िक से भरे ये 5 आहार क्यों शामिल करें", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/बच्चों-की-डाइट-में-ज़िक-से-भरे-ये-5-आहार-क्यों-शामिल-करें"),
        array("title" => "आपके बच्चे के विकास के लिए ज़रूरी 7 पोषक तत्व", "img" => "/themes/custom/nestle_new/common/images/2-nutri.png", "url" => "expert-advice/आपके-बच्चे-के-विकास-के-लिए-ज़रूरी-7-पोषक-तत्व")
      );
    } else if($nutrient_name == 'आयरन') {
      $nutrients['desc'] = "<h4>आयरन का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>आयरन एक मिनरल है और शरीर को बढ़ने और विकास करने के लिए इसकी ज़रुरत पड़ती है। आयरन इम्यून सिस्टम में काफी अहम भूमिका निभाता है और अच्छी मात्रा में आयरन का सेवन करने से आपका इम्यून सिस्टम बेहतर तरीके से काम करता है।</p>";
      $nutrients['foods'] = array("चिकन", "चिकन, लिवर", "ब्लैक बीन्स, राजमा", "लाल अमरनाथ", "सोआ के पत्ते", "सोयाबीन", "रागी", "बाजरा");
      $nutrients["recipes"] = array(
        array("name" => "चिकन मसाला", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/चिकन-मसाला-रेसिपी-विधि"),

        array("name" => "कलेजी मसाला सूखी सब्ज़ी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/कलेजी-मसाला-सूखी-सब्ज़ी-रेसिपी-विधि"),

        array("name" => "राजमा पुलाव", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/राजमा-पुलाव-रेसिपी-विधि"),

        array("name" => "लाल चौलाई सूखी सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/लाल-चौलाई-सूखी-सब्जी-रेसिपी-विधि"),

        array("name" => "सोवा राजमा सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/सोवा-राजमा-सब्जी-रेसिपी-विधि"),

        array("name" => "सोयाबीन आलू सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/सोया-बीन-आलू-सब्जी-रेसिपी-विधि"),

        array("name" => "रागी दलिया सब्जी सहित", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/रागी-दलिया-सब्जी-सहित-रेसिपी-विधि"),

        array("name" => "मेथी बाजरा पराठा", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/मेथी-बाजरा-पराठा-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "सूप का मज़ा लें इन 5 स्वादिष्ट रेसिपी के साथ", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png", "url" => "expert-advice/सूप-का-मज़ा-लें-इन-5-स्वादिष्ट-रेसिपी-के-साथ"),
        array("title" => "बच्चों में कीड़ों से होने वाले संक्रमण और उपचार", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-में-कीड़ों-से-होने-वाले-संक्रमण-और-उपचार"),
        array("title" => "इन चीज़ों को मिलाकर खाने से मिलता है भरपूर पोषण", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/इन-चीज़ों-को-मिलाकर-खाने-से-मिलता-है-भरपूर-पोषण"),
        array("title" => "जानें आपके बच्चे के शरीर में आयरन क्यों ज़रूरी है", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/जानें-आपके-बच्चे-के-शरीर-में-आयरन-क्यों-ज़रूरी-है"),
        array("title" => "बच्चों के आहार में मिलेट कैसे शामिल करें", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-के-आहार-में-मिलेट-कैसे-शामिल-करें"),
        array("title" => "किशोरावस्था में लड़कियों के पोषण से जुड़ी ज़रूरी बातें", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/किशोरावस्था-में-लड़कियों-के-पोषण-से-जुड़ी-ज़रूरी-बातें"),
        array("title" => "प्रोटीन के महत्त्व से जुड़े 5 ज़रूरी सवाल", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/प्रोटीन-के-महत्त्व-से-जुड़े%205-ज़रूरी-सवाल"),
        array("title" => "अच्छे पोषण के लिए बनें बच्चों के रोल मॉडल, जानिए कैसे", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/अच्छे-पोषण-के-लिए-बनें-बच्चों-के-रोल-मॉडल-जानिए-कैसे"),
        array("title" => "फूड पिरामिड से प्लेट तक", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/फूड-पिरामिड-से-प्लेट-तक"),
        array("title" => "बच्चों के दिमाग़ी विकास को बढ़ाने के तरीके", "url" => "expert-advice/बच्चों-के-दिमाग़ी-विकास-को-बढ़ाने-के-तरीके")
      );
    } else if($nutrient_name == 'सेलेनियम') {
      $nutrients['desc'] = "<h4>सेलेनियम का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>सेलेनियम एक ज़रूरी ट्रेस मिनरल है जो कई चीज़ों के लिए ज़रूरी है, जिसमें कॉग्निटिव फंक्शन (याद रखना, सीखना, ध्यान देना, फैसला लेने जैसे काम), स्वस्थ इम्यून सिस्टम शामिल है। यह एंटीऑक्सीडेंट आपके शरीर में ऑक्सीडेटिव स्ट्रेस को कम करने में मदद करता है, जिससे सूजन कम होती है और इम्युनिटी बढ़ती है।
      </p>";
      $nutrients['foods'] = array("बांगड़ा", "हलीम बीज", "अंडा", "मूंग दाल");
      $nutrients["recipes"] = array(
        array("name" => "बांगड़ा करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/बांगड़ा-करी-रेसिपी-विधि"),

        array("name" => "हलीम लड्डू", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/हलीम-लड्डू-रेसिपी-विधि"),
        array("name" => "अंडा भुर्जी सब्जी सहित", "seo_name" => "recipes/अंडा-भुर्जी-सब्जी-सहित-रेसिपी-विधि"),

        array("name" => "मूंग दाल खीर गुड़ सहित", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/मूंग-दाल-खीर-गुड़-सहित-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "डे केयर के लिए अपने बच्चे का खाना पैक करने के लिए बेहतरीन सुझाव", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/डे-केयर-के-लिए-अपने-बच्चे-का-खाना-पैक-करने-के-लिए-बेहतरीन-सुझाव"),

        array("title" => "आपके बच्चे के लिए पोषक तत्वों से भरपूर खाना क्यों ज़रूरी है?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/आपके-बच्चे-के-लिए-पोषक-तत्वों-से-भरपूर-खाना-क्यों-ज़रूरी-है")
      );
    } else if($nutrient_name == 'विटामिन_a') {
      $nutrients['desc'] = "<h4>विटामिन A का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>विटामिन A वसा में घुलनशील विटामिन है जो कई खाद्य पदार्थों में स्वाभाविक तौर से मौजूद होता है। विटामिन A इम्यून सिस्टम के लिए भी महत्वपूर्ण है। विटामिन A की कमी से आपकी इंफेक्शन से लड़ने की ताकत में कमी आ सकती है और इसकी कमी से आप बीमार होने पर देरी से ठीक होते हैं।</p>";
      $nutrients['foods'] = array("पालक", "मेथी के पत्ते", "काली अरवी के पत्ते ", "लाल अमरनाथ", "सोआ के पत्ते", "गाजर");
      $nutrients["recipes"] = array(
        array("name" => "चिकन पालक करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/चिकन-पालक-करी-रेसिपी-विधि"),

        array("name" => "मेथी सूखी सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/मेथी-सूखी-सब्जी-रेसिपी-विधि"),

        array("name" => "आलू वड़ी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/आलू-वड़ी-रेसिपी-विधि"),

        array("name" => "लाल चौलाई सूखी सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/लाल-चौलाई-सूखी-सब्जी-रेसिपी-विधि"),

        array("name" => "सोवा मूंग दाल सूखी सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/सोवा-मूंग-दाल-सूखी-सब्जी-रेसिपी-विधि"),

        array("name" => "गाजर चुकंदर रस चीनी सहित", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/गाजर-चुकंदर-रस-चीनी-सहित-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "गर्भावस्था में आम खाएँ या न खाएँ?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/गर्भावस्था-में-आम-खाएँ-या-न-खाएँ"),
        array("title" => "5 हेल्दी डिप रेसिपी", "url" => "expert-advice/5-हेल्दी-डिप-रेसिपी"),
        array("title" => "बाहर खेलने वाले बच्चों के लिए गर्मियों में बनाएं ये 5 शरबत", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बाहर-खेलने-वाले-बच्चों-के-लिए-गर्मियों-में-बनाएं-ये-5-शरबत"),

        array("title" => "बच्चों को पसंद आने वाली कद्दू की 5 स्वादिष्ट रेसिपी", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-को-पसंद-आने-वाली-कद्दू-की-5-स्वादिष्ट-रेसिपी"),

        array("title" => "बच्चे के विकास के लिए ये विटामिन हैं सबसे ज़रूरी", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चे-के-विकास-के-लिए-ये-विटामिन-हैं-सबसे-ज़रूरी"),

        array("title" => "ऑर्गैनिक फूड क्यूँ है एक अच्छा विकल्प?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/ऑर्गेनिक-फूड-क्यों-है-एक-अच्छा-विकल्प"),

        array("title" => "बच्चों को पसंद आने वाली आसान और सेहतमंद रेसिपीज़", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-को-पसंद-आने-वाली-आसान-और-सेहतमंद-रेसिपीज़"),

        array("title" => "बच्चों को बेहद पसंद आएंगी गाजर की ये बेहतरीन रेसिपी", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-को-बेहद-पसंद-आएंगी-गाजर-की-ये-बेहतरीन-रेसिपी")
      );
    } else if($nutrient_name == 'विटामिन_e') {
      $nutrients['desc'] = "<h4>विटामिन E का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>विटामिन E एक महत्वपूर्ण विटामिन है जो हमारे शरीर में कई सारे हिस्सों के बेहतर तरीके से काम करने में मदद करता है। यह एक एंटीऑक्सीडेंट भी है। शरीर को अपना इम्यून सिस्टम बढ़ाने के लिए विटामिन E की ज़रुरत पड़ती है ताकि हमारा शरीर बैक्टीरिया और अन्य कीटाणुओं से लड़ सके।</p>";
      $nutrients['foods'] = array("बादाम", "एवोकैडो", "पालक", "कद्दू", "ब्रोकली", "कीवी");
      $nutrients["recipes"] = array(
        array("name" => "बादाम पराठा", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/बादाम-पराठा-रेसिपी-विधि"),

        array("name" => "अवोकाडो अंकुरित पराठा", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/अवोकाडो-अंकुरित-पराठा-रेसिपी-विधि"),

        array("name" => "केला पालक मिल्कशेक", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/केला-पालक-मिल्कशेक-रेसिपी-विधि"),

        array("name" => "दाल कद्दू सहित", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/दाल-कद्दू-सहित-रेसिपी-विधि"),

        array("name" => "जवार ब्रोक्कोली पैनकेक", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/जवार-ब्रोक्कोली-पैनकेक-रेसिपी-विधि"),

        array("name" => "कीवी खीरा सलाद", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/कीवी-खीरा-सलाद-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "आपके बच्चे की स्वस्थ आँखों की रोशनी के लिए सबसे अच्छे खाद्य पदार्थ", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/आपके-बच्चे-की-स्वस्थ-आँखों-की-रोशनी-के-लिए-सबसे-अच्छे-खाद्य-पदार्थ"),

        array("title" => "बच्चों की डाइट में ड्राई फ्रूट शामिल करने के बेमिसाल फ़ायदे", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-की-डाइट-में-ड्राई-फ्रूट-शामिल-करने-के-बेमिसाल-फ़ायदे"),

        array("title" => "क्यों होती हैनट एलर्जी ? जानें इसके इलाज", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/क्यों-होती-हैनट-एलर्जी%20-जानें-इसके-इलाज"),

        array("title" => "20 इम्युनिटी बढ़ाने वाले भोजन जो आपके बच्चे के आहार में शामिल होने चाहिए", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/20-इम्युनिटी-बढ़ाने-वाले-भोजन-जो-आपके-बच्चे-के-आहार-में-शामिल-होने-चाहिए"),

        array("title" => "सर्दियों से राहत के लिए खाएँ यह पौष्टिक तत्व", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/सर्दियों-से-राहत-के-लिए-खाएँ-यह%20-पौष्टिक-तत्व"),

        array("title" => "बच्चे में हमेशा ताकत बनाए रखने के तरीके", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चे-में-हमेशा-ताकत-बनाए-रखने-के-तरीके")
      );
    } else if($nutrient_name == 'विटामिन_c') {
      $nutrients['desc'] = "<h4>विटामिन C का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>विटामिन C को एस्कॉर्बिक एसिड भी कहा जाता है और यह कई ज़रूरी काम करता है। यह कोशिकाओं (सेल्स) की रक्षा करता है और उन्हें स्वस्थ रखता है, स्किन, हड्डियों आदि को स्वस्थ रखने में मदद करता है।</br>विटामिन C इम्यून सिस्टम के कई हिस्सों में शामिल होता है। यह व्हाइट ब्लड सेल्स के उत्पादन में मदद करता है जिसके कारण शरीर को इंफेक्शन से बचाने में मदद मिलती है।</p>";
      $nutrients['foods'] = array("गूसबेरी (करौंदा)", "अमरुद", "संतरा", "पपीता", "नींबू", "शिमला मिर्च");
      $nutrients["recipes"] = array(
        array("name" => "आंवला चटनी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/आंवला-चटनी-रेसिपी-विधि"),

        array("name" => "अमरुद मिल्कशेक", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/अमरुद-मिल्कशेक-रेसिपी-विधि"),

        array("name" => "चुकंदर संतरा रायता", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/चुकंदर-संतरा-रायता-रेसिपी-विधि"),

        array("name" => "पपीता मिल्कशेक चीनी सहित", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/पपीता-मिल्कशेक-चीनी-सहित-रेसिपी-विधि"),

        array("name" => "नींबू और धनिया सूप", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/नींबू-और-धनिया-सूप-रेसिपी-विधि"),

        array("name" => "पनीर शिमला मिर्च सब्जी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/पनीर-शिमला-मिर्च-सब्जी-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "आपके बच्चे के लिए विटामिन सी क्यों है ज़रूरी?", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/आपके-बच्चे-के-लिए-विटामिन-सी-क्यों-है-ज़रूरी")
      );
    } else if($nutrient_name == 'पाइरीडक्सीन_विटामिन_b6') {
      $nutrients['desc'] = "<h4>पाइरिडोक्सिन (विटामिन B6) का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>विटामिन B6 को पाइरिडोक्सिन के नाम से भी जाना जाता है यह पानी में घुलनशील विटामिन होता है। ये कोशिकाओं (सेल्स) के बेहतर तरीके से काम करने के लिए ज़रूरी होते हैं, ये मेटाबोलिज्म में मदद करते हैं, ब्लड सेल्स का निर्माण करते हैं और कोशिकाओं (सेल्स) को स्वस्थ रखते हैं।</br>विटामिन B6 व्हाइट ब्लड सेल्स और T सेल्स के उत्पादन के लिए जिम्मेदार होता है, जो इम्यून रेस्पोंस को नियंत्रित करते हैं।</p>";
      $nutrients['foods'] = array("रोहू", "केसर", "झींगा", "अखरोट", "रावस", "सफ़ेद पॉम्फ्रेट");
      $nutrients["recipes"] = array(
        array("name" => "रोहु फिश करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/रोहु-फिश-करी-रेसिपी-विधि"),

        array("name" => "हल्दी केसर दूध चीनी सहित", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/हल्दी-केसर-दूध-चीनी-सहित-रेसिपी-विधि"),

        array("name" => "झींगा मलाई करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/झींगा-मलाई-करी-रेसिपी-विधि"),

        array("name" => "अखरोट केक", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/अखरोट-केक-रेसिपी-विधि"),

        array("name" => "रावस फिश करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/रावस-फिश-करी-रेसिपी-विधि"),

        array("name" => "फिश फ्राई", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/फिश-फ्राई-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "Nutrients to support immunity in active children", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/nutrients-support-immunity-active-children")
      );
    } else if($nutrient_name == 'टोटल_फोलेट_विटामिन_b9') {
      $nutrients['desc'] = "<h4>टोटल फोलेट्स (विटामिन B9) का महत्व और यह किस तरह से इम्युनिटी बढ़ाने में मदद करता है।</h4><p>टोटल फोलेट (विटामिन B-9) रेड ब्लड सेल्स के निर्माण और स्वस्थ सेल ग्रोथ के लिए ज़रूरी होता है</br>बच्चे के तेजी से बढ़े होने की अवधि के दौरान अच्छी मात्रा में टोटल फोलेट का सेवन करना बहुत ज़रूरी होता है।</p>";
      $nutrients['foods'] = array("ताज़ी बोम्बिल", "पॉम्फ्रेट", "झींगा", "रोहू", "बांगड़ा", "राजमा", "काला चना", "पालक");
      $nutrients["recipes"] = array(
        array("name" => "बोम्बिल (बॉम्बे डक) फिश फ्राई", "seo_name" => "recipes/बोम्बिल-फिश-फ्राई-रेसिपी-विधि"),
        array("name" => "ग्रिल्ड पॉम्फ्रेट", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/ग्रिल्ड-पॉम्फ्रेट-रेसिपी-विधि"),

        array("name" => "झींगा करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/झींगा-करी-रेसिपी-विधि"),

        array("name" => "रोहु फिश करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/रोहु-फिश-करी-रेसिपी-विधि"),

        array("name" => "बांगड़ा करी", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/बांगड़ा-करी-रेसिपी-विधि"),

        array("name" => "राजमा चावल", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/राजमा-चावल-रेसिपी-विधि"),

        array("name" => "चना सोया कटलेट", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/चना-और-सोया-कटलेट-रेसिपी-विधि"),

        array("name" => "केला पालक मिल्कशेक", "img" => "/themes/custom/nestle_new/common/images/1-chicken-masala-curry.png", "seo_name" => "recipes/केला-पालक-मिल्कशेक-रेसिपी-विधि")
      );
      $nutrients["articles"] = array(
        array("title" => "आपके बच्चे के लिए शाकाहारी खाने की योजना कैसे बनाएँ", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/आपके-बच्चे-के-लिए-शाकाहारी-खाने-की-योजना-कैसे-बनाएँ"),

        array("title" => " बच्चों के लिए पोषण से भरपूर रेसिपी", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-के-लिए-पोषण-से-भरपूर-रेसिपी"),
        array("title" => "इन गर्मियों में बेहद फ़ायदेमंद होगी यह प्रोटीन गाइड", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/इन-गर्मियों-में-बेहद-फ़ायदेमंद-होगी-यह-प्रोटीन-गाइड"),

        array("title" => "बच्चों को सर्दियों में खिलाएं ये पौष्टिक और सेहतमंद व्यंजन", "img" => "/themes/custom/nestle_new/common/images/1-why-these.png",  "url" => "expert-advice/बच्चों-को-सर्दियों-में-खिलाएं-ये-पौष्टिक-और-सेहतमंद-व्यंजन")
      );
    }
    $modalPopUp .= 

    '<div class="immuno-popup">
      <div class="immuno-popupinr"> <span class="close-immunopopup"></span>
      <div class="immuno-popupcont">
      <h2 class="tips-icon">'.(($hindi)?'आपकी इम्युनिटी बढ़ाने के टिप्स':'Tips to boost your Immunity').'</h2>
      <div class="tips-tab"> 
        <a href="#food-tips" class="active-tip">'.(($hindi)?'भोजन':'Foods').'</a> 
        <a href="#recipies-tips">'.(($hindi)?'रेसिपी':'Recipes').'</a> 
        <a href="#articles-tips">'.(($hindi)?'आर्टिकल':'Articles').'</a> 
      </div>
      <div class="contscrol"> <div class="tips-commonbox" id="food-tips"> <div class="hd-tips">'.ucwords($nutrient).'</div>'.$nutrients['desc'].(($rda_color=='overred')?'<p class="nutrients-note">'.(($hindi)?'जब पोषक तत्वों का ज़्यादा मात्रा में सेवन किया जाता है तो जिन खाद्य पदार्थ से ये चीज़ें मिल रही हैं उन पर ध्यान देने की ज़रुरत है। इनकी   मात्रा को सीमित करने से आपको सही मात्रा में ये चीज़ें लेने में मदद मिल सकती है।':'Nutrients when consumed in excess require attention to the food sources contributing to the same. Restricting portion size of these can be helpful to limit dietary intake').'</p>':'').'<ul class="food-tiplist">';
      
    foreach($nutrients['foods'] as $food) {
      $modalPopUp .= '<li> <span>'.$food.'</span> </li>';
    }

    $modalPopUp .= '</ul> </div> <div class="tips-commonbox" id="recipies-tips"> <div class="hd-tips">'.ucwords($nutrient).'</div><h3>'.(($hindi)?'कृपया <span>'.$nutrient.'</span> से भरपूर रेसिपी चेक करें। ':'Please check Recipes which are rich in <span>'.strtolower($nutrient)).'</span></h3> <ul class="recipes-tiplist">';

    foreach($nutrients['recipes'] as $recipe) {
      $modalPopUp .= '<li><a href="'.$recipe['seo_name'].'" target="_blank" data-url="'.$recipe['seo_name'].'" data-type="Recipe" data-nutri="'.$nutrient.'"><span><img src="'.$recipe['img'].'" alt=""></span> <em>'.$recipe['name'].'</em></a></li>';
    }

    $modalPopUp .= '</ul> </div> <div class="tips-commonbox" id="articles-tips"> <div class="hd-tips">'.ucwords($nutrient).'</div><h3>'.(($hindi)?'कृपया <span>'.$nutrient.'</span> से भरपूर चीज़ों के आर्टिकल चेक करें।':'Please Read more about food items rich in <span>'.strtolower($nutrient)).'</span></h3> <ul class="articles-tiplist">';

    foreach($nutrients['articles'] as $article) {
      $modalPopUp .= '<li><a href="'.(($hindi)?'hindi/':'').$article['url'].'" target="_blank" data-url="'.(($hindi)?'hindi/':'').$article['url'].'" data-type="Article" data-nutri="'.$nutrient.'"><span><img src="'.$article['img'].'" alt=""></span> <em>'.$article['title'].'</em></a></li>';
    }

    $modalPopUp .= '</div></div></div></div>';

    $data['nutri_data'] = $modalPopUp;
    $data['childAge'] = $childAge;
    $data['gender'] = $gender;

    return new JsonResponse($data);
  }

  public function firstPage() {
    return [
      '#theme' => 'immunityFirstPage',
    ];
  }

  /**
   * Add food diary meal as per @request.
   */
  public function addFoodMeal(Request $request) {
    $session = \Drupal::request()->getSession();
    $immunityData = $session->get('immunityData');
    $childAge =  $immunityData['immunityAge'];
    $Gender = $immunityData['immunityGender'];
    $Genderval = (!empty($Gender) ? '1' : '2');
    $foodId = $request->query->get('foodId');
    $qntId = $request->query->get('qntId');
    $servUnt = $request->query->get('servUnt');
    $mealName = $request->query->get('mealName');
    $child_id = $immunityData['immunityClientk'];
    $participationKey = $immunityData['immunityparticipationK'];
    $hindi = CommonFunc::isHindi();
    $post_data = [
      'client_key' => $child_id,
      'age' => $childAge,
      'food_id' => $foodId,
      'quantity' => $qntId,
      'unit_id' => $servUnt,
      'gender_id' => $Genderval
    ];
    $post_data = CommonFunc::APiHindi($post_data);
    if($hindi) {
      $hindiArr = array("alias" => $mealName);
      $post_data  = array_merge($post_data, $hindiArr);
    }
    $addFoodMeal = NestleAPI::addImmunityEntry($post_data);

    $retrive_post_data = [
    'client_key' => $child_id,
    'participation_key' => $participationKey,
    ];
    $retrive_post_data = CommonFunc::APiHindi($retrive_post_data);
    $getImmunityClient = NestleAPI::retriveImmunityEntry($retrive_post_data);
   
    $today = date('d-m-Y');
    $SavedDataArr = array_reverse($getImmunityClient['contents']['meal_entries'][$today]);
    $meal_term['immunityData'] = CommonDiary::immunityScoreDom($SavedDataArr);
	$meal_term['debug'] = array_reverse($getImmunityClient['contents']['meal_entries'][$today]);
	$debug1 = end(array_reverse($getImmunityClient['contents']['meal_entries'][$today]));
	$meal_term['entry_food_id'] = $debug1['food_entry_id'];
    $meal_term['immunityScore'] = strtolower(reset(explode(' ',$getImmunityClient['contents']['immunity_score_zone'])));
    $meal_term['childAge'] = $childAge;
    $meal_term['childGender'] = $Genderval;
    $meal_term['nutrients_data'] = $getImmunityClient['contents']['analysis'];
    return new JsonResponse($meal_term);
  }

  /**
   * Add food immunity meal as per @request.
   */
  public function deleteMealImmunity(Request $request) {
    $session = \Drupal::request()->getSession();
    $immunityData = $session->get('immunityData');
    $child_id = $immunityData['immunityClientk'];
    $participationKey = $immunityData['immunityparticipationK'];
    $food_entry_id = $request->query->get('food_entry_id');
    $post_data = [
      'client_key' => $child_id,
      'participation_key' => $participationKey,
      'food_entry_id'=>$food_entry_id
    ];
    $post_data = CommonFunc::APiHindi($post_data);
    $getImmunityClient = NestleAPI::deleteImmunityEntry($post_data);
    $SavedDataArr['color'] = strtolower(reset(explode(' ',$getImmunityClient['contents']['immunity_score_zone'])));
    $SavedDataArr['nutrients_data'] = $getImmunityClient['contents']['analysis'];
    return new JsonResponse($SavedDataArr);
  }
	/**
	* Add food immunity meal as per @request.
	*/
	public function updateMealImmunity(Request $request) {
		
		$session = \Drupal::request()->getSession();
		$immunityData = $session->get('immunityData');

		$food_entry_id = $request->query->get('food_entry_id');
		$fd_quantity_val = $request->query->get('fd_quantity_val');
		$fd_serUnit_val = $request->query->get('fd_serUnit_val');
		$child_id = $immunityData['immunityClientk'];
		$participationKey = $immunityData['immunityparticipationK'];

		$post_data = [
		'client_key' => $child_id,
		'participation_key' => $participationKey,
		'food_entry_id' => $food_entry_id,
		'quantity' => $fd_quantity_val,
		'unit_id' => $fd_serUnit_val
		];

		$post_data = CommonFunc::APiHindi($post_data);
		$editFoodMeal = NestleAPI::editImmunityEntry($post_data);
        

		$meal_term['immunityScore'] = $editFoodMeal['contents']['immunity_score_zone'];

		$meal_term['nutrients_data'] = $editFoodMeal['contents']['analysis'];
        
		return new JsonResponse($meal_term);
	}
}
