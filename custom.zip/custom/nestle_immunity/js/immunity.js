/**
 * @file
 * Handles AJAX fetching of food nutrients post records , including filter submission and response.
 */

(function ($, Drupal) {
	'use strict';
	/**
	 * Attaches the AJAX behavior to fetch post records and filters.
	 *
	 * @type {Drupal~behavior}
	 *
	 * @prop {Drupal~behaviorAttach} attach
	 *   Attaches ajax functionality to relevant elements.
	 */
	Drupal.behaviors.immunity = {
		attach: function (context) {
			$('#get_immunity_datan').once().click(function() {
				var laoderHtml = '<div class="loader"></div>';
				var dobYr = $('#vital_dobYr').val();
				var dobMth = $('#vital_dobMth').val();
				if (dobYr == '') {
					$(".dobyr-form-error").html('Enter Year between 2 to 12');
					$('#vital_dobYr').css('border-color', 'red');
					$('.dobyr-form-error').css('color', 'red');
					$('#vital_dobYr').focus();
					return false;
				}
				if(dobYr ==1) {
					$(".dobyr-form-error").html('Enter Year between 2 to 12');
					$('#vital_dobYr').css('border-color', 'red');
					$('.dobyr-form-error').css('color', 'red');
					$('#vital_dobYr').focus();
					return false;	
				}
				if(dobYr == 0) {
					$(".dobyr-form-error").html('Enter Year between 2 to 12');
					$('#vital_dobYr').css('border-color', 'red');
					$('.dobyr-form-error').css('color', 'red');
					$('#vital_dobYr').focus();
					return false;	
				}
				if(dobYr >12) {
				    $(".dobyr-form-error").html('Enter Year between 2 to 12');
					$('#vital_dobYr').css('border-color', 'red');
					$('.dobyr-form-error').css('color', 'red');
					$('#vital_dobYr').focus();
					return false;	
				}
				if(isNaN(dobYr)) {
					$(".dobyr-form-error").html('Enter Year between 2 to 12');
					$('#vital_dobYr').css('border-color', 'red');
					$('.dobyr-form-error').css('color', 'red');
					$('#vital_dobYr').focus();
					return false;
				}
				$(".dobyr-form-error").html('');
			    $('#vital_dobYr').css('border-color', '');
				$('.dobyr-form-error').css('color', '');
				if (dobMth == '') {
					$(".dobMth-form-error").html('Enter Month between 0 to 11');
					$('#vital_dobMth').css('border-color', 'red');
					$('.dobMth-form-error').css('color', 'red');
					$('#vital_dobMth').focus();
					return false;
				}
				if(dobMth > 11) {
				    $(".dobMth-form-error").html('Enter Month between 0 to 11');
					$('#vital_dobMth').css('border-color', 'red');
					$('.dobMth-form-error').css('color', 'red');
					$('#vital_dobMth').focus();
					return false;	
				}
				if(isNaN(dobMth)) {
					$(".dobMth-form-error").html('Enter Month between 0 to 11');
					$('#vital_dobMth').css('border-color', 'red');
					$('.dobMth-form-error').css('color', 'red');
					$('#vital_dobMth').focus();
					return false;
				}
				
				$(".dobMth-form-error").html('');
				$('#vital_dobMth').css('border-color', '');
				$('.dobMth-form-error').css('color', '');
				var gender = $('input[name="gender"]:checked').val();
				var lang = drupalSettings.language;
                var asdd = dobYr+'.'+dobMth;
				jQuery(laoderHtml).appendTo('.innerhtmlloader');
				if (lang == "hi") {
					var short_url = "hindi/";
				} else {
					var short_url = "";
				}
				
				jQuery.ajax({
					dataType: "json",
					url: drupalSettings.path.baseUrl + short_url + "show-immunity",
					data: {
						ym: dobYr+'.'+dobMth,
						gender: gender
					},
					success: function (immunity) {
						$('#immunity-score-div').html(immunity.immunityHtml);
						$('#display_data_id').html(immunity.immunityData);
						$('#child_age').val(immunity.childAge);
						$('#child_gender').val(immunity.gender);
						$(".loader").remove();
					}
				});
			});
			$('#vital_dobYr').once().change(function() {
				var dobyear = $("#vital_dobYr").val();
				if(dobyear == 50) {
					$("#vital_dobMth").attr('disabled','disabled');
					$("#vital_dobMth").val(0);
				} else {
					$("#vital_dobMth").attr('disabled',false);
				}
				
			});
			$('#vital_dobMth').once().change(function() {
				var dobyear = $("#vital_dobYr").val();
				if(dobyear == 50) {
					$("#vital_dobMth").attr('disabled','disabled');
					$("#vital_dobMth").val(0);
				} else {
					$("#vital_dobMth").attr('disabled',false);
				}
				
			});
			

			$(document).on('click', '.immunity-modal-header ul li', function (event) {
				var tagid = $(this).attr('data');
				$('.immunity-modal-header ul li').removeClass('current');
				$('.immunitymodaldetail').removeClass('current')
				$(this).addClass('current');
				$('#' + tagid).addClass('current');
				var body = $(".immunity-modal-content");
				body.stop().animate({scrollTop:0}, 500, 'swing');
				event.preventDefault();
				event.stopPropagation();

			});

			$(document).on('click', '.immunitynutrient ul  li', function () {
				var tagid = $(this).attr('data-tab');
				$('#' + tagid).fadeIn();
			});

			$(document).on('click', '#immunity-score-div .immunity-modal-body .close', function (event) {
				event.stopImmediatePropagation();

				$('.immunity-modal').remove();
			});

			var lang = drupalSettings.language;
			if (lang == "hi") {
				var short_url = "hindi/";
			} else {
				var short_url = "";
			}
			var Circlevalue = jQuery('span.rate').text();
			var laoderHtml = '<div class="loader"></div>';
			var succesHtml = '<div class="updateMessage">Food Entry has been saved successfully</div>';

			if ($('.growth-gender input').is(":checked")) {
				$('.growth-gender input:checked').parents('.growth-gender .form-item-gender').addClass("m-checkbox");
			}
			$(".growth-gender input", context).click(function () {
				$('.growth-gender input:not(:checked)').parents('.growth-gender .form-item-gender').removeClass("m-checkbox");
				$('.growth-gender input:checked').parents('.growth-gender .form-item-gender').addClass("m-checkbox");
			});
			/**
			 * Range Slider age.
			 */
			if ($('#ch_dob').length > 0) {
				var slider = document.getElementById("ch_dob");
				var month = document.getElementById("demoMonth");
				var year = document.getElementById("demoYear");
				year.innerHTML = "2";
				month.innerHTML = "24";
				var Spntxt = $(month).text();
				year.innerHTML = slider.value == 2 ? 0 : slider.value;
				month.innerHTML = slider.value;
				$(slider).attr('min', Spntxt)
				slider.oninput = function () {
					if (this.value > 11) {
						var years = Math.floor(this.value / 12);
						year.innerHTML = years;
						var months = this.value % 12;
						month.innerHTML = months
						$('#vital_dobYr').val(years);
						$('#vital_dobMth').val(months);
					} else {
						var years = Math.floor(this.value / 12);
						year.innerHTML = years;
						month.innerHTML = this.value;
						$('#vital_dobYr').val(years);
						$('#vital_dobMth').val(this.value);
					}
				};
				year.innerHTML = "2";
				month.innerHTML = "0";
			}

			/**
			 * Reintialize event after ajax response.
			 */
			$(window).bind("load", function (event) {
				event.stopImmediatePropagation();
				//OnloadImmunityNutritions();
				//alert('hh')
			});

			checkevents();

			function OnloadImmunityNutritions() {

				var lang = drupalSettings.language;
				if (lang == "hi") {
					var short_url = "hindi/";
				} else {
					var short_url = "";
				}
				
				var selectedDateval = "1";

				jQuery(laoderHtml).appendTo('#display_data_id');
				jQuery.ajax({
					dataType: "json",
					'async': false,
					url: drupalSettings.path.baseUrl + short_url + "immunity/onload-immunity",
					data: {
						selectedDateval: selectedDateval
					},
					success: function (dataNew) {
						checkevents();

						jQuery('#child_age').val(dataNew.childAge);
						jQuery('#child_gender').val(dataNew.gender);

						$('#immunity-score-div').html(dataNew.immunityHtml);
						$('#display_data_id').html(dataNew.immunityData);

						jQuery('.loader').remove();
					}
				});
			}

			/**
			 * Food Qty Plus Minus increments and calling related events.
			 */
			function checkevents() {
				jQuery(document).on("click", ".qt", function (event) {
					event.stopImmediatePropagation();

					var $button = $(this);
					var oldValue = Drupal.checkPlain($button.closest(this).parents('.food-dairy-form').find(".food-qty").val());
					if (oldValue == "0") {
						var newVal = parseFloat(oldValue) + 0.5;
					} else if (oldValue == "0.5") {
						var newVal = parseFloat(oldValue) + 0.5;
					} else if ($button.text() == "+") {
						var newVal = parseFloat(oldValue) + 1;
					} else {
						if (oldValue > 1) {
							var newVal = parseFloat(oldValue) - 1;
						} else if (oldValue = 1) {
							var newVal = parseFloat(oldValue) - 0.5;
						} else if (oldValue = 0) {
							var newVal = parseFloat(oldValue) - 0.5;
							newVal = 0
						} else {
							newVal = 0;
						}
					}
					console.log("HowManyTimes");
					$button.closest(this).parents('.food-dairy-form').find(".food-qty").val(newVal);
				});

				var QTYInput = jQuery('.grp.qty').find('.food-qty').val();
				if (QTYInput == 0) {
					jQuery('.qt.minus').addClass('pointer');
				}
				jQuery('.qt.minus').click(function () {
					var QTYInputs = jQuery('.grp.qty').find('.food-qty').val();
					if (QTYInputs == '0.5') {
						jQuery('.minus').addClass('pointer');
					}
				});

				/* jQuery('.log-nav #display_data_id', context).on('click', '.qt.plus', function () {
					console.log('yes');
					jQuery('.qt.minus').removeClass('pointer');
				}); */
				/**
				 * Get food nutrients details on the basis of meal timing and serving unit.
				 */
				//jQuery('.search_meal_cls').keyup(function () {
				jQuery(document).on('keyup', '.search_meal_cls', function (event) {
					event.stopImmediatePropagation();
					//alert('hi')
					var lang = drupalSettings.language;
					if (lang == "hi") {
						var short_url = "hindi/";
					} else {
						var short_url = "";
					}
					var key = jQuery(this).attr('data-key');
					jQuery(".replacesearchData_" + key).show();
					var searchFoodVal = jQuery('#search_meal_frm_' + key).val();

					jQuery.ajax({
						dataType: "json",
						url: drupalSettings.path.baseUrl + short_url + "immunity/search-meal",
						data: {
							q: searchFoodVal
						},
						success: function (data) {
							jQuery('.replacesearchData_' + key).html('');

							var content = '';
							var i = 0;
							for (; data[i];) {
								// Create dynamic element.
								jQuery("<div></div>", {
									"text": data[i]['label'],
									"data-eng": data[i]['eng'],
									"data-key": data[i]['value'],
									"data-title": data[i]['label'],
									"class": 'searchAutofood',
									"on": {
										"click": function (event) {
											jQuery.ajax({
												dataType: "json",
												url: drupalSettings.path.baseUrl + short_url + "immunity/meal-unit",
												data: {
													key: jQuery(this).attr('data-key'),
													title: jQuery(this).attr('data-title')
												},
												success: function (units) {

													//alert(units)
													jQuery('.unit_' + key).html('');
													var len = units.length;
													var html = '';
													for (var i = 0; i < len; i++) {
														html += '<option data-eng="' + units[i].eng + '" value="' + units[i].id + '">' + units[i].title + '</option>';
													}
													jQuery('.unit_' + key).html(html);
												}
											});
										}
									}
								}).appendTo(".replacesearchData_" + key);
								i++;
							}
							jQuery(".searchAutofood").once().click(function () {
								var recipeName = jQuery(this).attr('data-title');
								var recipeEng = jQuery(this).attr('data-eng');
								var recipeId = jQuery(this).attr('data-key');
								jQuery('#search_meal_frm_' + key).val(recipeName);
								jQuery('#search_meal_frm_' + key).attr('data-eng', recipeEng);
								jQuery('#search_meal_frm_alt_' + key).val(recipeId);
								jQuery(".replacesearchData_" + key).hide();
							});
						}
					});
				});

				/**
				 *Food diary validation
				 */

				jQuery(document).on('click', '.fd_btn_clk', function (event) {
					event.stopImmediatePropagation();

					var lang = drupalSettings.language;
					if (lang == "hi") {
						var short_url = "hindi/";
					} else {
						var short_url = "";
					}

					var nutirents = '';
					var selectedDateval = jQuery(".active").attr("data-date");
					var chk = jQuery(this).attr('id');
					var getId = chk.split(['fd_btn_']);
					var key = getId[1];
					console.log(key, 'getId')
					var fd_search_val = Drupal.checkPlain(jQuery('#search_meal_frm_alt_' + key).val());
					var fd_quantity_val = Drupal.checkPlain(jQuery('#food_qty_' + key).val());
					var fd_serUnit_val = Drupal.checkPlain(jQuery('#unit_' + key).val());
					var fd_timeslt_val = Drupal.checkPlain(jQuery('#fd_time_val_' + key).val());
					var fd_search_act = Drupal.checkPlain(jQuery('#search_meal_frm_' + key).val());
					var prts = jQuery(this).parents('.food-dairy-form');

					if (fd_search_act === "") {
						prts.find('.search').addClass('balert')
					} else {
						jQuery('.search').removeClass('balert');
					}
					if (fd_quantity_val < "0.5") {
						prts.find('.qty').addClass('balert')
					} else {
						jQuery('.qty').removeClass('balert');
					}
					if (fd_serUnit_val === "0") {
						prts.find('.select').addClass('balert')
					} else {
						jQuery('.select').removeClass('balert');
					}
					if (fd_search_val !== "" && fd_quantity_val !== "0" && fd_serUnit_val !== "0") {

						jQuery(laoderHtml).appendTo('#immunityRepID_' + fd_timeslt_val);
						var meal_name = $('#search_meal_frm_'+key).val();
						var quantity = $('#food_qty_'+key).val();
						var servingUnit = $('#unit_'+key+' option:selected').text();
						var childGender = $('input[name="gender"]:checked').val();

						jQuery.ajax({
							dataType: "json",
							url: drupalSettings.path.baseUrl + short_url + "immunity/add-meal",
							data: {
								foodId: fd_search_val,
								qntId: fd_quantity_val,
								servUnt: fd_serUnit_val,
								timeSltval: fd_timeslt_val,
								countVal: getId[1],
								selectedDateval: selectedDateval,
								mealName: fd_search_act
							},
							success: function (foodNutrientData) {
								var Imntyvalue = foodNutrientData.immunityScore;
								var childAge = foodNutrientData.childAge;

								dataLayer.push({
									"event": "AddMealItem",
									"EventAction": "Add Food Item",
									"EventLabel": meal_name,
									"ChildAge": childAge,
									"ChildGender": ((childGender==1)?"Boy":"Girl"),
									"FoodName": meal_name,
									"quantity": quantity,
									"servingUnit": servingUnit,
									"foodPosition": parseInt(key) + 1,
									"ImmunityScore": Imntyvalue,
								});

								dataLayer.push({
									"event": "ImmunityScore",
									"EventAction": "Add Food Item",
									"EventLabel": meal_name,
									"ChildAge": childAge,
									"ChildGender": ((childGender==1)?"Boy":"Girl"),
									"FoodName": meal_name,
									"quantity": quantity,
									"servingUnit": servingUnit,
									"ImmunityScore": Imntyvalue,
								});

								jQuery('#immunity-score-div .immunity-graph div.immunity-child').attr('class', 'immunity-child');
								jQuery('#immunity-score-div .immunity-graph div.immunity-child').addClass(Imntyvalue);
								jQuery('#immunity-score-div .immunity-child').effect("shake", 1500);

								$.each(foodNutrientData.nutrients_data, function (key, value) {
									nutirents += '<li data-tab="tab-'+ (key+1) +' " class="modal-tab"><div class="left">' + value.name + '</div><div class="right"><span class="dotcircle '+ value.class_color+'"></span></div></li>';
								});
		
								jQuery('#immunity-score-div .nutrients_rda').html(nutirents);
								jQuery('#immunity-score-div #display_data_id').html(foodNutrientData.immunityData);

								checkevents();
								jQuery('.loader').remove();
								//hideShowRdaMessage();
							}
						});
					}
				});

				/**
				 * Update Meal Food Diary.
				 *
				 * @param {jQuery.Event}
				 *   The jQuery event on update meal.
				 */
				jQuery('.fd_btn_clk_pst').unbind();
				// jQuery('.fd_btn_clk_pst').bind('click', function () {
				jQuery(document).on('click', '.fd_btn_clk_pst', function (event) {
					event.stopImmediatePropagation();
					var lang = drupalSettings.language;
					if (lang == "hi") {
						var short_url = "hindi/";
					} else {
						var short_url = "";
					}

					var nutirents = '';
					var chk = jQuery(this).attr('id');
					var selectedDateval = jQuery(".active").attr("data-date");
					var getId = chk.split(['fd_btn_pst_']);

					var food_entry_id = Drupal.checkPlain(jQuery('#search_meal_frm_alt_' + getId[1]).val());
					var fd_quantity_val = Drupal.checkPlain(jQuery('#food_qty_' + getId[1]).val());
					var fd_serUnit_val = Drupal.checkPlain(jQuery('#unit_' + getId[1]).val());
					var fd_timeslt_val = Drupal.checkPlain(jQuery('#fd_time_val_' + getId[1]).val());
					var fd_search_act = Drupal.checkPlain(jQuery('#search_meal_frm_' + getId[1]).val());
					jQuery(laoderHtml).appendTo('#immunityRepID_' + fd_timeslt_val);
					jQuery.ajax({
						dataType: "json",
						url: drupalSettings.path.baseUrl + short_url + "immunity/update-meal",
						data: {
							food_entry_id: food_entry_id,
							fd_quantity_val: fd_quantity_val,
							fd_serUnit_val: fd_serUnit_val,
							fd_timeslt_val: fd_timeslt_val,
							selectedDateval: selectedDateval,
							mealName: fd_search_act
						},
						success: function (updateNutrientData) {

							jQuery('#immunity-score-div #immunityRepID_' + getId[1]).html(updateNutrientData.immunityData);
							var Imntyvalue = updateNutrientData.immunityScore;

							jQuery('#immunity-score-div .immunity-graph div.immunity-child').attr('class', 'immunity-child');
							jQuery('#immunity-score-div .immunity-graph div.immunity-child').addClass(Imntyvalue);
							jQuery('#immunity-score-div .immunity-child').effect("shake", 1500);
							
							$.each(updateNutrientData.nutrients_data, function (key, value) {
								nutirents += '<li data-tab="tab-'+ (key+1) +' " class="modal-tab"><div class="left">' + value.name + '</div><div class="right"><span class="dotcircle '+ value.class_color+'"></span></div></li>';
							});
							jQuery('#immunity-score-div .nutrients_rda').html(nutirents);
							
							jQuery('.loader').remove();
						}
					});
				});

				/**
				 * Delete Meal Food Diary.
				 *
				 * @param {jQuery.Event}
				 *   The jQuery event on delete meal.
				 */

				// jQuery('.fd_btn_pst_del').once().click(function() {

				jQuery(document).on('click', '#display_data_id .fd_btn_pst_del', function (event) {
					event.stopImmediatePropagation();
					var lang = drupalSettings.language;
					if (lang == "hi") {
						var short_url = "hindi/";
					} else {
						var short_url = "";
					}

					var nutirents = '';
					var chk = jQuery(this).attr('id');
					var getId = chk.split(['fd_btn_pst_del_']);
					var food_entry_id = Drupal.checkPlain(jQuery('#search_meal_frm_alt_' + getId[1]).val());
					var fd_timeslt_val = Drupal.checkPlain(jQuery('#fd_time_val_' + getId[1]).val());
					var confirmDel = '';
					var foodcnt = "";
					if (lang == "hi") {
						foodcnt = "क्या आप इस फ़ूड को हटाना चाहते हैं?"

					} else {
						foodcnt = "Do you want to delete this food entry?"
					}

					if (confirm(foodcnt)) {
						confirmDel = 1;
					} else {
						confirmDel = 2;
					}
					if (confirmDel == 1) {


						jQuery(laoderHtml).appendTo('#immunityRepID_' + fd_timeslt_val);
						jQuery.ajax({
							dataType: "json",
							url: drupalSettings.path.baseUrl + short_url + "immunity/delete-meal",
							data: {
								food_entry_id: food_entry_id
							},
							success: function (deleteNutrientData) {
								jQuery('#immunity-score-div #immunityRepID_' + fd_timeslt_val).remove();
								var Imntyvalue = deleteNutrientData.color;
								jQuery('#immunity-score-div .immunity-graph div.immunity-child').attr('class', 'immunity-child');
								jQuery('#immunity-score-div .immunity-graph div.immunity-child').addClass(Imntyvalue);
								jQuery('#immunity-score-div .immunity-child').effect("shake", 1500);
								
								$.each(deleteNutrientData.nutrients_data, function (key, value) {
									nutirents += '<li data-tab="tab-'+ (key+1) +' " class="modal-tab"><div class="left">' + value.name + '</div><div class="right"><span class="dotcircle '+ value.class_color+'"></span></div></li>';
								});
		
								jQuery('#immunity-score-div .nutrients_rda').html(nutirents);
								
								jQuery('.loader').remove();
								//hideShowRdaMessage();;
							}
						});
					}
				});
			}
			
			$(document).on('click', '.immunitynutrient .modal-tab', function (event) {
				event.stopImmediatePropagation();
				
				var nutrient = $(this).find('.left').html();
				var color = $(this).find('.right span').attr('class');
				color = color.split(" ");

				var foods = '';
				$('#immunity-score-div .search_meal_cls').each(function() {
					if($(this).val() != '') {
						foods += $(this).val()+', ';
					}
				});

				var food_qantity = '';
				$('#immunity-score-div .food-qty').each(function() {
					if($(this).val() != 0) {
						food_qantity += $(this).val()+', ';
					}
				});

				var serving = '';
				$('#immunity-score-div select[name^="unit_"]').each(function() {
					if($(this).find(":selected").val() != 0) {
						serving += $(this).find(":selected").text()+', ';
					}
				});

				jQuery.ajax({
					dataType: "json",
					url: drupalSettings.path.baseUrl + short_url + "immunity/nutrients",
					data: {
						nutrient: nutrient,
						rda_color: color[1]
					},
					success: function (nutrients) {
						jQuery('.immunity-modal').remove();
						jQuery('#immunity-score-div .immunitynutrient').after(nutrients.nutri_data);
						jQuery('.immunity-modal').fadeIn();

						dataLayer.push({
							"event": "CheckNutrients",
							"EventAction": nutrient,
							"EventLabel": "Food",
							"ChildAge": nutrients.childAge,
							"ChildGender": ((nutrients.gender==1)?"Boy":"Girl"),
							"FoodName": foods,
							"quantity": food_qantity,
							"servingUnit": serving,
							"ImmunityScore": color[1],
						});
					}
				});
			});

			$('.tabfimmuno').unbind()
			$('.tabfimmuno').bind('click', function(){
				$(this).toggleClass('down');
				$('.immunodetail').slideToggle();
			});
			
			
			$('.immuno-ques').click(function(){
				$('.immunoques-model').fadeIn();
			});
				$('.imclose').click(function(){
				$('.immunoques-model').fadeOut();
			});
			
			$(function() {
				$(window).scroll(function(){
					var Windowscroll = $(window).scrollTop();
					if (Windowscroll >= 1414){
						$('.growth-track-form-wapper.immunodetail').slideUp();
						$('.tabfimmuno').removeClass('down')
					}
				});	
			});

			/**
			 * Use to show or hide message on empty RDA grid.
			 * Called on meal add, delete and update.
			 */
//			function hideShowRdaMessage() {
//				if (jQuery('.food-dairy-form:first-child .search .search_meal_cls').val() == "" || jQuery('.food-dairy-form:first-child .search .search_meal_cls').val() == undefined) {
//					if (lang == "hi") {
//						var noShowStr = '<tr class="noshow-msg"><td colspan="4"><h4>कृपया परिणाम प्राप्त करने के लिए भोजन योजना जोड़ें।</h4></td></tr>';
//					} else {
//						var noShowStr = '<tr class="noshow-msg"><td colspan="4"><h4>Please add meal plan to get the results.</h4></td></tr>';
//					}
//					//jQuery(".noshow-msg").removeClass("hidden");
//					jQuery(".immunity-table tbody").html(noShowStr);
//				}
//			}
		}
	}
})(jQuery, Drupal);