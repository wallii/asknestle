/**
* @file
* Handles AJAX fetching of food nutrients post records , including filter submission and response.
*/

(function ($, Drupal) {
	'use strict';
	/**
	* Attaches the AJAX behavior to fetch post records and filters.
	*
	* @type {Drupal~behavior}
	*
	* @prop {Drupal~behaviorAttach} attach
	*   Attaches ajax functionality to relevant elements.
	*/
	function hindiUrl(){
		var lang = drupalSettings.path.currentLanguage;
		if (lang == "hi") {
		var short_url = "hindi/";
		} 
		else {
		var short_url = "";
		}
		return short_url;
	}
	/**
	  add Immunity
	**/
	var laoderHtml = '<div class="loader"><span></span></div>';
	$('#get_immunity_datan').click(function() {
		var laoderHtml = '<div class="loader"><span></span></div>';
		var dobYr = $('#vital_dobYr').val();
		var dobMth = $('#vital_dobMth').val();
		if (dobYr == '') {
			$(".dobyr-form-error").html('Enter Year between 2 to 12');
			$('#vital_dobYr').css('border-color', 'red');
			$('.dobyr-form-error').css('color', 'red');
			$('#vital_dobYr').focus();
			return false;
		}
		if(dobYr ==1) {
			$(".dobyr-form-error").html('Enter Year between 2 to 12');
			$('#vital_dobYr').css('border-color', 'red');
			$('.dobyr-form-error').css('color', 'red');
			$('#vital_dobYr').focus();
			return false;	
		}
		if(dobYr == 0) {
			$(".dobyr-form-error").html('Enter Year between 2 to 12');
			$('#vital_dobYr').css('border-color', 'red');
			$('.dobyr-form-error').css('color', 'red');
			$('#vital_dobYr').focus();
			return false;	
		}
		if(dobYr >12) {
			$(".dobyr-form-error").html('Enter Year between 2 to 12');
			$('#vital_dobYr').css('border-color', 'red');
			$('.dobyr-form-error').css('color', 'red');
			$('#vital_dobYr').focus();
			return false;	
		}
		if(isNaN(dobYr)) {
			$(".dobyr-form-error").html('Enter Year between 2 to 12');
			$('#vital_dobYr').css('border-color', 'red');
			$('.dobyr-form-error').css('color', 'red');
			$('#vital_dobYr').focus();
			return false;
		}
		$(".dobyr-form-error").html('');
		$('#vital_dobYr').css('border-color', '');
		$('.dobyr-form-error').css('color', '');
		if (dobMth == '') {
			$(".dobMth-form-error").html('Enter Month between 0 to 11');
			$('#vital_dobMth').css('border-color', 'red');
			$('.dobMth-form-error').css('color', 'red');
			$('#vital_dobMth').focus();
			return false;
		}
		if(dobMth > 11) {
			$(".dobMth-form-error").html('Enter Month between 0 to 11');
			$('#vital_dobMth').css('border-color', 'red');
			$('.dobMth-form-error').css('color', 'red');
			$('#vital_dobMth').focus();
			return false;	
		}
		if(isNaN(dobMth)) {
			$(".dobMth-form-error").html('Enter Month between 0 to 11');
			$('#vital_dobMth').css('border-color', 'red');
			$('.dobMth-form-error').css('color', 'red');
			$('#vital_dobMth').focus();
			return false;
		}
		$(".dobMth-form-error").html('');
		$('#vital_dobMth').css('border-color', '');
		$('.dobMth-form-error').css('color', '');
		var gender = $('input[name="gender"]:checked').val();
		var asdd = dobYr+'.'+dobMth;
		jQuery(laoderHtml).appendTo('.main-wrp');
		var short_url = hindiUrl();
		jQuery.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "show-immunity",
			data: {
				ym: dobYr+'.'+dobMth,
				gender: gender
			},
			success: function (immunity) {
				$('#immunity-score-div').html(immunity.immunityHtml);
				$('#display_data_id').html(immunity.immunityData);
				$('#child_age').val(immunity.childAge);
				$('#child_gender').val(immunity.gender);
				$(".loader").remove();
			}
		});
	});
	
	/**
	  Immunity search food
	**/
	jQuery(document).on('keyup', '.srchfld', function (event) {

		var short_url = hindiUrl();
		var key = jQuery(this).attr('data-key');
		
		var searchFoodVal = jQuery('#search_meal_frm_' + key).val().trim();
		var searchFoodValleng = searchFoodVal.replace(/\s/g, ''.length);
		if (searchFoodValleng.length >= 3) {
			$('.srchfld').css('border-color', '');
			$(".food_ere").html('');
			jQuery.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "immunity/search-meal",
			data: {
				q: searchFoodVal
			},
			success: function (data) {
				if(data.length == 0){
					$('.srchfld').css('border-color', 'red');
					$(".food_ere").html('No food suggestion for this keyword');
					jQuery(".srchData-outr").hide();
				}else{
					$('.srchfld').css('border-color', '');
					$(".food_ere").html('');
					jQuery(".srchData-outr").show();
				}
				
				jQuery(".replacesearchData_" + key).show();
				jQuery('.replacesearchData_' + key).html('');
				var content = '';
				var i = 0;
				for (; data[i];) {
				// Create dynamic element.
				jQuery("<div></div>", {
				"text": data[i]['label'],
				"data-eng": data[i]['eng'],
				"data-key": data[i]['value'],
				"data-title": data[i]['label'],
				"class": 'searchAutofood srchDataItm',
				}).appendTo(".replacesearchData_" + key);
				i++;
				}
			}
		});
		}else{
			jQuery('.replacesearchData_0').html('');
			jQuery('.replacesearchData_0').hide();
		}
		
	});
	$(document).on('click', '.searchAutofood', function () {
		var laoderHtml = '<div class="loader"><span></span></div>';
		jQuery(laoderHtml).appendTo('.main-wrp');
		jQuery(".srchData-outr").hide();

		var recipeName = $(this).attr('data-title');
		var recipeEng = $(this).attr('data-eng');
		var recipeId = $(this).attr('data-key');
		var Atrvalue = $(this).attr('data-title');
		var AtrId = $(this).attr('data-key');
		var short_url = hindiUrl();
		$('.srchfld').val(recipeName);
		jQuery.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "immunity/meal-unit",
			data: {
				key: recipeId,
				title: Atrvalue
			},
			success: function (units) {			
				var len = units.length;
				var html = '';
				for (var i = 0; i < len; i++) {
				html += '<option data-eng="' + units[i].eng + '" value="' + units[i].id + '">' + units[i].title + '</option>';
				}
				//jQuery('.unit_' + key).html(html);
				var lHtml = '<div class="foodlist-item nadded"><div class="foodlist-item-dtls"><div class="fooditem-name"> <span data-id="'+AtrId+'" data-title="'+Atrvalue+'">'+Atrvalue+'</span></div></div><div class="fooditem-edtbox" style="display: block;"><div class="food-unitqty"><div class="fooditem-unit"><select class="droplist">'+html+'</select></div><div class="fooditem-qty"><div class="addminus-form">          <input type="button" value="" class="minus btn-addminus">          <input type="text" value="0" class="qty">          <input type="button" value="" class="add btn-addminus">        </div>      </div>    </div></div></div>';
				$("#search_meal_frm_0").attr('data-title',Atrvalue);
				$("#search_meal_frm_0").attr('data-id',AtrId);
				let hasnotadded = $(".foodlist-items-row .foodlist-item").hasClass('nadded');
				if(hasnotadded) {
				jQuery(".nadded").remove();
				} 
				jQuery(".foodlist-items-row").append(lHtml);
				$(".replaceslist").hide();
				$(".loader").remove();				
			}
		});
	});
	
	/**
	Add Plus minus quantity
	**/
	$(document).on('click', '.add', function (event) {

		let oldValue = Drupal.checkPlain($(this).prev(".qty").val());
		let newVal = '';
		if (oldValue == "0") {
		newVal = parseFloat(oldValue) + 0.5;
		} else if (oldValue == "0.5") {
		newVal = parseFloat(oldValue) + 0.5;
		} else if (oldValue >= 0.5) {
		newVal = parseFloat(oldValue) + 0.5;
		} 
		$(this).prev(".qty").val(newVal);
		$('.qty').css('color', '');	

	});
	
	$(document).on('click', '.minus', function (event) {
		let hasclassadded = $(this).hasClass('added');
		if(hasclassadded) {
		alert('yes');
		} else {

		}
		let oldValue = Drupal.checkPlain($(this).next(".qty").val());
		let newVal = '';
		if (oldValue == "0") {
		newVal = oldValue;
		} else if (oldValue >= 0.5) {
		newVal = (parseFloat(oldValue) - 0.5);
		} 
		$(this).next(".qty").val(newVal);
	});

	/**
	Add Food for immunity check
	**/
	$(document).on('click', '#addFoodDiaryData', function (event) {
		var laoderHtml = '<div class="loader"><span></span></div>';
		var fooddatak = $(".srchfld").attr('data-id');
		var fooddataval = $(".srchfld").attr('data-title');

		if(fooddataval == '') {
			$('.srchfld').css('border-color', 'red');
			$(".food_ere").html('Value can not be empty');
		return false;
		} else {
			$('.srchfld').css('border-color', '');
			$(".food_ere").html('');	
		}

		var qunrt = $(".nadded .fooditem-unit .droplist").val();
		var qunrttitle = $( ".fooditem-unit .droplist option:selected" ).attr('data-eng');
		var qunrtval = $(".nadded .qty").val();
		if(qunrtval == 0) {
			$('.qty').css('color', 'red');
			return false;
		} else {
			$('.qty').css('color', '');	
		}
		var adfoodhtml ='';
		adfoodhtml += '<div class="foodlist-item-dtls">';
		adfoodhtml += '<div class="fooditem-name"><span>'+fooddataval+'</span><p><em data-id="'+qunrt+'">'+qunrttitle+'</em> <i>'+qunrtval+'</i></p></div>';
		adfoodhtml += '<div class="fooditem-dlt" style="display: block;" data-foodId="'+fooddatak+'" data-foodName="'+fooddataval+'"></div><div class="fooditem-edt acive-edt" data-foodId="'+fooddatak+'" data-foodName="'+fooddataval+'"></div>';
		adfoodhtml += '</div>';
		
		$(".nadded div.foodlist-item-dtls").replaceWith(adfoodhtml);
		$(".nadded .fooditem-edtbox").append( '<div class="btn-add"><button class=" updatefoodItem secnd-button">Update</button></div>' );
		$('.srchfld').val(' ');
		$('.srchfld').attr('data-title','');
		$('.srchfld').attr('data-id','');
		$('.added .fooditem-unit select').attr('disabled', true);
		$('.added div.addminus-form .btn-addminus').attr('disabled', true);
		let fd_search_val = fooddatak;
		let fd_quantity_val = qunrtval;
		let fd_serUnit_val = qunrt;
		let fd_search_act = fooddataval
		var short_url = hindiUrl();
		
		jQuery.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "immunity/add-meal",
			data: {
				foodId: fd_search_val,
				qntId: fd_quantity_val,
				servUnt: fd_serUnit_val,
				mealName: fd_search_act
			},
			beforeSend: function () {
			 $(laoderHtml).appendTo(".immuno-scl");
			},
			success: function (foodNutrientData) {
				console.log(foodNutrientData);
				
				var Imntyvalue = foodNutrientData.immunityScore;
				var childAge = foodNutrientData.childAge;
				var nutirents = '';
				$.each(foodNutrientData.nutrients_data, function (key, value) {
						nutirents += '<div class="item-tips" data-tab="tab-'+ (key+1) +' " class="modal-tab"><div class="tips-title">' + value.name + '</div><div class="tips-graph"><div class="tips-graph-box"><div class="col25 '+ value.class_color+'-color"></div></div></div><div class="tips-popup" data-nutriname="'+ value.name +'" data-nutricolor="'+value.class_color+'"><a href="javascript:void(0)">Tips</a></div></div>';
					});
				$('.nutrient-tips-list').html(nutirents);
				$(".nutrient-tips-hd ul").removeClass();
				$(".nutrient-tips-hd ul").addClass("score-"+Imntyvalue);
				$('.loader').remove();
				var el = $('.foodlist-items-row .nadded');
				//alert(foodNutrientData.entry_food_id);
				$(".nadded .fooditem-name").attr("data-entryid",foodNutrientData.entry_food_id);
				$(".nadded .fooditem-dlt").attr("data-entryid",foodNutrientData.entry_food_id);
				$(".nadded .food-unitqty").attr("data-entryid",foodNutrientData.entry_food_id);
				$(".nadded .updatefoodItem").attr("data-entryid",foodNutrientData.entry_food_id);
		        el.addClass('added');
		        el.removeClass('nadded');
				
			}
		});
	});
	
	/**
	Food Item Delete
	**/

	$(document).on('click', '.foodlist-item-dtls .fooditem-dlt', function (event) {
		event.stopImmediatePropagation();
		var lang = drupalSettings.path.currentLanguage;
		var food_entry_id = Drupal.checkPlain($(this).attr('data-entryid'));
		if (lang == "hi") {
			var short_url ="hindi/";
		} 
		else {
			var short_url = "";
		}
		var confirmDel = '';
		var foodcnt = "";
		if (lang == "hi") {
			foodcnt = "क्या आप इस फ़ूड को हटाना चाहते हैं?"
		}else{
			foodcnt = "Do you want to delete this food entry?"
		}
		if (confirm(foodcnt)) {
			confirmDel = 1;
		} else {
			confirmDel = 2;
		}
		var $this = $(this);
		if (confirmDel == 1) {
		var short_url = hindiUrl();
			jQuery.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "immunity/delete-meal",
			data: {
			food_entry_id: food_entry_id
			},
			beforeSend: function () {
			 $(laoderHtml).appendTo(".immuno-scl");
			},
			success: function (deleteNutrientData) {
			console.log(deleteNutrientData);	
			var Imntyvalue = deleteNutrientData.color;
			
			var nutirents = '';
				$.each(deleteNutrientData.nutrients_data, function (key, value) {
						nutirents += '<div class="item-tips" data-tab="tab-'+ (key+1) +' " class="modal-tab"><div class="tips-title">' + value.name + '</div><div class="tips-graph"><div class="tips-graph-box"><div class="col25 '+ value.class_color+'-color"></div></div></div><div class="tips-popup" data-nutriname="'+ value.name +'" data-nutricolor="'+value.class_color+'"><a href="javascript:void(0)">Tips</a></div></div>';
					});
				$('.nutrient-tips-list').html(nutirents);
				$(".nutrient-tips-hd ul").removeClass();
				$(".nutrient-tips-hd ul").addClass("score-"+Imntyvalue);
			
			//$('#immunity-score-div .nutrients_rda').html(nutirents);
			 $this.parents('.foodlist-item.added').remove();
			 $('.loader').remove();
			}
		 });
		}
	});

  Drupal.behaviors.immunityGetTips = {
		attach: function (context, settings) {
			$(document).on('click', '.tips-popup', function (event) {
				event.stopImmediatePropagation();
				var short_url = hindiUrl();
				var nutrient = jQuery(this).attr('data-nutriname');
				var color = jQuery(this).attr('data-nutricolor');
				jQuery(laoderHtml).appendTo('.main-wrp');
				jQuery.ajax({
					dataType: "json",
					url: drupalSettings.path.baseUrl + short_url + "immunity/nutrients",
					data: {
						nutrient: nutrient,
						rda_color: color
					},
					success: function (nutrients) {
						$('#tipsdata').html('');
						jQuery('#tipsdata').html(nutrients.nutri_data);
						$(".tipsboost-popup").show();	
						$(".tipsboost-popup .tips-commonbox:first").show();
						$(".tips-tab a").click(function() {
							$(".tips-tab a").removeClass("active-tip");
							$(this).addClass("active-tip");
							$(".tips-commonbox").hide();
							var activeTab = ".tipsboost-popup"+" "+ $(this).attr("href");
							$(activeTab).show(); 
							return false;
						});
						$(".tipsboost-popup .close-immunopopup").click(function(){
							$(".immuno-overlay").hide();	
						});	
						$(".loader").remove();
					}
				});
			});

		}
  };
  
  /** 
     Edit toggle
  **/
	$(document).on('click', '.fooditem-edt', function (event) {
		$(this).parents('.foodlist-item').find('.droplist').prop("disabled", false);
		$(this).parents('.foodlist-item').find('.btn-addminus').prop("disabled", false);
	});
	
	/**
	  Update Immunity data
	**/
	$(document).on('click', '.updatefoodItem', function (event) {
		var entryFoodItd = $(this).attr('data-entryid');
		var short_url = hindiUrl();
		var unitq = $(this).parent().prev('.food-unitqty').find(".droplist :selected").val();
		var unitqVal = $(this).parent().prev('.food-unitqty').find(".qty").val();
		$(this).parents('.foodlist-item.added').find('.fooditem-name i').text(unitqVal);
		$.ajax({
			dataType: "json",
			url: drupalSettings.path.baseUrl + short_url + "immunity/update-meal",
			data: {
				food_entry_id: entryFoodItd,
				fd_quantity_val: unitqVal,
				fd_serUnit_val: unitq
			},
			beforeSend: function () {
			 $(laoderHtml).appendTo(".immuno-scl");
			},
			success: function (foodNutrientData) {
				var Imntyvalue = foodNutrientData.immunityScore;
				var nutirents = '';
				$.each(foodNutrientData.nutrients_data, function (key, value) {
						nutirents += '<div class="item-tips" data-tab="tab-'+ (key+1) +' " class="modal-tab"><div class="tips-title">' + value.name + '</div><div class="tips-graph"><div class="tips-graph-box"><div class="col25 '+ value.class_color+'-color"></div></div></div><div class="tips-popup" data-nutriname="'+ value.name +'" data-nutricolor="'+value.class_color+'"><a href="javascript:void(0)">Tips</a></div></div>';
					});
				$('.nutrient-tips-list').html(nutirents);
				$(".nutrient-tips-hd ul").removeClass();
				$(".nutrient-tips-hd ul").addClass("score-"+Imntyvalue);
				
				console.log(foodNutrientData);
				$(".loader").remove();
			}
		});
		return false;
    });
 

})(jQuery, Drupal);	



