(function ($, Drupal) {
	
	$('.dasbord-testimonial-slider').slick({
	dots: true,
	infinite: true,
	arrows:false,
	autoplay: false,
	speed: 1500,
	autoplaySpeed: 4000,
	slidesToShow: 1
	});
	
	$(document).on('click', '#ask_community_hp', function () {

		var lang = drupalSettings.language;
		if (lang == "hi") {
			var short_url ="hindi/";
		} 
		else {
			var short_url = "";
		}
		var comtxt = Drupal.checkPlain($('#hp_community_textbx').val());
		console.log(comtxt);
		console.log(lang);
		if(/^[a-zA-Z0-9-\s\. ? `\, ]*$/.test(comtxt) == false) {
			return false;
		}
        var laoderHtml = '<div class="loader"><span></span></div>';
		if (comtxt != '') {
			$.ajax({
				url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
				type: 'post',
				cache: false,
				data: {
					"action": "creat_post",
					"txt": comtxt
				},
				beforeSend: function () {
					$(laoderHtml).appendTo(".ask-question");
			    },
				success: function (response) {
					var html = '<p>'+comtxt+':(Pending approval)</p><a href="/community">Check status</a>';
					$(".loader").remove();
					$("#ask_comm_oupt").html(html);
					$("#ask_community_hp").prop('disabled', true);
					$('#hp_community_textbx').val('');
				}
			});
		}

	});
	
	
	
	
})(jQuery, Drupal);
