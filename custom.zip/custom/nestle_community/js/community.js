/**
 * @file
 * Handles community records, events.
 */

(function ($, Drupal) {
    'use strict';

    Drupal.behaviors.community = {
        attach: function (context) {

            var lang = drupalSettings.language;
            if (lang == "hi") {
                var short_url ="hindi/";
            } 
            else {
                var short_url = "";
            }
            /*
             * Animate(open) the comment box in community.
             */
            $('.cmty-detail .reply', context).click(function () {
               /* var thisTitle = $(this).text();
                dataLayer.push({
                    "event":"LinkClick",
                    "EventLabel":thisTitle,
                    "EventValue":"AskNestle Community",
                    "EventAction":"Internal Link Click",
                }); */
                
                $('.reply-form').animate({
                    bottom: 0,
                }, 1000);
            });

            /*
             * Animate(close) the comment box in community.
             */
            $('.cm-cross', context).click(function () {
				
                $('textarea#edit-comment').css('border', 'none');
                $('.reply-form').animate({
                    bottom: -100 + '%',
                }, 1000);
                // $("form#comment-form")[0].reset()
                $('iframe').contents().find('body').empty();
				
            });
			
			$.fn.comtpupshowmsg = function () {
				$('div.alert-pos_com').removeClass('hidden');
				setTimeout(function () {
					$('div.alert-pos_com').addClass('hidden');
				}, 5000);
				//location.reload(true);			
			};
									
            /*
             * Ajax comment submit on community.
             */


            $('button.p_com', context).click(function () {
                var lang = drupalSettings.language;
                if (lang == "hi") {
                    var short_url ="hindi/";
                } 
                else {
                    var short_url = "";
                }
                var comtxt = Drupal.checkPlain($('.post_txt').val());
                console.log(comtxt);
                console.log(lang);
               
                if(/^[a-zA-Z0-9-\s\. ? `\, ]*$/.test(comtxt) == false) {

                return false;
                }



              /*  var format = /^[&'"<>]*$/;

                if(comtxt.match(format)){
                    alert("test")
                return false;
                }*/

                if (comtxt != '') {
                    $.ajax({
                        url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
                        type: 'post',
                        cache: false,
                        data: {
                            "action": "creat_post",
                            "txt": comtxt
                        },
                        success: function (response) {
                            $('.post_txt').val('');
                            $('div.alert-pos_com').removeClass('hidden');
                            setTimeout(function () {
                                $('div.alert-pos_com').addClass('hidden');
                            }, 5000);
                            location.reload(true);
                        }
                    });
                }

            });

            /*
             * Auto redirect to the registration page while try to post community(anonymous user only).
             */

            $('.ask-away.pre-cm', context).click(function () {
                var lang = drupalSettings.language;
                if (lang == "hi") {
                    var short_url ="hindi/";
                    var kindly_register = 'सवाल पूछने के लिए कृपया हमारे साथ रजिस्टर करें';
                } 
                else {
                    var short_url = "";
                    var kindly_register = 'Hey ! Kindly register with us to ask a question';
                }
                var cmPrpt = window.confirm(kindly_register);
                if (cmPrpt) {
                    window.location.href = drupalSettings.path.baseUrl + short_url + "user/register";
                }
            });
    



          
					/*Bind click*/
						//$('.cmshare').unbind()
                        $(".cmshare").click(function(){
                            $(this).closest("div.block-shareeverywhereblock").slideToggle();
                        });
			

            /*
             * Ajax report abuse of purticular comment on community question.
             */
            $('button.report_abuse', context).click(function () {
                var lang = drupalSettings.language;
                if (lang == "hi") {
                    var short_url ="hindi/";
                    var comment_marked = 'टिप्पणी सफलतापूर्वक रिपोर्ट कर दी गयी है ';
                    var are_you_sure = "क्या आप इस टिप्पणी को रिपोर्ट करना चाहते हैं? ";
                } 
                else {
                    var short_url = "";
                    var comment_marked = 'Comment marked as reported successfully.';
                    var are_you_sure = "Are you sure you want to report this comment?";
                }
                var c_report = $(this);
                var id = Drupal.checkPlain($(this).data('id'));

                if (confirm(are_you_sure)) {
                    if (id != '') {
                        $.ajax({
                            url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
                            type: 'post',
                            cache: false,
                            data: {
                                "action": "report_abuse",
                                "id": id
                            },
                            success: function (response) {
                                alert(comment_marked);
                                c_report.remove();
                            }
                        });
                    }
                } else {
                    return false;
                }
            });
            
            /*
             * Load more functionality
             */
            $('.load-more-data', context).on('click', '#btn_more', function () {
                var limitVar = 10;
                loadarticles(limitVar);
            });

            

            function loadarticles(limitVar) {
                var laoderHtml = '<div class="loader"><span></span></div>';
                var lang = drupalSettings.language;
                if (lang == "hi") {
                    var short_url ="hindi/";
                    var no_record_found = 'कोई रिकॉर्ड नहीं मिला';
                    var back_to_article = 'वापस लेख पर जाए';
                } 
                else {
                    var short_url = "";
                    var no_record_found = 'No Record Found';
                    var back_to_article = 'Back to article';
                }

                var limit = Drupal.checkPlain(parseInt($('#limit').val()));
                var rowEnd = '';
                var totalEndVAl = '';
                var row = Drupal.checkPlain(parseInt($('#row').val()));
                var allcount = Drupal.checkPlain(parseInt($('#count').val()));
                
                row = parseInt(row) + parseInt(limit);

                if (row < allcount) {
                    $("#row").val(row);
                    $.ajax({
                        url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
                        type: 'post',
                        data: {
                            "action": "load_community",
                            "row": row,
                            "limit": limit
                        },
                        beforeSend: function () {
                            $(laoderHtml).appendTo(".community-list");
                        },
                        success: function (response) {
                            if (response.articlesData != '') {
                                rowEnd = Drupal.checkPlain(parseInt($('#row').val()));
                                totalEndVAl = parseInt(rowEnd) + parseInt(limit);

                                if (totalEndVAl == allcount || totalEndVAl > allcount) {
                                    $('.load-more-data').hide();
                                } else {
                                    $('.load-more-data').show();
                                }

                                $(".community-list .item-comment:last").after(response.articlesData).show();
                                a2a.init_all();
                                $(".loader").remove();
                            } else {
                                $('.community-list').html('<div class="recordntfd">'+ no_record_found +'<span><a href="' + drupalSettings.path.baseUrl + 'expert-advice">'+ back_to_article +'</a><span></div>');
                                $('.load-more-data').hide();
                            }
                        }
                    });
                }
            }
            
            
            /*
             * Like button functionality on community listing
             */
            
            $('.community-list', context).on('click', '.item-comment .like_dislike', function () {
                var lang = drupalSettings.language;
                if (lang == "hi") {
                    var short_url ="hindi/";
                } 
                else {
                    var short_url = "";
                }
                var element = $(this);
                var id = element.data('id');
                var type = element.attr('data-ld');

                $.ajax({
                    url: drupalSettings.path.baseUrl + short_url + 'ajax/set-ajax',
                    type: 'post',
                    cache: false,
                    data: {
                        "action": "setLikeDislike",
                        "id": id,
                        "type": type
                    },
                    success: function (response) {
                      console.log(response.likes);
                        if (type == 'dislike') {
                            element.attr('data-ld', 'like');
                            element.removeClass('thumup');
                            element.addClass('activethumup');
                        }
                        else if (type == 'like') {
                            element.attr('data-ld', 'dislike');
                            element.removeClass('activethumup');
                             element.addClass('thumup');
                        }
                        element.parent().find('.like-count-data').text(response.likes);
                    }
                });
            });			
        }
    }
})(jQuery, Drupal);
