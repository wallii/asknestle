<?php

namespace Drupal\nestle_community\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\image\Entity\ImageStyle;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\user\Entity\User;
use Drupal\comment\Entity\Comment;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Language\LanguageManager;
use Drupal\file\Entity\File;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\media\Entity\Media;

/**
 * Show all community listing and categories.
 *
 * @internal
 */
class HomePageCommunity extends ControllerBase {
  # home page community data	
  public static function HomeRecentCommunity() {
	$langCode = CommonFunc::multilingualConvert("lang");
	$cm_query = \Drupal::entityQuery('node')
	->range(0, 3)
	->condition('status', 1)
	->condition('type', 'community', '=');
	$cm_nids = $cm_query->sort('created', 'DESC')->execute();

	$cm_nodes = Node::loadMultiple($cm_nids);
	$search['countcommunityPage'] = count($cm_nids);
	$community = array();
	foreach ($cm_nodes as $node) {

		//$node = $node->getTranslation($langCode);
		$nid = $node->get('nid')->value;
		$uid = $node->getOwnerId();
		$comm['uid'] = $uid;
		$date = $node->get('created')->value;
		$comm['created_date'] = \Drupal::service('date.formatter')->format($date, 'dtf') . " " . date("A", $date);
		$comm['author'] = '';
		$comm['body'] = strip_tags($node->get('body')->value);
		$alias_url = \Drupal::service('path_alias.manager')->getAliasByPath('/node/'.$nid);
		$comm['node_url'] = $alias_url;
		$likeDislike = CommonFunc::checklikeDislike($nid);
		if(!empty($likeDislike)) {
		$comm['likeDLike']= $likeDislike[0]->like_num;
		} else {
		$comm['likeDLike']= 0;
		}
		$comm['current_user'] = CommonFunc::userId();			
		$comm['total_comment'] = CommonFunc::countComment($nid);
		$comm['u_name'] = CommonFunc::getUserValue('field_first_name', $uid);
		/* author image
		*/
		$user = User::load($uid);
		if(!empty($user->user_picture->getValue())){
		$fid =  $user->user_picture->getValue()[0]['target_id'];
		}

		if(!empty($fid)){
		$file_image =File::load($user->user_picture->getValue()[0]['target_id']);
		$original_image = $file_image->getFileUri();
		$image_path = file_url_transform_relative(file_create_url($original_image));
		}else{
		$image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
		}
		$comm['image'] = $image_path;
		$like_dislike = CommonFunc::checklikeDislike($nid);
		if ($like_dislike != '') {
		if (array_key_exists(0, $like_dislike) && $like_dislike[0]->like_num == 1) {
		$comm['like'] = $like_dislike[0]->like_num;
		}
		}
		$community[] = $comm;
	}
	//echo "<pre>";
	//print_r($community); die;
	$data['community'] = $community;
	return [
			'#theme' => 'HomeCommunityBlock',
			'#params' => $data,
			'#attached' => [
				'library' => 'nestle_community/nestle_community_home_page',
			]
		];
	  
	  
  }
}
 
