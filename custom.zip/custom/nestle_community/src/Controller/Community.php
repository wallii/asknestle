<?php

namespace Drupal\nestle_community\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\image\Entity\ImageStyle;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\user\Entity\User;
use Drupal\comment\Entity\Comment;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Language\LanguageManager;
use Drupal\file\Entity\File;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\media\Entity\Media;

/**
 * Show all community listing and categories.
 *
 * @internal
 */
class Community extends ControllerBase {
  /**
  * {@inheritdoc}
  */
public function listing() {
  global $base_url;
  $hindi = CommonFunc::isHindi();
  $lang_code = CommonFunc::multilingualConvert("lang");
  $user_id = CommonFunc::userId();

  /*
  * Getting community articles
  */
  $query = \Drupal::entityQuery('node');
  $query->condition('type', 'community', '=');

  if (\Drupal::currentUser()->isAnonymous() == TRUE) {
    $query->condition('status', 1);
  } else {
    $group = $query->orConditionGroup()
    ->condition('uid', $user_id, '=')
    ->condition('status', 1);
    $query->condition($group);
  }

  $count = $query->count()->execute();
  $setLoadmore = '';

  if ($count > 0) {
    $nid = \Drupal::entityQuery('node');
    $nid->condition('type', 'community', '=');

  if (\Drupal::currentUser()->isAnonymous() == TRUE) {
    $nid->condition('status', 1);
  } else {
    $group = $nid->orConditionGroup()
    ->condition('uid', $user_id, '=')
    ->condition('status', 1);
    $nid->condition($group);
  }

  $nid->sort('created', 'DESC');
  $nid->range(0, 5);
  $nids = $nid->execute();
  $communities = Node::loadMultiple($nids);

  $articleslimit = 5;
  $articles['limit'] = $articleslimit;
  $articles['count'] = $count;
  $articles['status'] = 1;

  if ($articleslimit == $count || $articleslimit > $count) {
    $setLoadmore = 1;
  }
  $articles['setLoadmore'] = $setLoadmore;
  $contents = [];
  foreach ($communities as $community) {
    $owner_id = $community->getOwnerId();
    if ($community->isPublished() == FALSE) {
      if ($owner_id === $user_id) {
      $contents['ownpublish'][] = $community;
      } else {
      $contents['unpublish'][] = $community;
      }
    } else {
      $contents['publish'][] = $community;
    }
  }
  if (array_key_exists('ownpublish', $contents)){
    foreach ($contents['ownpublish'] as $content) {
      $count = CommonFunc::likeDislikeCount($content->id());
      $data = addtoany_create_entity_data($content);
      $share_html = [];
      $like_dislike = CommonFunc::checklikeDislike($content->id());
      
      if ($like_dislike != '') {
        if (array_key_exists(0, $like_dislike) && $like_dislike[0]->like_num == 1) {
          $article['like'] = $like_dislike[0]->like_num;
        }
      }

      $share_html[] = [
        '#addtoany_html' => \Drupal::token()->replace($data['addtoany_html'], ['node' => $content]),
        '#link_url' => $data['link_url'],
        '#link_title' => strip_tags(CommonFunc::summary($content->get('body')->value, 125)),
        '#button_setting' => $data['button_setting'],
        '#button_image' => $data['button_image'],
        '#universal_button_placement' => $data['universal_button_placement'],
        '#buttons_size' => $data['buttons_size'],
        '#theme' => 'addtoany_standard',
        '#cache' => [
          'contexts' => ['url'],
        ],
      ];

      $article['share'] = $share_html;
      $article['id'] = $content->id();
      $article['likes'] = ($count['likes'] != '') ? $count['likes'] : 0;
      $article['status'] = 'ownpublish';
      $article['desc'] = CommonFunc::summary($content->get('body')->value, 125);
      $article['full_desc'] = strip_tags($content->get('body')->value);
      $article['desclength'] = strlen($content->get('body')->value);
      $article['comment'] = CommonFunc::countComment($content->id());
      $article['u_name'] = CommonFunc::getUserValue('field_first_name', $content->getOwnerId());
      $article['url'] = Url::fromRoute('entity.node.canonical', ['node' => $content->id()])->toString();
      $uid =$content->getOwnerId();
      $user = User::load($uid);
      if(!empty($user->user_picture->getValue())){
        $fid =  $user->user_picture->getValue()[0]['target_id'];
      }
      if(!empty($fid)){
        $file_image =File::load($user->user_picture->getValue()[0]['target_id']);
        $original_image = $file_image->getFileUri();
        $image_path = file_url_transform_relative(file_create_url($original_image));
      }else{
        $image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
      }
      $article['image'] = $image_path;
      //$article['ago'] = date('jS M, y h:i A', $content->get('created')->value);
      $article['ago'] = \Drupal::service('date.formatter')->format($content->get('created')->value, 'dtf') . " " . date("A", $content->get('created')->value);
      $articles['communities'][] = $article;
    }
  }

  foreach ($contents['publish'] as $content) {
  $count = CommonFunc::likeDislikeCount($content->id());
  $data = addtoany_create_entity_data($content);
  $share_html = [];
  $like_dislike = CommonFunc::checklikeDislike($content->id());


  if ($like_dislike != '') {
  if (array_key_exists(0, $like_dislike) && $like_dislike[0]->like_num == 1) {
    $article['like'] = $like_dislike[0]->like_num;
  }
  }

  $share_html[] = [
  '#addtoany_html' => \Drupal::token()->replace($data['addtoany_html'], ['node' => $content]),
  '#link_url' => $data['link_url'],
  '#link_title' => strip_tags(CommonFunc::summary($content->get('body')->value, 125)),
  '#button_setting' => $data['button_setting'],
  '#button_image' => $data['button_image'],
  '#universal_button_placement' => $data['universal_button_placement'],
  '#buttons_size' => $data['buttons_size'],
  '#theme' => 'addtoany_standard',
  '#cache' => [
  'contexts' => ['url'],
  ],
  ];

  $article['share'] = $share_html;
  $article['id'] = $content->id();
  $article['likes'] = ($count['likes'] != '') ? $count['likes'] : 0;
  $article['status'] = 'published';
  $article['full_desc'] = strip_tags($content->get('body')->value);
  $article['desc'] = CommonFunc::summary(strip_tags($content->get('body')->value), 125);
  $article['desclength'] = strlen($content->get('body')->value);
  $article['comment'] = CommonFunc::countComment($content->id());
  $article['u_name'] = CommonFunc::getUserValue('field_first_name', $content->getOwnerId());
  $uid =$content->getOwnerId();
  $user = User::load($uid);

  if(!empty($user->user_picture->getValue()))
  {
    $fid =  $user->user_picture->getValue()[0]['target_id'];
  }
 
    if(!empty($fid)){
      $file_image =File::load($user->user_picture->getValue()[0]['target_id']);
      $original_image = $file_image->getFileUri();
      $image_path = file_url_transform_relative(file_create_url($original_image));
    }else{
      $image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
    }
  $article['image'] = $image_path;
  $article['url'] = Url::fromRoute('entity.node.canonical', ['node' => $content->id()])->toString();
  //$article['ago'] = date('jS M, y h:i A', $content->get('created')->value);
  $article['ago'] = \Drupal::service('date.formatter')->format($content->get('created')->value, 'dtf') . " " . date("A", $content->get('created')->value);

  $articles['communities'][] = $article;
  unset($article['like']);
  }
  } else {
  $articles['setLoadmore'] = 1;
  $articles['status'] = 0;
  }
  /** Community Videos Code Starts Here */
  $nids = \Drupal::entityQuery('node')
  ->condition('type', 'community_videos', '=')
  ->sort('created', 'ASC')
  ->range(0, 20)
  ->execute();
  $community_videos = Node::loadMultiple($nids);
  $community_video_data =array();
  foreach ($community_videos as $cv) {
    if ($cv->isPublished()) {
      if(!empty($cv->field_yt_video_cover_image->getValue())){
        $thumbnail_fid =  $cv->field_yt_video_cover_image->getValue()[0]['target_id'];
      }
      if(!empty($thumbnail_fid)){
        $file_image =File::load($thumbnail_fid);
        $original_image = $file_image->getFileUri();
        $image = file_url_transform_relative(file_create_url($original_image));
      }else{
        $image ="/themes/custom/nestle_new/common/images/community-video-thum.jpg";
      }
      //$image ="/themes/custom/nestle_new/common/images/community-video-thum.jpg";
      //$cv = $cv->getTranslation($lang_code);
      $link = $cv->field_yt_video_url->getValue()[0]['value'];
      $cvideo['title'] = $cv->getTitle();
      $cvideo['image'] = $image;
      $cvideo['link'] = $link;
      $community_video_data[] = $cvideo;
    }
  }
  $articles['cvideos'] = $community_video_data;
  /** Community Videos Code Ends Here */
  /**** Start current logged in user image *****/
  $current_uid = CommonFunc::userId();
  $image_path ='';
  if($current_uid !=0){
    $user = User::load($current_uid);
    if(!empty($user->user_picture->getValue())){
      $fid =  $user->user_picture->getValue()[0]['target_id'];
    }
    if(!empty($fid)){
      $file_image =File::load($user->user_picture->getValue()[0]['target_id']);
      $original_image = $file_image->getFileUri();
      $image_path = file_url_transform_relative(file_create_url($original_image));
    }else{
      $image_path ="/themes/custom/nestle_new/common/images/default-avatar.png";
    }
  }
  /**** End current logged in user image *****/

  /**** Start get community config page data *****/
  $page_header = array();
  $page_header['heading'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_heading_1');
  $page_header['subhead'] = CommonFunc::getConfigPageFieldValue('common_page_headings', 'field_heading_2');
  /**** End get community config page data *****/
  return [
  '#theme' => 'Community',
  '#articles' => $articles,
  '#u_image' => $image_path,
  '#pheader' =>$page_header,
  '#attached' => [
  'library' => 'nestle_community/community_style',
  ],
  ];
}
    
  /**
   * Start Show abuse comment report list in admin panel.
   */
  public function abuseReporting() {
    $database = \Drupal::database();
    $sort_type = \Drupal::request()->query->get('sort');
    if ($sort_type == '' || $sort_type == 'DESC') {
      $sort_data_by = 'ASC';
      $sort_data_query = 'DESC';
    } else {
      $sort_data_by = 'DESC';
      $sort_data_query = 'ASC';
    }
    $header = [
      'label_0' => [
        'data' => $this->t('#'),
      ],
      'label_1' => [
          'data' => $this->t('Community question'),
      ],
      'label_2' => [
        'data' => $this->t('Comment'),
      ],
      'label_3' => [
        'data' => $this->t('Commented By'),
      ],
      'arc_counter' => [
        'data' => $this->t('Abuse Counter'),
        'specifier' => 'arc_counter',
        'sort' => 'desc',
        'data' => new FormattableMarkup('<a href=":link">Abuse Counter</a>', [':link' => '?sort=' . $sort_data_by,
            '@name' => 'Abuse Counter'])
      ],
      'label_6' => [
        'data' => $this->t('Action'),
      ],
      'label_7' => [
        'data' => $this->t(''),
      ],
    ];
    $query = $database->select('abuse_reports_counter', 'arc');
    $query->join('comment_field_data', 'cfd', 'arc.arc_comment_id = cfd.cid');
    $query
      ->fields('arc')
      ->orderby('arc_counter', $sort_data_query);
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(50);
    $reports = $pager->execute()->fetchAll();
    $rows = [];
    $i = 1;
    foreach ($reports as $report) {
      $community = Node::load($report->arc_community_id);
      $commented_user = User::load($report->arc_commented_user_id);
      $comment = Comment::load($report->arc_comment_id);
      if ($community && $commented_user && $comment) {
        $row = [];
        $row[] = $i;
        $row[] = str_replace('&nbsp;', ' ', strip_tags(CommonFunc::summary($community->body->value, 100)));
        if (!$comment->get('comment_body')->isEmpty()){
          $row[] = str_replace('&nbsp;', ' ', strip_tags($comment->get('comment_body')->value));
        } 
        else {
          $row[] = "N/A";
        }
        $row[] = ucwords($commented_user->field_first_name->value) . ' (' . $commented_user->mail->value . ')';
        $row[] = $report->arc_counter;

        if ($comment->isPublished()) {
          $action = 'Unpublish';
        } else {
          $action = 'Publish';
        }

        $row[] = Link::createFromRoute(t($action), 'nestle_community.comment_status', ['id' => $report->arc_comment_id], ['relative' => TRUE]);
        $row[] = Link::createFromRoute($this->t('View'), 'nestle_community.comment_view', ['id' => $report->arc_comment_id], ['relative' => TRUE]);
        $rows[] = $row;
        $i++;
      }
    }
    $build['table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => $this->t('No content has been found.'),
    ];
    $build['pager'] = [
      '#type' => 'pager',
    ];
    return $build;
  }
  /* End Start Show abuse comment report list in admin panel.***/
  /*
   * Start Community abusing comment report view in admin panel.
   */
  public function comment_view() {
    $database = \Drupal::database();
    $date_formatter = \Drupal::service('date.formatter');
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $comment_id = end($path_args);
    $listing_url = Url::fromRoute('nestle_community.abuse_report')->toString();
    $status_url = Url::fromRoute('nestle_community.comment_status', $route_parameters = array("id" => $comment_id))->toString();
    $ar_data = $database->select('abuse_reports', 'ar')
      ->fields('ar')
      ->condition('ar_comment_id', $comment_id, '=')
      ->range(0, 1)
      ->execute()->fetchObject();
    $community = Node::load($ar_data->ar_community_id);
    $commented_user = User::load($ar_data->ar_commented_user_id);
    $reported_user = User::load($ar_data->ar_reporter_id);
    $comment = Comment::load($ar_data->ar_comment_id);
    $comment_array = $comment->toArray();

    if ($comment->isPublished()) {
      $action = 'Unpublish';
    } else {
      $action = 'Publish';
    }

    $community_question = $community->body->value;
    $created = $comment_array['created'][0]['value'];
    $display_date = $date_formatter->format($created, 'custom', 'D, j F Y, h:i:sA', 'IST');
    $comment_details = [];
    $comment_details['community_question'] = str_replace('&nbsp;', ' ', strip_tags($community_question));
    if (!$comment->get('comment_body')->isEmpty()) {
      $comment_details['comment'] = str_replace('&nbsp;', ' ', strip_tags($comment->get('comment_body')->value));
    } 
    else {
      $comment_details['comment'] = "N/A";
    }
    $comment_details['commented_by'] = ucwords($commented_user->field_first_name->value);
    $comment_details['commented_by_email'] = $commented_user->mail->value;
    $comment_details['commented_on'] = $display_date;
    $comment_details['listing_url'] = $listing_url;
    $comment_details['status_url'] = $status_url;
    $comment_details['action'] = $action;

    $all_abuses = $database->select('abuse_reports', 'ar')
      ->fields('ar')
      ->condition('ar_comment_id', $comment_id, '=')
      ->execute()->fetchAll();
    $comment_details['report_abuse_count'] = count($all_abuses);
    foreach ($all_abuses as $aa) {
      $reported_user = User::load($aa->ar_reporter_id);
      $this_created = $aa->ar_created;
      $this_display_date = $date_formatter->format($this_created, 'custom', 'D, j F Y, h:i:sA', 'IST');
      $reporter_details['reporter_name'] = ucwords($reported_user->field_first_name->value);
      $reporter_details['reporter_email'] = $reported_user->mail->value;
      $reporter_details['report_date'] = $this_display_date;
      $comment_details['reporter_details'][] = $reporter_details;
    }
    return [
      '#theme' => 'CommunityCommentView',
      '#comment_details' => $comment_details,
      '#attached' => [
        'library' => 'nestle_community/community_style',
      ],
    ];
  }
  /* End Start Community abusing comment report view in admin panel.***/
  /*
   * Start set publish / unpublish abused comment functionality in admin panel.
   */
  public function comment_status() {
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $comment_id = end($path_args);
    $comment = Comment::load($comment_id);
    if ($comment->isPublished()) {
        $action = 'Unpublished';
        $comment->setUnpublished();
        $comment->save();
    } else {
        $action = 'Published';
        $comment->setPublished();
        $comment->save();
    }
    // Redirect to Abusive Comments Listing
    \Drupal::messenger()->addStatus(t('Comment ' . $action . ' Successfully!'));
    return $this->redirect('nestle_community.abuse_report');
  }
  /* End set publish / unpublish abused comment functionality in admin panel.***/
}
 
