<?php

namespace Drupal\nestle_community\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\nestle_common\Controller\CommonFunc;
use Drupal\comment\Entity\Comment;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\CssCommand;
use \Symfony\Component\HttpFoundation\Response;
use \Symfony\Component\HttpFoundation\Cookie;
use Drupal\user\Entity\User;

/**
 * Provides comment form for community.
 *
 * @internal
 */
class CommentForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'comment_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $node_id = NULL, $node_title = NULL) {
    $form['c_id'] = [
      '#type' => 'hidden',
      '#default_value' => $node_id,
    ];

    $form['c_title'] = [
      '#type' => 'hidden',
      '#default_value' => $node_title,
    ];

    $form['comment'] = [
      '#type'=>'textarea',
      '#placeholder' => t('Add a reply'),
      //'#format'=>'full_html',
      '#attributes' => array('class' => array('textarea-fild')),
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => t('Submit')
    ];

    $form['#theme'] = 'AddComment';
    $form['#attached']['library'][] = 'nestle_community/community_style';
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function saveComment(array &$form, FormStateInterface $form_state) {
	 
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $comment = $form_state->getValue('comment');
    $without_html_comment = str_replace('&nbsp;', ' ', strip_tags($comment));
    $user_id = CommonFunc::userId();
    if (trim($without_html_comment) == '') {
      $ifstring = false;
    } 
    else {
      $ifstring = true;
    }
    if ($ifstring && $user_id) {

      $c_id = $form_state->getValue('c_id');
      $c_title = $form_state->getValue('c_title');
      
      if (strlen($without_html_comment) > 50) {
        $without_html_comment = substr($c_title, 0, 50 - 3);
        $without_html_comment = substr($without_html_comment, 0, strrpos($without_html_comment, ' '));
      }
      $values = [
        'entity_type' => 'node',
        'entity_id' => $c_id,
        'field_name' => 'field_user_comments',
        'uid' => $user_id,
        'comment_type' => 'comment',
        'subject' => trim($without_html_comment),
        'comment_body' => $comment,
            // 'status' => 0,
        'status' => 1,
      ];

      $comment = Comment::create($values);
      if ($comment->save() == TRUE) {
        $cids = \Drupal::entityQuery('comment')
          ->condition('entity_id', $c_id)
          ->condition('entity_type', 'node')
          ->condition('status', 1)
          ->sort('cid', 'DESC')
          ->execute();
      }
    }
  }

}
